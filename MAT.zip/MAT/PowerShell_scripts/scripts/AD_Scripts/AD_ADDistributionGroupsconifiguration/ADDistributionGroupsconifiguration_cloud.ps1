﻿<#
Export-AAD_Groups_DistributionAndSecurity.ps1
Purpose: Export Azure AD groups inventory (all groups, distribution groups, security groups).
Infrastructure: cloud (Azure AD / Microsoft Graph app-only)
Notes: This script uses the exact connection block you provided (unchanged). Ensure Z: or your network drive has Config.json with TenantId/AppId/Thumbprint and the certificate is installed.
#>

Set-StrictMode -Version Latest
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# --- Ensure Microsoft.Graph modules are available (import) ---
# These imports ensure the required cmdlets are present in the session.
# If Microsoft.Graph is not installed, install it before running this script.
#Import-Module Microsoft.Graph -ErrorAction Stop
#Import-Module Microsoft.Graph.Groups -ErrorAction SilentlyContinue

# --- Your exact block (unchanged) ---
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$JsonPath = "$network_drive\Config.json"

$config = Get-Content $JsonPath | ConvertFrom-Json

$TenantId = $config. TenantId

$ClientId = $config.AppId

$Thumbprint = $config. Thumbprint

#=== Output ===

$OutFolder = "$network_drive\AD_ADDistributionGroupsconifiguration"

# Ensure TLS 1.2

[Net.ServicePointManager]:: SecurityProtocol = [Net.SecurityProtocolType]:: Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

# Output file paths
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$OutAllGroupsCsv = Join-Path $OutFolder "AAD_AllGroups_$timeStamp.csv"
$OutDistributionCsv = Join-Path $OutFolder "AAD_DistributionGroups_$timeStamp.csv"
$OutSecurityCsv = Join-Path $OutFolder "AAD_SecurityGroups_$timeStamp.csv"

Write-Host "Fetching groups from Microsoft Graph..." -ForegroundColor Cyan

# We will request a core set of properties; expand members/owners counts per-group.
$props = "id,displayName,mail,mailNickname,groupTypes,securityEnabled,mailEnabled,onPremisesSyncEnabled,createdDateTime,onPremisesSamAccountName"

# Fetch all groups (paged internally by the SDK)
$allGroups = Get-MgGroup -Property $props -All -ErrorAction Stop

Write-Host ("Total groups retrieved: {0}" -f $allGroups.Count) -ForegroundColor Green

# Prepare result array
$rows = @()

foreach ($g in $allGroups) {
    # Basic properties
    $id = $g.Id
    $displayName = $g.DisplayName
    $mail = $g.Mail
    $mailNick = $g.MailNickname
    $groupTypes = if ($g.GroupTypes) { ($g.GroupTypes -join ";") } else { "" }
    $securityEnabled = $g.SecurityEnabled
    $mailEnabled = $g.MailEnabled
    $onPremSync = $g.OnPremisesSyncEnabled
    $created = $g.CreatedDateTime
    $onPremSam = $g.OnPremisesSamAccountName

    # Owner count
    $ownerCount = 0
    try {
        $ownerCount = (Get-MgGroupOwner -GroupId $id -All -ErrorAction Stop | Measure-Object).Count
    } catch {
        # if the tenant/app doesn't have permission to enumerate owners, leave as -1 to indicate unknown
        $ownerCount = -1
    }

    # Member count
    $memberCount = 0
    try {
        $memberCount = (Get-MgGroupMember -GroupId $id -All -ErrorAction Stop | Measure-Object).Count
    } catch {
        $memberCount = -1
    }

    $rows += [PSCustomObject]@{
        Id = $id
        DisplayName = $displayName
        Mail = $mail
        MailNickname = $mailNick
        GroupTypes = $groupTypes
        SecurityEnabled = $securityEnabled
        MailEnabled = $mailEnabled
        OnPremisesSyncEnabled = $onPremSync
        OnPremisesSamAccountName = $onPremSam
        CreatedDateTime = $created
        OwnersCount = $ownerCount
        MembersCount = $memberCount
    }
}

# Export all groups
$rows | Export-Csv -Path $OutAllGroupsCsv -NoTypeInformation -Encoding UTF8 -Force
Write-Host "All groups exported to: $OutAllGroupsCsv" -ForegroundColor Green

# Filter distribution groups: mailEnabled = true AND securityEnabled = $false (classic distribution groups)
$distributionGroups = $rows | Where-Object { ($_.MailEnabled -eq $true) -and ($_.SecurityEnabled -ne $true) }
$distributionGroups | Export-Csv -Path $OutDistributionCsv -NoTypeInformation -Encoding UTF8 -Force
Write-Host ("Distribution groups exported: {0} -> {1}" -f $distributionGroups.Count, $OutDistributionCsv) -ForegroundColor Green

# Filter security groups: SecurityEnabled = true (includes mail-enabled security groups and pure security groups)
$securityGroups = $rows | Where-Object { $_.SecurityEnabled -eq $true }
$securityGroups | Export-Csv -Path $OutSecurityCsv -NoTypeInformation -Encoding UTF8 -Force
Write-Host ("Security groups exported: {0} -> {1}" -f $securityGroups.Count, $OutSecurityCsv) -ForegroundColor Green

Write-Host "Done." -ForegroundColor Cyan