﻿<#
.SYNOPSIS
  Export AAD directory roles & members via raw Graph calls, expand nested group membership, CSV output.

.REQUIRES
  Microsoft.Graph PowerShell (for Connect-MgGraph / Invoke-MgGraphRequest).
  Scopes: Directory.Read.All, Group.Read.All, RoleManagement.Read.Directory
#>

# ------------------ CONFIG ------------------
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

$outCsv = Join-Path $network_drive/AD_ADRBACconfiguration ("Cloud_RBAC_Report_{0:yyyyMMdd_HHmmss}.csv" -f (Get-Date))

# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null


# ----------------- HELPERS ------------------
function Get-GraphPaged {
    param(
        [Parameter(Mandatory)][string]$Uri # relative to v1.0, e.g. '/directoryRoles'
    )
    $all = @()
    $next = "https://graph.microsoft.com/v1.0$Uri"
    while ($next) {
        try {
            $resp = Invoke-MgGraphRequest -Method GET -Uri $next -ErrorAction Stop
        } catch {
            Write-Warning "Graph GET failed: $next : $_"
            break
        }
        if ($resp.value) { $all += $resp.value } else { $all += $resp }
        $next = $resp.'@odata.nextLink'
    }
    return $all
}

function Resolve-MemberShape {
    param(
        [Parameter(Mandatory)]$Obj # element from Graph .value
    )
    # Works with directory objects returned from /directoryRoles/{id}/members or /groups/{id}/members
    $type = $Obj.'@odata.type'
    if (-not $type) { $type = $Obj.'@odata.context' } # rare fallback
    $shortType = ($type -replace '#?microsoft\.graph\.','')
    switch -regex ($shortType) {
        'group' { $kind = 'Group' }
        'user' { $kind = 'User' }
        'servicePrincipal' { $kind = 'ServicePrincipal' }
        'device' { $kind = 'Device' }
        default { $kind = if ($shortType) { $shortType } else { ($Obj.'@odata.type' | Out-String).Trim() } }
    }

    $id = $Obj.id
    $name = $Obj.displayName
    $upn = $Obj.userPrincipalName

    [PSCustomObject]@{
        Id = $id
        Kind = $kind
        DisplayName = $(if ($name) { $name } else { $id })
        UPN = $upn
        Raw = $Obj
    }
}

function Get-GroupMembersRecursive_Graph {
    param(
        [Parameter(Mandatory)][string]$TopGroupId,
        [Parameter(Mandatory)][string]$TopGroupDisplayName,
        [Parameter(Mandatory)][string]$CurrentGroupId,
        [int]$CurrentLevel = 0,
        [string]$ParentChain = $null,
        [string]$ImmediateParent = $null,
        [ref]$Visited
    )
    if ([string]::IsNullOrEmpty($ParentChain)) { $chain = $TopGroupDisplayName } else { $chain = "$ParentChain > $CurrentGroupId" }

    $members = Get-GraphPaged -Uri "/groups/$CurrentGroupId/members"
    $rows = @()

    foreach ($m in $members) {
        $info = Resolve-MemberShape -Obj $m
        $key = $info.Id
        if (-not $key) { $key = "$($info.Kind):$($info.DisplayName)" }

        if ($Visited.Value.Contains($key)) {
            $rows += [PSCustomObject]@{
                RoleName = $null
                RoleId = $null
                AssignmentType = $null
                PrincipalType = 'Visited'
                PrincipalDisplayName = $info.DisplayName
                PrincipalUPN = $info.UPN
                GroupId = $TopGroupId
                Source = 'Graph_Transitive'
                TopGroup = $TopGroupDisplayName
                TopGroupId = $TopGroupId
                NestedParentChain = $chain
                NestedLevel = $CurrentLevel
                ImmediateParent = $ImmediateParent
                ResolvedMemberId = $info.Id
                ResolvedMemberType = $info.Kind
                ResolvedMemberDisplay = $info.DisplayName
                ResolvedMemberUPN = $info.UPN
                DirectMember = ($CurrentLevel -eq 0)
                Note = 'AlreadyVisited'
            }
            continue
        }

        $Visited.Value.Add($key) | Out-Null

        if ($info.Kind -ieq 'Group') {
            # emit nested-group row
            $rows += [PSCustomObject]@{
                RoleName = $null
                RoleId = $null
                AssignmentType = $null
                PrincipalType = 'Group'
                PrincipalDisplayName = $info.DisplayName
                PrincipalUPN = $info.UPN
                GroupId = $TopGroupId
                Source = 'Graph_Transitive'
                TopGroup = $TopGroupDisplayName
                TopGroupId = $TopGroupId
                NestedParentChain = $chain
                NestedLevel = $CurrentLevel
                ImmediateParent = $ImmediateParent
                ResolvedMemberId = $info.Id
                ResolvedMemberType = 'Group'
                ResolvedMemberDisplay = $info.DisplayName
                ResolvedMemberUPN = $info.UPN
                DirectMember = ($CurrentLevel -eq 0)
                Note = 'NestedGroup'
            }

            # recurse deeper
            $rows += Get-GroupMembersRecursive_Graph -TopGroupId $TopGroupId -TopGroupDisplayName $TopGroupDisplayName `
                        -CurrentGroupId $info.Id -CurrentLevel ($CurrentLevel + 1) `
                        -ParentChain $chain -ImmediateParent $info.DisplayName -Visited $Visited
        }
        else {
            # leaf member
            $rows += [PSCustomObject]@{
                RoleName = $null
                RoleId = $null
                AssignmentType = $null
                PrincipalType = $info.Kind
                PrincipalDisplayName = $info.DisplayName
                PrincipalUPN = $info.UPN
                GroupId = $TopGroupId
                Source = 'Graph_Transitive'
                TopGroup = $TopGroupDisplayName
                TopGroupId = $TopGroupId
                NestedParentChain = $chain
                NestedLevel = $CurrentLevel
                ImmediateParent = $ImmediateParent
                ResolvedMemberId = $info.Id
                ResolvedMemberType = $info.Kind
                ResolvedMemberDisplay = $info.DisplayName
                ResolvedMemberUPN = $info.UPN
                DirectMember = ($CurrentLevel -eq 0)
                Note = ''
            }
        }
    }

    return $rows
}

# --------- COLLECT DIRECTORY ROLES & MEMBERS (RAW GRAPH) ----------
Write-Host "Fetching directory roles..." -ForegroundColor Cyan
$roles = Get-GraphPaged -Uri "/directoryRoles"

$results = @()
foreach ($role in $roles) {
    $roleName = $role.displayName
    $roleId = $role.id

    Write-Host " Members of role: $roleName" -ForegroundColor DarkCyan
    $members = Get-GraphPaged -Uri "/directoryRoles/$roleId/members"

    foreach ($m in $members) {
        $info = Resolve-MemberShape -Obj $m

        # Base (original) assignment row (your original columns)
        $row = [PSCustomObject]@{
            RoleName = $roleName
            RoleId = $roleId
            AssignmentType = 'DirectoryRoleMember'
            PrincipalType = $info.Kind
            PrincipalDisplayName = $info.DisplayName
            PrincipalUPN = $info.UPN
            GroupId = if ($info.Kind -ieq 'Group') { $info.Id } else { $null }
            Source = 'Graph:v1.0/directoryRoles'
        }
        $results += $row
    }
}

# ------------- EXPAND NESTED GROUP MEMBERS (RECURSIVE) -------------
$expanded = @()
foreach ($entry in $results) {
    # Keep original row
    $expanded += [PSCustomObject]@{
        RoleName = $entry.RoleName
        RoleId = $entry.RoleId
        AssignmentType = $entry.AssignmentType
        PrincipalType = $entry.PrincipalType
        PrincipalDisplayName = $entry.PrincipalDisplayName
        PrincipalUPN = $entry.PrincipalUPN
        GroupId = $entry.GroupId
        Source = $entry.Source
        TopGroup = $null
        TopGroupId = $null
        NestedParentChain = $null
        NestedLevel = $null
        ImmediateParent = $null
        ResolvedMemberId = $null
        ResolvedMemberType = $null
        ResolvedMemberDisplay = $null
        ResolvedMemberUPN = $null
        DirectMember = $null
        Note = 'OriginalAssignment'
    }

    # If principal is a group, expand its nested members
    if ($entry.PrincipalType -ieq 'Group' -and $entry.GroupId) {
        $topGroupId = $entry.GroupId
        $topGroupName = $entry.PrincipalDisplayName
        if (-not $topGroupName) { $topGroupName = $topGroupId }

        $visitedSet = New-Object System.Collections.Generic.HashSet[string]
        $visitedRef = [ref]$visitedSet

        $members = Get-GroupMembersRecursive_Graph -TopGroupId $topGroupId -TopGroupDisplayName $topGroupName `
                    -CurrentGroupId $topGroupId -CurrentLevel 0 -ParentChain $null -ImmediateParent $null -Visited $visitedRef

        if ($members) {
            # Carry over the role fields onto the nested rows for context (optional but handy)
            $expanded += $members | ForEach-Object {
                $_ | Select-Object `
                    @{n='RoleName';e={$entry.RoleName}},
                    @{n='RoleId';e={$entry.RoleId}},
                    @{n='AssignmentType';e={$entry.AssignmentType}},
                    @{n='PrincipalType';e={$_.PrincipalType}},
                    @{n='PrincipalDisplayName';e={$_.PrincipalDisplayName}},
                    @{n='PrincipalUPN';e={$_.PrincipalUPN}},
                    @{n='GroupId';e={$entry.GroupId}},
                    @{n='Source';e={$_.Source}},
                    TopGroup,TopGroupId,NestedParentChain,NestedLevel,ImmediateParent,DirectMember,Note,
                    ResolvedMemberId,ResolvedMemberType,ResolvedMemberDisplay,ResolvedMemberUPN
            }
        }
    }
}

# ---------------------- EXPORT ----------------------
if ($expanded.Count -gt 0) {
    $ordered = $expanded | Select-Object `
        RoleName,RoleId,AssignmentType,PrincipalType,PrincipalDisplayName,PrincipalUPN,GroupId,Source,`
        TopGroup,TopGroupId,NestedParentChain,NestedLevel,ImmediateParent,DirectMember,Note,`
        ResolvedMemberId,ResolvedMemberType,ResolvedMemberDisplay,ResolvedMemberUPN

    $ordered | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
    Write-Host "Exported $($ordered.Count) RBAC assignment / resolved-member entries to $outCsv" -ForegroundColor Green
} else {
    "" | Select-Object "RoleName","RoleId","AssignmentType","PrincipalType","PrincipalDisplayName","PrincipalUPN","GroupId","Source" |
    Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
    Write-Host "No RBAC assignments found. Header-only CSV created: $outCsv" -ForegroundColor Yellow
}