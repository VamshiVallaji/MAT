﻿<#
Export-AAD_Devices_ConnectMgGraph_Safe.ps1
PowerShell 5.1 - uses your exact Connect-MgGraph block, safe property access, header-only CSV if no rows.
#>

# --- YOUR EXACT CONNECT BLOCK (unchanged) ---
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$JsonPath = "$network_drive\Config.json"

$config = Get-Content $JsonPath | ConvertFrom-Json

$TenantId = $config. TenantId

$ClientId = $config.AppId

$Thumbprint = $config. Thumbprint

#=== Output ===

$OutFolder = "$network_drive\AD_AllComputersInventory"

# Ensure TLS 1.2

[Net.ServicePointManager]:: SecurityProtocol = [Net.SecurityProtocolType]:: Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null
# --- end exact block ---

$timeStamp = (Get-Date).ToString("yyyyMMdd_HHmmss")
$outCsv = Join-Path $OutFolder ("AAD_Devices_{0}.csv" -f $timeStamp)

Write-Host "Querying Microsoft Graph (Get-MgDevice)..." -ForegroundColor Cyan

# Attempt to get devices via SDK. If the SDK cmdlet is missing, let user know.
try {
    $devices = Get-MgDevice -All -ErrorAction Stop
} catch {
    Write-Host "Failed to call Get-MgDevice: $($_.Exception.Message)" -ForegroundColor Red
    # create header-only CSV and exit gracefully
    "" | Select-Object Id,DisplayName,DeviceId,DeviceType,OperatingSystem,OperatingSystemVersion,Model,Manufacturer,AccountEnabled,TrustType,ApproximateLastSignInDateTime,OnPremisesSyncEnabled,OnPremisesDistinguishedName,OwnersCount |
        Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Force
    Write-Host "Header-only CSV created at $outCsv" -ForegroundColor Yellow
    exit 0
}

if (-not $devices -or $devices.Count -eq 0) {
    Write-Host "No devices returned from Graph. Creating header-only CSV at $outCsv" -ForegroundColor Yellow
    "" | Select-Object Id,DisplayName,DeviceId,DeviceType,OperatingSystem,OperatingSystemVersion,Model,Manufacturer,AccountEnabled,TrustType,ApproximateLastSignInDateTime,OnPremisesSyncEnabled,OnPremisesDistinguishedName,OwnersCount |
        Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Force
    Write-Host "Header-only CSV created: $outCsv" -ForegroundColor Green
    exit 0
}

Write-Host ("Devices retrieved: {0}" -f $devices.Count) -ForegroundColor Green

# Helper function: safe property get (works for typed SDK objects and for additional properties)
function Get-Safe {
    param($obj, [string]$name)
    if ($null -eq $obj) { return $null }
    # Try PSObject properties first
    $p = $obj.PSObject.Properties[$name]
    if ($p -ne $null) { return $p.Value }
    # Try AdditionalProperties dictionary (Microsoft.Graph SDK)
    if ($obj.PSObject.Properties['AdditionalProperties']) {
        $ap = $obj.AdditionalProperties
        if ($ap -and $ap.ContainsKey($name)) { return $ap[$name] }
    }
    # Try indexer fallback
    try { return $obj[$name] } catch {}
    return $null
}

$rows = @()
foreach ($d in $devices) {
    # owners count: try SDK Get-MgDeviceRegisteredOwner -DeviceId <id> -All
    $ownerCount = -1
    try {
        $owners = Get-MgDeviceRegisteredOwner -DeviceId $d.Id -All -ErrorAction Stop
        $ownerCount = ($owners | Measure-Object).Count
    } catch {
        $ownerCount = -1
    }

    $rows += [PSCustomObject]@{
        Id = (Get-Safe $d 'id')
        DisplayName = (Get-Safe $d 'displayName')
        DeviceId = (Get-Safe $d 'deviceId')
        DeviceType = (Get-Safe $d 'deviceType')
        OperatingSystem = (Get-Safe $d 'operatingSystem')
        OperatingSystemVersion = (Get-Safe $d 'operatingSystemVersion')
        Model = (Get-Safe $d 'model')
        Manufacturer = (Get-Safe $d 'manufacturer')
        AccountEnabled = (Get-Safe $d 'accountEnabled')
        TrustType = (Get-Safe $d 'trustType')
        ApproximateLastSignInDateTime = (Get-Safe $d 'approximateLastSignInDateTime')
        OnPremisesSyncEnabled = (Get-Safe $d 'onPremisesSyncEnabled')
        OnPremisesDistinguishedName = (Get-Safe $d 'onPremisesDistinguishedName')
        OwnersCount = $ownerCount
    }
}

# Export to CSV
try {
    $rows | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Force
    Write-Host ("Export complete: {0} devices -> {1}" -f $rows.Count, $outCsv) -ForegroundColor Green
} catch {
    Write-Host "Failed to write CSV $outCsv : $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host "Done." -ForegroundColor Cyan