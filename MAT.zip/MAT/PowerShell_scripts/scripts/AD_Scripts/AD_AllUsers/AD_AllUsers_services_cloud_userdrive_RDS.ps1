﻿# Merged_AAD_Inventory_Script.ps1
# Single script to produce a combined report for:
# - All users (with SignInActivity and nested groups)
# - Service accounts inventory
# - HomeDrive and RDS-related notes
# Reads TenantId/AppId/Thumbprint from <NetworkDrive>:\Config.json and connects via certificate (app-only)
# PowerShell 5.1+ / Microsoft.Graph module

# --- Read config from first network drive found ---
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID | Select-Object -First 1
if (-not $network_drive) { Write-Host "FATAL: No network drive found (DriveType=4)." -ForegroundColor Red; exit 1 }
$JsonPath = Join-Path $network_drive "Config.json"
if (-not (Test-Path $JsonPath)) { Write-Host "FATAL: Config.json not found at $JsonPath" -ForegroundColor Red; exit 1 }
$config = Get-Content $JsonPath -ErrorAction Stop | ConvertFrom-Json
$TenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint

# --- Output ---
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$ReportPath = Join-Path $network_drive ("AD_AllUsers/AAD_Combined_Inventory_{0}.csv" -f $timeStamp)

# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using certificate..." -ForegroundColor Cyan
Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

# Make sure users module available (Get-MgUser)
try { Import-Module Microsoft.Graph.Users -ErrorAction Stop } catch { Write-Host "Warning: Microsoft.Graph.Users module not available - proceeding if Get-MgUser exists." }

# Properties we want to retrieve from user object
$props = @(
    'id','displayName','userPrincipalName','mail','jobTitle','department','companyName','officeLocation',
    'accountEnabled','mobilePhone','businessPhones','streetAddress','city','state','postalCode','country',
    'createdDateTime','signInActivity',
    'userType','onPremisesSyncEnabled','onPremisesSamAccountName','onPremisesUserPrincipalName','onPremisesDistinguishedName',
    'onPremisesImmutableId','onPremisesExtensionAttributes','manager'
)

Write-Host "Retrieving all Azure AD users (requesting SignInActivity and onPremises attributes)..." -ForegroundColor Cyan
try {
    $AllUsers = Get-MgUser -All -Property ($props -join ',') -ErrorAction Stop
    Write-Host ("Retrieved {0} users" -f $AllUsers.Count) -ForegroundColor Green
} catch {
    Write-Host "FATAL: Failed to retrieve users: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Build group map for quick lookup of display names (optional)
Write-Host "Retrieving all Azure AD groups (for nested group display names)..." -ForegroundColor Cyan
try {
    $AllGroups = Get-MgGroup -All -ErrorAction Stop
    $GroupMap = @{}
    foreach ($g in $AllGroups) { $GroupMap[$g.Id] = $g.DisplayName }
} catch {
    Write-Host "Warning: Failed to retrieve groups: $($_.Exception.Message)" -ForegroundColor Yellow
    $GroupMap = @{}
}

# Helper: detect service account
function Is-ServiceAccount($u) {
    if (-not $u) { return $false }
    $patterns = '(^svc-)|(^svc_)|\bsvc\b|\bservice\b|\bapp\b|\bautomation\b|\bbot\b|\bsvc\.'
    if ($u.DisplayName -and ($u.DisplayName -match $patterns)) { return $true }
    if ($u.UserPrincipalName -and ($u.UserPrincipalName -match $patterns)) { return $true }
    return $false
}

# Helper: Extract manager UPN or Id readable
function Get-ManagerName($mgr) {
    if (-not $mgr) { return "" }
    # Manager may be an object or string; try to extract userPrincipalName or displayName
    if ($mgr -is [string]) { return $mgr }
    if ($mgr.AdditionalProperties.ContainsKey('userPrincipalName')) { return $mgr.AdditionalProperties['userPrincipalName'] }
    if ($mgr.DisplayName) { return $mgr.DisplayName }
    return ""
}

# Helper: Determine HomeDrive and RDS presence
function Detect-HomeDriveRDS($u) {
    $hasHomeDrive = $false
    $homeDriveNote = ""
    $hasRDS = $false
    $rdsNote = ""

    # Check common on-premises DN or extension attributes for home directory/drive names
    if ($u.onPremisesDistinguishedName -and ($u.onPremisesDistinguishedName -match 'Home|home|Profile|ProfilePath|msTSHomeDirectory')) { $hasHomeDrive = $true; $homeDriveNote = "onPremisesDistinguishedName indicates home/profile" }
    if ($u.onPremisesExtensionAttributes) {
        $extJson = $null
        try { $extJson = $u.onPremisesExtensionAttributes | ConvertTo-Json -Compress -Depth 3 } catch { $extJson = $null }
        if ($extJson -and ($extJson -match 'home|Home|HomeDrive|homeDrive|HomeDirectory|homeDirectory|msTSHomeDirectory|msTSHomeDrive')) {
            $hasHomeDrive = $true
            if ($homeDriveNote) { $homeDriveNote += '; extensionAttributes contain home' } else { $homeDriveNote = 'extensionAttributes contain home' }
        }
    }

    # Heuristics: jobtitle/department mentioning RDS/TS/RemoteDesktop
    if ($u.jobTitle -and ($u.jobTitle -match 'RDS|Remote|Terminal Services|Remote Desktop|ts|tsserver')) { $hasRDS = $true; $rdsNote = 'jobTitle suggests RDS' }
    if ($u.department -and ($u.department -match 'RDS|Remote|Terminal Services|Remote Desktop')) { $hasRDS = $true; if ($rdsNote) { $rdsNote += '; department suggests RDS' } else { $rdsNote = 'department suggests RDS' } }
    if ($u.onPremisesExtensionAttributes -and ($u.onPremisesExtensionAttributes.ToString() -match 'msTS|TSHome|Terminal')) { $hasRDS = $true; if ($rdsNote) { $rdsNote += '; extensionAttributes' } else { $rdsNote = 'extensionAttributes indicate RDS' } }

    return @{ HasHomeDrive = $hasHomeDrive; HomeDriveNote = $homeDriveNote; HasRDS = $hasRDS; RDSNote = $rdsNote }
}

# Build report rows
$rows = @()
Write-Host "Building combined inventory rows (this may take time for large tenants)..." -ForegroundColor Cyan
$i = 0
foreach ($u in $AllUsers) {
    $i++
    if (($i % 200) -eq 0) { Write-Host "Processed $i users..." }

    # Sign-in activity handling
    $sia = $null
    try { $sia = $u.SignInActivity } catch { $sia = $null }
    if (-not $sia) {
        # Fallback to sign-in logs (requires AuditLog.Read.All). Attempt, but don't fail if it errors.
        $lastSignIn = $null
        $statusText = 'NoSignInFound'
        try {
            $siEvent = Get-MgAuditLogSignIn -Filter ("userPrincipalName eq '{0}'" -f $($u.UserPrincipalName)) -Top 1 -ErrorAction Stop
            if ($siEvent) {
                $lastSignIn = $siEvent.CreatedDateTime
                $statusText = if ($siEvent.Status -and $siEvent.Status.ErrorCode -eq 0) { 'Success' } else { ($siEvent.Status.FailureReason -or 'Failed') }
            }
        } catch {
            # swallow
            $lastSignIn = $null
            $statusText = 'NoSignInFound'
        }
    } else {
        $lastSignIn = $sia.lastSuccessfulSignInDateTime
        if (-not $lastSignIn) { $lastSignIn = $sia.lastSignInDateTime }
        $statusText = if ($sia.lastSuccessfulSignInDateTime) { 'Success' } elseif ($sia.lastSignInDateTime) { 'SignInRecorded' } else { 'NoSignInFound' }
    }

    # Nested groups
    $groups = @()
    try {
        $members = Get-MgUserMemberOf -UserId $u.Id -All
        foreach ($m in $members) {
            if ($m.AdditionalProperties.ContainsKey('displayName')) { $groups += $m.AdditionalProperties['displayName'] }
            elseif ($m.DisplayName) { $groups += $m.DisplayName }
        }
    } catch {
        $groups = @("ErrorRetrievingGroups: $($_.Exception.Message -replace '\r?\n',' ')")
    }

    # Service account detection
    $isSvc = Is-ServiceAccount $u

    # HomeDrive / RDS detection
    $h = Detect-HomeDriveRDS $u

    # Manager
    $mgr = Get-ManagerName $u.Manager

    $rows += [PSCustomObject]@{
        # Common user-focused columns
        DisplayName = $u.DisplayName
        UserPrincipalName = $u.UserPrincipalName
        Mail = $u.Mail
        JobTitle = $u.JobTitle
        Department = $u.Department
        CompanyName = $u.CompanyName
        OfficeLocation = $u.OfficeLocation
        AccountEnabled = $u.AccountEnabled
        MobilePhone = $u.MobilePhone
        BusinessPhones = ($u.BusinessPhones -join "; ")
        StreetAddress = $u.StreetAddress
        City = $u.City
        State = $u.State
        PostalCode = $u.PostalCode
        Country = $u.Country
        CreatedDateTime = $u.CreatedDateTime
        LastSignInDateTime = $lastSignIn
        SignInStatus = $statusText
        NestedGroups = ($groups -join "; ")
        Id = $u.Id
        ObjectId = $u.Id

        # Service-account focused columns
        IsServiceAccount = if ($isSvc) { 'Yes' } else { 'No' }
        Enabled = if ($u.AccountEnabled) { 'Yes' } else { 'No' }
        UserType = $u.UserType
        OnPremisesSyncEnabled = if ($u.onPremisesSyncEnabled) { 'Yes' } else { 'No' }
        Manager = $mgr

        # onPremises details useful for homeDrive/RDS detection and hybrid mapping
        onPremisesSamAccountName = $u.onPremisesSamAccountName
        onPremisesUserPrincipalName = $u.onPremisesUserPrincipalName
        onPremisesDistinguishedName = $u.onPremisesDistinguishedName
        onPremisesImmutableId = $u.onPremisesImmutableId
        onPremisesExtensionAttributes = ($(if ($u.onPremisesExtensionAttributes) { $u.onPremisesExtensionAttributes | ConvertTo-Json -Compress -Depth 3 } else { "" }))
        HomeDriveDetected = if ($h.HasHomeDrive) { 'Yes' } else { 'No' }
        HomeDriveNote = $h.HomeDriveNote
        RDSDetected = if ($h.HasRDS) { 'Yes' } else { 'No' }
        RDSNote = $h.RDSNote
    }
}

# Export to CSV
Write-Host "Exporting combined report to: $ReportPath" -ForegroundColor Cyan
try {
    $rows | Export-Csv -Path $ReportPath -NoTypeInformation -Encoding UTF8 -Force
    Write-Host "Exported $($rows.Count) rows -> $ReportPath" -ForegroundColor Green
} catch {
    Write-Host "FATAL: Failed to write CSV: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host "Done." -ForegroundColor Cyan