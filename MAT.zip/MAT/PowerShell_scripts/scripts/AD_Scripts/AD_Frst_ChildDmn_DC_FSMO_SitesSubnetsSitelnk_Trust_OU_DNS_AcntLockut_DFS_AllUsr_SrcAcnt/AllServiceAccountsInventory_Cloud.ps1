$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
#$OutFolder = "Z:\AD_Frst_ChildDmn_DC_FSMO_SitesSubnetsSitelnk_Trust_OU_DNS_AcntLockut_DFS_AllUsr_SrcAcnt"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null
# Optionally switch to beta if you prefer latest signInActivity behavior:
# Select-MgProfile -Name "beta"

# Output CSV
$OutputCsv = "Z:\AD_Frst_ChildDmn_DC_FSMO_SitesSubnetsSitelnk_Trust_OU_DNS_AcntLockut_DFS_AllUsr_SrcAcnt\AzureADServiceAccountsInventory_$timeStamp.csv"

# Get all users
$allUsers = Get-MgUser -All -Property DisplayName, UserPrincipalName, AccountEnabled, UserType, OnPremisesSyncEnabled, JobTitle, Department, Mail, Manager, SignInActivity, CreatedDataTime

# Filter service accounts (adjust pattern as per your naming convention)
$serviceAccounts = $allUsers | Where-Object { ($_.DisplayName -match "svc|service|app|automation|bot") -or ($_.UserPrincipalName -match "svc|service|app") }
#$serviceAccounts = $allUsers | Where-Object { $_.DisplayName -like "*svc*" }

# Format inventory
$inventory = $serviceAccounts | Select-Object `
    DisplayName,
    UserPrincipalName,
    @{Name='Enabled';Expression={if ($_.AccountEnabled) {'Yes'} else {'No'}}},
    UserType,
    @{Name='OnPremisesSyncEnabled';Expression={if ($_.OnPremisesSyncEnabled) {'Yes'} else {'No'}}},
    JobTitle,
    Department,
    Mail,
    @{Name='Manager';Expression={($_.Manager -replace ".*\/users\/","")}}

# Export to CSV
$inventory | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding UTF8
Write-Host "Azure AD Service Accounts exported to $OutputCsv"