﻿param(
 
  [int]$Days = 30,
  [int]$SampleSize = 200
)

$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutFolder = "$network_drive\AD_GPO_List_in_Domain_Config_ADAudit"

# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
# File paths
$dirAuditsSamplePath = Join-Path $OutFolder "DirectoryAuditsSample_$timeStamp.csv"
$dirAuditsSummaryPath = Join-Path $OutFolder "DirectoryAuditsSummary_$timeStamp.csv"
$signInsSamplePath = Join-Path $OutFolder "SignInsSample_$timeStamp.csv"
$signInsSummaryPath = Join-Path $OutFolder "SignInsSummary_$timeStamp.csv"
$rolesPath = Join-Path $OutFolder "DirectoryRolesMembers_$timeStamp.csv"


# Time window
$startIso = (Get-Date).ToUniversalTime().AddDays(-1 * [int]$Days).ToString("o")
$nowIso = (Get-Date).ToUniversalTime().ToString("o")

Write-Host "Fetching Directory Audit logs (sample)..." -ForegroundColor Cyan
$dirAudits = @()
try {
  $uri = "https://graph.microsoft.com/v1.0/auditLogs/directoryAudits?`$filter=activityDateTime ge $startIso&`$orderby=activityDateTime desc&`$top=$SampleSize"
  $res = Invoke-MgGraphRequest -Method GET -Uri $uri -ErrorAction SilentlyContinue
  if ($res -and $res.value) { $dirAudits = $res.value }
} catch {
  Write-Warning "Directory audit retrieval failed: $_"
  $dirAudits = @()
}

# Build directory audit rows (PS5-safe: precompute variables)
$dirRows = @()
foreach ($a in $dirAudits) {
  $id = ""; $activityDateTime = ""; $activityDisplayName = ""; $loggedByService = ""; $initiatedBy = ""
  $targetResources = ""; $result = ""; $resultReason = ""
  try { if ($a.id) { $id = $a.id } } catch {}
  try { if ($a.activityDateTime) { $activityDateTime = $a.activityDateTime } } catch {}
  try { if ($a.activityDisplayName) { $activityDisplayName = ($a.activityDisplayName -replace "`r|`n"," ") } } catch {}
  try { if ($a.loggedByService) { $loggedByService = $a.loggedByService } } catch {}
  try {
    if ($a.initiatedBy -and $a.initiatedBy.user -and $a.initiatedBy.user.displayName) { $initiatedBy = $a.initiatedBy.user.displayName }
    elseif ($a.initiatedBy -and $a.initiatedBy.app -and $a.initiatedBy.app.displayName) { $initiatedBy = $a.initiatedBy.app.displayName }
  } catch {}
  try {
    if ($a.targetResources) {
      $names = @()
      foreach ($t in $a.targetResources) {
        try { if ($t.displayName) { $names += $t.displayName } } catch {}
      }
      if ($names.Count -gt 0) { $targetResources = $names -join ";" }
    }
  } catch {}
  try { if ($a.result) { $result = $a.result } } catch {}
  try { if ($a.resultReason) { $resultReason = $a.resultReason } } catch {}

  $dirRows += [PSCustomObject]@{
    Id = $id
    ActivityDateTime = $activityDateTime
    ActivityDisplayName= $activityDisplayName
    LoggedByService = $loggedByService
    InitiatedBy = $initiatedBy
    TargetResources = $targetResources
    Result = $result
    ResultReason = $resultReason
  }
}

# Export Directory Audits sample or header-only CSV
if ($dirRows.Count -gt 0) {
  $dirRows | Export-Csv -Path $dirAuditsSamplePath -NoTypeInformation -Encoding UTF8
  Write-Host "Wrote DirectoryAuditsSample.csv (rows: $($dirRows.Count))"
} else {
  "" | Select-Object "Id","ActivityDateTime","ActivityDisplayName","LoggedByService","InitiatedBy","TargetResources","Result","ResultReason" |
    Export-Csv -Path $dirAuditsSamplePath -NoTypeInformation -Encoding UTF8
  Write-Host "No Directory audit entries; header-only CSV created."
}

# Directory audits summary (single row)
$dirSummaryObj = New-Object PSObject
$dirSummaryObj | Add-Member NoteProperty StartDate $startIso
$dirSummaryObj | Add-Member NoteProperty EndDate $nowIso
$dirSummaryObj | Add-Member NoteProperty SampleFetched ($dirRows | Measure-Object).Count
$dirSummaryObj | Export-Csv -Path $dirAuditsSummaryPath -NoTypeInformation -Encoding UTF8
Write-Host "Wrote DirectoryAuditsSummary.csv"

# -------------------------
# Sign-in logs (sample)
# -------------------------
Write-Host "Fetching Sign-in logs (sample)..." -ForegroundColor Cyan
$signIns = @()
try {
  $uri = "https://graph.microsoft.com/v1.0/auditLogs/signIns?`$filter=createdDateTime ge $startIso&`$orderby=createdDateTime desc&`$top=$SampleSize"
  $sres = Invoke-MgGraphRequest -Method GET -Uri $uri -ErrorAction SilentlyContinue
  if ($sres -and $sres.value) { $signIns = $sres.value }
} catch {
  Write-Warning "Sign-in retrieval failed: $_"
  $signIns = @()
}

$signRows = @()
foreach ($s in $signIns) {
  $sid=""; $created=""; $userDisplay=""; $userUpn=""; $appDisplay=""; $ip=""; $client=""; $caStatus=""; $statusText=""
  try { if ($s.id) { $sid = $s.id } } catch {}
  try { if ($s.createdDateTime) { $created = $s.createdDateTime } } catch {}
  try { if ($s.userDisplayName) { $userDisplay = ($s.userDisplayName -replace "`r|`n"," ") } } catch {}
  try { if ($s.userPrincipalName) { $userUpn = $s.userPrincipalName } } catch {}
  try { if ($s.appDisplayName) { $appDisplay = $s.appDisplayName } } catch {}
  try { if ($s.ipAddress) { $ip = $s.ipAddress } } catch {}
  try { if ($s.clientAppUsed) { $client = $s.clientAppUsed } } catch {}
  try { if ($s.conditionalAccessStatus) { $caStatus = $s.conditionalAccessStatus } } catch {}

  try {
    $st = $s.status
    if ($st -and ($st.errorCode -ne $null)) { $statusText = $st.errorCode } else {
      $tmp = $null
      try { $tmp = $s.status | ConvertTo-Json -Depth 2 } catch {}
      if ($tmp) { $statusText = ($tmp -replace "`r|`n"," ") }
    }
  } catch {}

  $signRows += [PSCustomObject]@{
    Id = $sid
    CreatedDateTime = $created
    UserDisplayName = $userDisplay
    UserPrincipalName = $userUpn
    AppDisplayName = $appDisplay
    IpAddress = $ip
    ClientAppUsed = $client
    ConditionalAccessStatus = $caStatus
    Status = $statusText
  }
}

if ($signRows.Count -gt 0) {
  $signRows | Export-Csv -Path $signInsSamplePath -NoTypeInformation -Encoding UTF8
  Write-Host "Wrote SignInsSample.csv (rows: $($signRows.Count))"
} else {
  "" | Select-Object "Id","CreatedDateTime","UserDisplayName","UserPrincipalName","AppDisplayName","IpAddress","ClientAppUsed","ConditionalAccessStatus","Status" |
    Export-Csv -Path $signInsSamplePath -NoTypeInformation -Encoding UTF8
  Write-Host "No sign-in entries; header-only CSV created."
}

# Sign-in summary
$signSummaryObj = New-Object PSObject
$signSummaryObj | Add-Member NoteProperty StartDate $startIso
$signSummaryObj | Add-Member NoteProperty EndDate $nowIso
$signSummaryObj | Add-Member NoteProperty SampleFetched ($signRows | Measure-Object).Count
$signSummaryObj | Export-Csv -Path $signInsSummaryPath -NoTypeInformation -Encoding UTF8
Write-Host "Wrote SignInsSummary.csv"

# -------------------------
# Directory roles & members (who can read/manage logs)
# -------------------------
Write-Host "Fetching directory roles and members..." -ForegroundColor Cyan
$rolesMembers = @()
try {
  $rolesRes = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/directoryRoles" -ErrorAction SilentlyContinue
} catch {
  $rolesRes = $null
}

if ($rolesRes -and $rolesRes.value) {
  foreach ($r in $rolesRes.value) {
    $roleId = ""; $roleName = ""
    try { if ($r.id) { $roleId = $r.id } } catch {}
    try { if ($r.displayName) { $roleName = $r.displayName } } catch {}

    # get members
    $memRes = $null
    try { $memRes = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/directoryRoles/$roleId/members" -ErrorAction SilentlyContinue } catch {}

    if ($memRes -and $memRes.value) {
      foreach ($m in $memRes.value) {
        $memberType = ""; $memberDisplay = ""; $memberUpn = ""; $memberId = ""
        try { if ($m.'@odata.type') { $memberType = ($m.'@odata.type' -replace "#microsoft.graph.","") } } catch {}
        try { if ($m.displayName) { $memberDisplay = $m.displayName } } catch {}
        try { if ($m.userPrincipalName) { $memberUpn = $m.userPrincipalName } } catch {}
        try { if ($m.id) { $memberId = $m.id } } catch {}

        $rolesMembers += [PSCustomObject]@{
          RoleName = $roleName
          RoleId = $roleId
          MemberType = $memberType
          MemberDisplayName = $memberDisplay
          MemberUserPrincipalName = $memberUpn
          MemberId = $memberId
        }
      }
    } else {
      $rolesMembers += [PSCustomObject]@{
        RoleName = $roleName
        RoleId = $roleId
        MemberType = ""
        MemberDisplayName = ""
        MemberUserPrincipalName = ""
        MemberId = ""
      }
    }
  }
}

if ($rolesMembers.Count -gt 0) {
  $rolesMembers | Export-Csv -Path $rolesPath -NoTypeInformation -Encoding UTF8
  Write-Host "Wrote DirectoryRolesMembers.csv (rows: $($rolesMembers.Count))"
} else {
  "" | Select-Object "RoleName","RoleId","MemberType","MemberDisplayName","MemberUserPrincipalName","MemberId" |
    Export-Csv -Path $rolesPath -NoTypeInformation -Encoding UTF8
  Write-Host "No directory role data; header-only CSV created."
}

# Disconnect
try { Disconnect-MgGraph -ErrorAction SilentlyContinue } catch {}
