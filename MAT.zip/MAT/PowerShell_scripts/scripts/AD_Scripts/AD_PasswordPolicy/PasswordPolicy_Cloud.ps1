﻿<#
.SYNOPSIS
  Focused Azure AD password policy collector - PowerShell 5.1 safe.

.DESCRIPTION
  - Queries authenticationMethodsPolicy, selfServicePasswordResetPolicy, passwordProtectionPolicy.
  - Tries v1 then beta.
  - Writes JSON files and a summary CSV.
  - Requires app-only permissions (Directory.Read.All, AuthenticationMethods.Read.All, Policy.Read.All) with admin consent.
#>

$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutFolder = "$network_drive\AD_PasswordPolicy"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

# Define endpoints (v1 then beta)
$endpoints = @(
  @{ Name = "AuthenticationMethodsPolicy"; V1 = "https://graph.microsoft.com/v1.0/policies/authenticationMethodsPolicy"; Beta = "https://graph.microsoft.com/beta/policies/authenticationMethodsPolicy" },
  @{ Name = "SelfServicePasswordResetPolicy"; V1 = "https://graph.microsoft.com/v1.0/policies/selfServicePasswordResetPolicy"; Beta = "https://graph.microsoft.com/beta/policies/selfServicePasswordResetPolicy" },
  @{ Name = "PasswordProtectionPolicy"; V1 = "https://graph.microsoft.com/v1.0/policies/passwordProtectionPolicy"; Beta = "https://graph.microsoft.com/beta/policies/passwordProtectionPolicy" }
)

$summary = @()

foreach ($ep in $endpoints) {

  $name = $ep.Name
  $v1 = $ep.V1
  $beta = $ep.Beta

  Write-Host ("Checking endpoint: " + $name) -ForegroundColor Cyan

  $fetched = $false
  $usedUri = ""
  $resultObj = $null
  $errMsg = ""

  # Try v1
  try {
    $r = Invoke-MgGraphRequest -Method GET -Uri $v1 -ErrorAction Stop
    if ($r) { $fetched = $true; $usedUri = $v1; $resultObj = $r }
  } catch {
    $errMsg = $_.Exception.Message
  }

  # If not fetched, try beta
  if (-not $fetched -and $beta) {
    try {
      $r2 = Invoke-MgGraphRequest -Method GET -Uri $beta -ErrorAction Stop
      if ($r2) { $fetched = $true; $usedUri = $beta; $resultObj = $r2; $errMsg = "" }
    } catch {
      if ($errMsg -eq "") { $errMsg = $_.Exception.Message } else { $errMsg = $errMsg + " | beta: " + $_.Exception.Message }
    }
  }

  if ($fetched -and $resultObj) {
    # Save JSON safely
    $outJson = Join-Path $OutFolder ($name + $timeStamp + ".json")
    $saved = $false
    try {
      $text = $null
      try { $text = $resultObj | ConvertTo-Json -Depth 6 } catch { $text = ($resultObj | Out-String) }
      Set-Content -Path $outJson -Value $text -Encoding UTF8
      $saved = $true
    } catch {
      $saved = $false
    }

    # Make short note
    $note = ""
    try {
      if ($resultObj.value) { $note = "Items:" + ($resultObj.value.Count) }
      else {
        $props = ""
        try { $props = ($resultObj | Get-Member -MemberType NoteProperty,Property | ForEach-Object { $_.Name }) -join "," } catch {}
        if ($props) { $note = "Props:" + $props } else { $note = "Got object" }
      }
    } catch { $note = "Saved JSON" }

    $JsonFile = " " 
      if ($saved) { $JsonFile = $outJson}

    $summary += [PSCustomObject]@{
      Endpoint = $name
      Uri = $usedUri
      Status = "OK"
      Note = $note
      JsonFile = $JsonFile
    }

    Write-Host ($name + ": fetched from " + $usedUri + " (" + $note + ")") -ForegroundColor Green

  } else {
    # Not fetched or permission error
    $summary += [PSCustomObject]@{
      Endpoint = $name
      Uri = ""
      Status = "NotAvailableOrPermissionDenied"
      Note = $errMsg
      JsonFile = ""
    }
    Write-Host ($name + ": not available or permission denied. Error: " + $errMsg) -ForegroundColor Yellow
  }
}

# Export summary CSV
$csvOut = Join-Path $OutFolder "PasswordPolicySummary_$timeStamp.csv"
try {
  $summary | Export-Csv -Path $csvOut -NoTypeInformation -Encoding UTF8
  Write-Host ("Summary CSV written: " + $csvOut) -ForegroundColor Cyan
} catch {
  Write-Host ("Failed to write summary CSV: " + $_.Exception.Message) -ForegroundColor Red
}

# Disconnect Graph
try { Disconnect-MgGraph -ErrorAction SilentlyContinue } catch {}

Write-Host ("Completed. Outputs in: " + $OutFolder) -ForegroundColor Green