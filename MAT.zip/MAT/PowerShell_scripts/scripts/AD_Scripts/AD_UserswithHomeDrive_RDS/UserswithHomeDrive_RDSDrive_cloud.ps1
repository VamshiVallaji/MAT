﻿<#
Export-AADUsers_FromZConfig_CertAuth_WriteHost.ps1
PowerShell 5.1 - read tenant/client/thumbprint from Z:\config.json and connect using certificate (Connect-MgGraph)
This version uses direct Write-Host calls for informational and fatal messages.
#>

$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutFolder = "Z:\AD_UserswithHomeDrive_RDS"

# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

# Explicitly import the users submodule so Get-MgUser is available
try {
    Import-Module Microsoft.Graph.Users -ErrorAction Stop
    Write-Host "Imported Microsoft.Graph.Users module (Get-MgUser available)." -ForegroundColor Green
} catch {
    Write-Host "FATAL: Could not load Microsoft.Graph.Users module: $($_.Exception.Message). Install/repair Microsoft.Graph module." -ForegroundColor Red
    exit 1
}

# Build output folder

$outCsv = Join-Path $OutFolder ("AAD_Users_Cloud_HomeDriveRDS_{0}.csv" -f (Get-Date -Format "yyyyMMdd_HHmmss"))

# Retrieve users via Microsoft.Graph (Get-MgUser) with useful properties
Write-Host "Querying users from Microsoft Graph..." -ForegroundColor Cyan
try {
    # request a set of properties useful for hybrid detection and extension attributes
    $props = "id,displayName,userPrincipalName,mail,onPremisesSyncEnabled,onPremisesSamAccountName,onPremisesUserPrincipalName,onPremisesDistinguishedName,onPremisesImmutableId,onPremisesExtensionAttributes"
    # Get-MgUser -All will page automatically in the SDK
    $mgUsers = Get-MgUser -Property $props -All -ErrorAction Stop
    Write-Host ("Retrieved {0} users." -f ($mgUsers.Count)) -ForegroundColor Green
} catch {
    Write-Host "FATAL: Failed to retrieve users via Get-MgUser: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

$rows = @()
if ($mgUsers -and $mgUsers.Count -gt 0) {
    foreach ($u in $mgUsers) {
        $ext = ""
        try { if ($u.onPremisesExtensionAttributes) { $ext = $u.onPremisesExtensionAttributes | ConvertTo-Json -Depth 2 -Compress } } catch { $ext = "" }
        $note = if ($u.onPremisesSyncEnabled -eq $true) { "Hybrid - authoritative homeDrive/msTS on on-prem AD" } else { "Cloud-only - homeDrive/msTS typically not in Azure AD" }

        $rows += [PSCustomObject]@{
            Id = $u.Id
            DisplayName = ($u.DisplayName -as [string])
            UserPrincipalName = ($u.UserPrincipalName -as [string])
            Mail = ($u.Mail -as [string])
            onPremisesSyncEnabled = ($u.onPremisesSyncEnabled -as [string])
            onPremisesSamAccountName = ($u.onPremisesSamAccountName -as [string])
            onPremisesUserPrincipalName = ($u.onPremisesUserPrincipalName -as [string])
            onPremisesDistinguishedName = ($u.onPremisesDistinguishedName -as [string])
            onPremisesImmutableId = ($u.onPremisesImmutableId -as [string])
            onPremisesExtensionAttributes = $ext
            HomeDriveRDS_Note = $note
        }
    }
} else {
    Write-Host "No users returned from Graph. Will create header-only CSV." -ForegroundColor Yellow
}

# Export CSV (header-only if no rows)
if ($rows.Count -eq 0) {
    "" | Select-Object Id,DisplayName,UserPrincipalName,Mail,onPremisesSyncEnabled,onPremisesSamAccountName,onPremisesUserPrincipalName,onPremisesDistinguishedName,onPremisesImmutableId,onPremisesExtensionAttributes,HomeDriveRDS_Note |
        Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
    Write-Host "Header-only CSV created at: $outCsv" -ForegroundColor Green
} else {
    $rows | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
    Write-Host ("Export complete: {0} users -> {1}" -f $rows.Count, $outCsv) -ForegroundColor Green
}

Write-Host "Done." -ForegroundColor Cyan