$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint
$tenantId     = "e9c255e0-7344-4dd3-b700-76c1d79f7bbc"
$clientId     = "a0f545dd-9c85-4b46-a95d-40b393044a19"
$clientSecret = "HB_8Q~y8JUMedFaP7-cnT1WSRVWg15dYn8DB8ctR"
$scope        = "https://graph.microsoft.com/.default"

$secureSecret = ConvertTo-SecureString $clientSecret -AsPlainText -Force



# Get the access token

$token = Get-MsalToken -TenantId $tenantId -ClientId $clientId -ClientSecret $secureSecret -Scopes $scope


# Extract the access token
$accessToken = $token.AccessToken

# Define headers
$headers = @{ 
    Authorization = "Bearer $accessToken"
    "Content-Type" = "application/json"
}

# Initialize result array
$results = @()

# Retrieve threat submissions
$submissionEndpoint = "https://graph.microsoft.com/beta/security/analyzedEmails"
$submissionResponse = Invoke-RestMethod -Method Get -Uri $submissionEndpoint -Headers $headers

foreach ($item in $submissionResponse.value) {
    $results += [PSCustomObject]@{
        Category     = "Threat Submission"
        SubmissionId = $item.id
        Recipient    = $item.recipientEmailAddress
        Verdict      = $item.verdict
        ThreatType   = $item.threatType
        CreatedDate  = $item.createdDateTime
    }

    # Retrieve remediation details
    $remediationEndpoint = "https://graph.microsoft.com/beta/security/emailThreatSubmission/$($item.id)/remediation"
    try {
        $remediationResponse = Invoke-RestMethod -Method Get -Uri $remediationEndpoint -Headers $headers
        $results += [PSCustomObject]@{
            Category     = "Remediation"
            SubmissionId = $item.id
            Action       = $remediationResponse.action
            Status       = $remediationResponse.status
            RemediatedBy = $remediationResponse.remediatedBy
        }
    } catch {
        Write-Host "No remediation data for submission ID: $($item.id)"
    }
}

# Retrieve policy summaries (example: Safe Links policy summary)
$policyEndpoint = "https://graph.microsoft.com/beta/security/threatPolicy"
try {
    $policyResponse = Invoke-RestMethod -Method Get -Uri $policyEndpoint -Headers $headers
    foreach ($policy in $policyResponse.value) {
        $results += [PSCustomObject]@{
            Category     = "Policy Summary"
            PolicyId     = $policy.id
            DisplayName  = $policy.displayName
            Description  = $policy.description
            LastModified = $policy.lastModifiedDateTime
        }
    }
} catch {
    Write-Host "Policy summary endpoint not available or insufficient permissions."
}

# Export to CSV
$results | Export-Csv -Path "DefenderATP_FullReport_$timestamp.csv" -NoTypeInformation -Encoding UTF8
Write-Host "? Full ATP Email Security Report generated: DefenderATP_FullReport_$timestamp.csv"




