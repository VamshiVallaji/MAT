$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name



# Connect to Exchange Online
Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization




# Create a results array
$results = @()

# --- Safe Attachments ---
$safeAttachments = Get-SafeAttachmentPolicy
foreach ($p in $safeAttachments) {
    $results += [PSCustomObject]@{
        PolicyType = "SafeAttachments"
        Name = $p.Name
        Enabled = $p.Enable
        Action = $p.Action
        Redirect = $p.Redirect
        RedirectAddr = $p.RedirectAddress
        SafeDocs = $p.EnableSafeDocs
        ForODSPT = "SPO:$($p.EnableSafeAttachmentsForSharePoint) | ODB:$($p.EnableSafeAttachmentsForOneDrive) | Teams:$($p.EnableSafeAttachmentsForTeams)"
        Priority = $p.Priority
        # Placeholders for other policy columns
        TrackClicks = $null
        EnableATP = $null
        SpamAction = $null
    }
}
# --- Safe Links ---
$safeLinks = Get-SafeLinksPolicy
foreach ($p in $safeLinks) {
    $results += [PSCustomObject]@{
        PolicyType = "SafeLinks"
        Name = $p.Name
        Enabled = $p.Enable
        Action = $null
        Redirect = $null
        RedirectAddr = $null
        SafeDocs = $null
        ForODSPT = $null
        Priority = $p.Priority
        # SafeLinks specific
        TrackClicks = $p.TrackClicks
        EnableATP = $p.EnableSafeLinksForInternalSenders
        SpamAction = $null
    }
}
# --- AntiPhish ---
$antiPhish = Get-AntiPhishPolicy
foreach ($p in $antiPhish) {
    $results += [PSCustomObject]@{
        PolicyType = "AntiPhish"
        Name = $p.Name
        Enabled = $p.Enable
        Action = $p.PhishThresholdLevel
        Redirect = $null
        RedirectAddr = $null
        SafeDocs = $null
        ForODSPT = $null
        Priority = $p.Priority
        TrackClicks = $null
        EnableATP = $null
        SpamAction = $null
    }
}
# --- Malware Filter ---
$malware = Get-MalwareFilterPolicy
foreach ($p in $malware) {
    $results += [PSCustomObject]@{
        PolicyType = "MalwareFilter"
        Name = $p.Name
        Enabled = $p.EnableFileFilter
        Action = $p.Action
        Redirect = $p.RedirectEnabled
        RedirectAddr = $p.RedirectAddress
        SafeDocs = $null
        ForODSPT = $null
        Priority = $null
        TrackClicks = $null
        EnableATP = $null
        SpamAction = $null
    }
}
# --- Inbound Spam ---
$inboundSpam = Get-HostedContentFilterPolicy
foreach ($p in $inboundSpam) {
    $results += [PSCustomObject]@{
        PolicyType = "InboundSpam"
        Name = $p.Name
        Enabled = $null
        Action = $null
        Redirect = $null
        RedirectAddr = $null
        SafeDocs = $null
        ForODSPT = $null
        Priority = $null
        TrackClicks = $null
        EnableATP = $null
        SpamAction = $p.SpamAction
    }
}
# --- Outbound Spam ---
$outboundSpam = Get-HostedOutboundSpamFilterPolicy
foreach ($p in $outboundSpam) {
    $results += [PSCustomObject]@{
        PolicyType = "OutboundSpam"
        Name = $p.Name
        Enabled = $null
        Action = $null
        Redirect = $null
        RedirectAddr = $null
        SafeDocs = $null
        ForODSPT = $null
        Priority = $null
        TrackClicks = $null
        EnableATP = $null
        SpamAction = $p.ActionWhenThresholdReached
    }
}



# --- Export CSV ---
$results | Export-Csv -Path "ATP_EmailSecurity_Report_$timestamp.csv" -NoTypeInformation -Encoding UTF8

Write-Host "? Report generated: ATP_EmailSecurity_Report_$timestamp.csv"




