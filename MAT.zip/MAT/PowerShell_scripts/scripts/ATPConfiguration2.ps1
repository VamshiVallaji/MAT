$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name



# Connect to Exchange Online
Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization




# Create a results array
$report = @()

# --- Safe Links ---
Get-SafeLinksPolicy | ForEach-Object {
    $_ | Select-Object *, @{Name="PolicyType";Expression={"SafeLinks"}}
} | ForEach-Object { $report += $_ }

# --- Safe Attachments ---
Get-SafeAttachmentPolicy | ForEach-Object {
    $_ | Select-Object *, @{Name="PolicyType";Expression={"SafeAttachments"}}
} | ForEach-Object { $report += $_ }

# --- Anti-Phish ---
Get-AntiPhishPolicy | ForEach-Object {
    $_ | Select-Object *, @{Name="PolicyType";Expression={"AntiPhish"}}
} | ForEach-Object { $report += $_ }

# --- Malware Filter ---
Get-MalwareFilterPolicy | ForEach-Object {
    $_ | Select-Object *, @{Name="PolicyType";Expression={"MalwareFilter"}}
} | ForEach-Object { $report += $_ }

# --- Inbound Spam (Content Filter) ---
Get-HostedContentFilterPolicy | ForEach-Object {
    $_ | Select-Object *, @{Name="PolicyType";Expression={"InboundSpam"}}
} | ForEach-Object { $report += $_ }

# --- Outbound Spam ---
Get-HostedOutboundSpamFilterPolicy | ForEach-Object {
    $_ | Select-Object *, @{Name="PolicyType";Expression={"OutboundSpam"}}
} | ForEach-Object { $report += $_ }


$allProps = $report[0].psobject.Properties.Name
$reversedProps = [System.Collections.ArrayList]@($allProps)
$reversedProps.Reverse()



# --- Export CSV ---
$reportPath = "$network_drive\Exchange\ATPConfiguration\ATP_EmailSecurity_Report_$timestamp.csv"

$report | Select-Object $reversedProps | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "Report generated: ATP_EmailSecurity_Report_$timestamp.csv"




