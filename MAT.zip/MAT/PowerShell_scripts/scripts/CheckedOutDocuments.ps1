$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\CheckedOutDocuments\CheckedOutDocuments_Report_$timestamp.csv"

$Report = @()

# ================================
# Get all Site Collections (excluding OneDrive, can include if needed)
# ================================
$Sites = Get-PnPTenantSite -IncludeOneDriveSites:$false -Filter "Url -like 'sharepoint.com/sites/'"

foreach ($Site in $Sites) {
    Write-Host "?? Connecting to Site: $($Site.Url)" -ForegroundColor Cyan

    try {
        # Connect to each site
        Connect-PnPOnline -Url $Site.Url -ClientId $ClientId -Thumbprint $Thumbprint -Tenant $tenantId

        # Get document libraries
        $Libraries = Get-PnPList | Where-Object { $_.BaseTemplate -eq 101 -and $_.Hidden -eq $false }

        foreach ($Library in $Libraries) {
            Write-Host " ?? Library: $($Library.Title)" -ForegroundColor Yellow

            # Get all items in library
            $Files = Get-PnPListItem -List $Library.Title -PageSize 500 `
                -Fields FileLeafRef, FileRef, CheckoutUser, Editor, Author, Created, Modified, 
                        FileSizeDisplay, ContentType, File_x0020_Type, Title

            foreach ($File in $Files) {
                if ($File["CheckoutUser"] -ne $null) {
                    
                    # Try to get checkout date
                    $CheckedOutDate = $null
                    if ($File.FieldValues.ContainsKey("CheckoutDate")) {
                        $CheckedOutDate = $File["CheckoutDate"]
                    } else {
                        # fallback if not available
                        $CheckedOutDate = $File["Modified"]
                    }

                    $Report += [PSCustomObject]@{
                        SiteUrl = $Site.Url
                        Library = $Library.Title
                        FileName = $File["FileLeafRef"]
                        Title = $File["Title"]
                        FileType = $File["File_x0020_Type"]
                        ContentType = $File["ContentType"].Name
                        FileSize = $File["FileSizeDisplay"]

                        # Checked out details
                        CheckedOutBy = $File["CheckoutUser"].Email
                        CheckedOutById = $File["CheckoutUser"].LookupId
                        CheckedOutDate = $CheckedOutDate

                        # Author / Modified info
                        CreatedBy = $File["Author"].Email
                        CreatedDate = $File["Created"]
                        ModifiedBy = $File["Editor"].Email
                        ModifiedDate = $File["Modified"]

                        # Full File URL
                        FileUrl = "$($Site.Url)$($File['FileRef'])"
                    }
                }
            }
        }
    }
    catch {
        Write-Host "?? Failed to process site: $($Site.Url) - $_" -ForegroundColor Red
    }
}

# ================================
# Export to CSV
# ================================
if ($Report.Count -gt 0) {
    $Report | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8
    Write-Host "? Report generated successfully: $reportPath" -ForegroundColor Green
} else {
    Write-Host "?? No checked out documents found across tenant" -ForegroundColor Yellow
}




