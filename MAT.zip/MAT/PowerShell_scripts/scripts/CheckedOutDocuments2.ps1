$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\CheckedOutDocuments\CheckedOutDocuments_Report_$timestamp.csv"



# Get all site collections (excluding OneDrive)
$sites = Get-PnPTenantSite -IncludeOneDriveSites:$false

$report = @()

foreach ($site in $sites) {
    Write-Host "Scanning site: $($site.Url)" -ForegroundColor Cyan

    try {
        # Connect to each site
        Connect-PnPOnline -Url $site.Url `
         -ClientId $ClientId `
         -Tenant $tenantId `
         -Thumbprint $Thumbprint

        # Get all document libraries (BaseTemplate 101)
        $lists = Get-PnPList | Where-Object { $_.BaseTemplate -eq 101 -and $_.Hidden -eq $false }

        $checkedOutCount = 0

        foreach ($list in $lists) {
            # CAML query to find checked-out items
            $caml = @"
<View Scope='RecursiveAll'>
  <Query>
    <Where>
      <IsNotNull>
        <FieldRef Name='CheckoutUser' />
      </IsNotNull>
    </Where>
  </Query>
</View>
"@

            $items = Get-PnPListItem -List $list.Title -Query $caml -PageSize 1000
            $checkedOutCount += $items.Count
        }

        # Add result to report
        $report += [PSCustomObject]@{
            SiteUrl = $site.Url
            SiteTitle = $site.Title
            CheckedOutDocuments = $checkedOutCount
        }
    }
    catch {
        Write-Warning "Error processing $($site.Url): $_"
    }
}

# Export to CSV
$report | Export-Csv -Path $reportPath -NoTypeInformation


