$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\CheckedOutFiles\CheckedOutFiles_Report_$timestamp.csv"


# Get all site collections
$sites = Get-PnPTenantSite | Where-Object { $_.Url -notlike "*-my.sharepoint.com*" }

# Prepare output
$report = @()

foreach ($site in $sites) {
    Write-Host "?? Checking site: $($site.Url)" -ForegroundColor Cyan

    try {
        Connect-PnPOnline -Url $site.Url -ClientId $ClientId -Tenant $tenantId -Thumbprint $Thumbprint

        # Get all document libraries
        $libraries = Get-PnPList | Where-Object { $_.BaseTemplate -eq 101 -and $_.Hidden -eq $false }

        foreach ($library in $libraries) {
            $items = Get-PnPListItem -List $library.Title -PageSize 1000 -Fields "FileLeafRef", "Editor", "CheckoutUser", "Modified", "FileRef"

            foreach ($item in $items) {
                if ($item["CheckoutUser"]) {
                    $report += [PSCustomObject]@{
                        SiteUrl        = $site.Url
                        LibraryTitle   = $library.Title
                        FileName       = $item["FileLeafRef"]
                        FileUrl        = $item["FileRef"]
                        CheckedOutBy   = $item["CheckoutUser"].LookupValue
                        LastModified   = $item["Modified"]
                        Editor         = $item["Editor"].LookupValue
                    }
                }
            }
        }
    } catch {
        Write-Warning "? Failed to connect or retrieve data from site: $($site.Url)"
    }
}

# Export to CSV
$report | Export-Csv -Path $reportPath -NoTypeInformation

Write-Host "? Report generated: CheckedOutFilesReport_$timestamp.csv"







