$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\Custom_Features\Custom_Features_Report_$timestamp.csv"


# Get all site collections
$sites = Get-PnPTenantSite

# Initialize report array
$customFeaturesReport = @()

foreach ($site in $sites) {
    try {
        # Connect to individual site
        Connect-PnPOnline -Url $site.Url -ClientId $ClientId -Tenant $tenantId -Thumbprint $Thumbprint

        $web = Get-PnPWeb
        $siteFeatures = Get-PnPFeature -Scope Site -ErrorAction SilentlyContinue
        $webFeatures = Get-PnPFeature -Scope Web -ErrorAction SilentlyContinue

        $allFeatures = $siteFeatures + $webFeatures

        foreach ($feature in $allFeatures) {
            $customFeaturesReport += [PSCustomObject]@{
                SiteUrl              = $site.Url
                Title                = $site.Title
                Template             = $site.Template
                FeatureScope         = $feature.Scope
                FeatureDisplayName   = $feature.DisplayName
                FeatureId            = $feature.Id
                FeatureDefinitionId  = $feature.DefinitionId
                FeatureVersion       = $feature.Version
                FeatureActivated     = $feature.Activated
            }
        }

        # Optionally add a summary row per site
   #     $customFeaturesReport += [PSCustomObject]@{
    #        SiteUrl              = $site.Url
     #       Title                = $site.Title
      #      Template             = $site.Template
       #     FeatureScope         = "Summary"
        #    FeatureDisplayName   = "Total Features"
         #   FeatureId            = ""
          #  FeatureDefinitionId  = ""
           # FeatureVersion       = ""
          #  FeatureActivated     = $allFeatures.Count
      #  }

    } catch {
        Write-Warning "?? Error processing site $($site.Url): $($_.Exception.Message)"
    }
}

# Export to CSV
$customFeaturesReport | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "? Custom Features Report generated: CustomFeaturesReport_$timestamp.csv"




