$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\Custom_Features_Summary\Custom_Features_Summary_Report_$timestamp.csv"


# Get all site collections
$sites = Get-PnPTenantSite

# Initialize report array
$featureSummaryReport = @()

foreach ($site in $sites) {
    try {
        # Connect to individual site
        Connect-PnPOnline -Url $site.Url -ClientId $ClientId -Tenant $tenantId -Thumbprint $Thumbprint

        # Get features at both Site and Web scope
        $siteFeatures = Get-PnPFeature -Scope Site -ErrorAction SilentlyContinue
        $webFeatures  = Get-PnPFeature -Scope Web  -ErrorAction SilentlyContinue

        $allFeatures = $siteFeatures + $webFeatures
        $activatedCount = ($allFeatures | Where-Object { $_.Activated -eq $true }).Count

        # Add summary to report
        $featureSummaryReport += [PSCustomObject]@{
            SiteUrl           = $site.Url
            TotalFeatures     = $allFeatures.Count
            ActivatedFeatures = $activatedCount
        }

    } catch {
        Write-Warning "?? Error processing site $($site.Url): $($_.Exception.Message)"
    }
}

# Output the report
#$featureSummaryReport | Format-Table -AutoSize




# Export to CSV
$featureSummaryReport | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

#Write-Host "? Custom Features Report generated: CustomFeatures_CouReport_$timestamp.csv"




