$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\Custom_MasterPages&PageLayouts\Custom_MasterPages&PageLayouts_Report_$timestamp.csv"



# Get all site collections (excluding OneDrive and App sites)
$sites = Get-PnPTenantSite | Where-Object {
    $_.Url -notlike "*-my.sharepoint.com*" -and $_.Url -notlike "*apps.sharepoint.com*"
}

# Prepare report array
$report = @()

foreach ($site in $sites) {
    Write-Host "?? Scanning site: $($site.Url)"

    try {
        # Connect to each site
        #Connect-PnPOnline -Url $site.Url -Interactive
        Connect-PnPOnline -Url $site.Url `
        -ClientId $ClientId `
        -Tenant $tenantId `
        -Thumbprint $Thumbprint

        # Get items from Master Page Gallery
        $items = Get-PnPListItem -List "Master Page Gallery" -PageSize 500 -Fields "FileLeafRef", "FileRef", "File_x0020_Size", "Created", "Author", "Modified", "Editor", "CheckOutUser", "ContentType", "ApprovalStatus", "PublishingStartDate", "PublishingExpirationDate", "HasUniqueRoleAssignments", "FileType", "FSObjType", "Title", "Version", "_UIVersionString", "FileDirRef", "File_x0020_Type", "File_x0020_Status", "File_x0020_Type", "File_x0020_Size"

        foreach ($item in $items) {
            $fileName = $item["FileLeafRef"]
            if ($fileName -like "*.master" -or $fileName -like "*.aspx") {
                $report += [PSCustomObject]@{
                    SiteURL               = $site.Url
                    FileName              = $fileName
                    FileType              = $item["File_x0020_Type"]
                    FileSizeKB            = [math]::Round($item["File_x0020_Size"] / 1024, 2)
                    ServerRelativeURL     = $item["FileRef"]
                    Title                 = $item["Title"]
                    ContentType           = $item["ContentType"]
                    Created               = $item["Created"]
                    CreatedBy             = $item["Author"].Email
                    Modified              = $item["Modified"]
                    ModifiedBy            = $item["Editor"].Email
                    CheckedOutTo          = $item["CheckOutUser"]?.Email
                    ApprovalStatus        = $item["ApprovalStatus"]
                    PublishingStartDate   = $item["PublishingStartDate"]
                    PublishingExpiration  = $item["PublishingExpirationDate"]
                    HasUniquePermissions  = $item["HasUniqueRoleAssignments"]
                    Version               = $item["Version"]
                    UIVersion             = $item["_UIVersionString"]
                    Directory             = $item["FileDirRef"]
                    FileStatus            = $item["File_x0020_Status"]
                }
            }
        }
    } catch {
        Write-Host "? Error accessing $($site.Url): $_"
    }
}

# Display report
$report | Format-Table -AutoSize

# Optional: Export to CSV
# $report | Export-Csv -Path $reportPath -NoTypeInformation
