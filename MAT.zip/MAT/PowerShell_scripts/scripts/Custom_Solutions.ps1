$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\Custom_Solutions\Custom_Solutions_Report_$timestamp.csv"




# Get all site collections
$sites = Get-PnPTenantSite

# Initialize report array
$customSolutionReport = @()

foreach ($site in $sites) {
    try {
        # Connect to individual site
        Connect-PnPOnline -Url $site.Url -ClientId $ClientId -Tenant $tenantId -Thumbprint $Thumbprint

        $web = Get-PnPWeb
        $siteDesigns = Get-PnPSiteDesignRun -WebUrl $site.Url -ErrorAction SilentlyContinue
        $customActions = Get-PnPCustomAction -Scope Site, Web -ErrorAction SilentlyContinue
        $alternateCss = $web.AlternateCssUrl
        $masterPage = $web.MasterUrl
        $apps = Get-PnPApp -Scope Site -ErrorAction SilentlyContinue
        #$sandboxSolutions = Get-PnPProperty -ClientObject $web.Solutions -Property Solutions -ErrorAction SilentlyContinue

        # Check for custom web parts
        $webParts = Get-PnPWebPart -Page "SitePages/Home.aspx" -ErrorAction SilentlyContinue
        $hasCustomWebParts = $webParts | Where-Object { $_.Type -like "*ScriptEditor*" -or $_.Type -like "*ContentEditor*" }

        $customSolutionReport += [PSCustomObject]@{
            SiteUrl                  = $site.Url
            Title                    = $site.Title
            Template                 = $site.Template
            CustomScriptStatus       = if ($site.DenyAddAndCustomizePages -eq $false) { "Enabled" } else { "Disabled" }
            SiteDesignsApplied       = ($siteDesigns | Select-Object -ExpandProperty SiteDesignId) -join "; "
            HasCustomWebParts        = if ($hasCustomWebParts) { "Yes" } else { "No" }
            HasUserCustomActions     = if ($customActions.Count -gt 0) { "Yes" } else { "No" }
            MasterPageCustomization  = if ($masterPage -ne "/_catalogs/masterpage/seattle.master") { "Yes" } else { "No" }
            AlternateCSS             = if ($alternateCss) { $alternateCss } else { "None" }
            HasAppInstalled          = if ($apps.Count -gt 0) { "Yes" } else { "No" }
            SandboxSolutionsPresent  = "Not Applicable"
        }
    } catch {
        Write-Warning "?? Error processing site $($site.Url): $($_.Exception.Message)"
    }
}

# Export to CSV
$customSolutionReport | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "? Custom Solution Report generated: CustomSolutionReport_$timestamp.csv"




