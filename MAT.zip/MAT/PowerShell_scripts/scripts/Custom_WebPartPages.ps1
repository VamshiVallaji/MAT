$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\Custom_Web_Part_Pages\Custom_WebPartPages_Report_$timestamp.csv"



# Get all site collections (excluding OneDrive and system sites)
$sites = Get-PnPTenantSite | Where-Object {
    $_.Url -notlike "*-my.sharepoint.com*"

    }

# Prepare report
$report = @()

foreach ($site in $sites) {
    Write-Host "Scanning site: $($site.Url)" -ForegroundColor Cyan

    Connect-PnPOnline -Url $site.Url `
        -ClientId $ClientId `
        -Tenant $tenantId `
        -Thumbprint $Thumbprint

    try {
        $pages = Get-PnPListItem -List "Site Pages" -PageSize 1000
    } catch {
        Write-Host "Site Pages library not found in $($site.Url)" -ForegroundColor Yellow
        continue
    }

    foreach ($page in $pages) {
        $fileName = $page.FieldValues["FileLeafRef"]
        if ($fileName -like "*.aspx") {
            $report += [PSCustomObject]@{
                SiteURL            = $site.Url
                Title              = $page.FieldValues["Title"]
                FileName           = $fileName
                FileURL            = $page.FieldValues["FileRef"]
                Created            = $page.FieldValues["Created"]
                Modified           = $page.FieldValues["Modified"]
                CreatedBy          = if ($page.FieldValues["Author"]) { $page.FieldValues["Author"].Email } else { "Unknown" }
                ModifiedBy         = if ($page.FieldValues["Editor"]) { $page.FieldValues["Editor"].Email } else { "Unknown" }
                CheckedOutTo       = if ($page.FieldValues["CheckoutUser"]) { $page.FieldValues["CheckoutUser"].Email } else { "Not Checked Out" }
                FileSize           = $page.FieldValues["File_x0020_Size"]
                ContentType        = $page.FieldValues["ContentType"]
                Version            = $page.FieldValues["OData__UIVersionString"]
                ApprovalStatus     = $page.FieldValues["ApprovalStatus"]
                CommentsEnabled    = if ($page.FieldValues["CommentsDisabled"] -eq $false) { "Yes" } else { "No" }
                PublishingStatus   = if ($page.FieldValues["PublishingPageContent"]) { "Published" } else { "Draft/Empty" }
                PageLayoutType     = $page.FieldValues["PageLayoutType"]
                PromotedState      = $page.FieldValues["PromotedState"]
                FirstPublishedDate = $page.FieldValues["FirstPublishedDate"]
            }
        }
    }
}

# Display or export
#$report | Format-Table -AutoSize
$report | Export-Csv -Path $reportPath -NoTypeInformation


