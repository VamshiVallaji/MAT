$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint
$tenantId     = "e9c255e0-7344-4dd3-b700-76c1d79f7bbc"
$clientId     = "a0f545dd-9c85-4b46-a95d-40b393044a19"
$clientSecret = "zNk8Q~VxfIv9G7RHtxTYfRYljcCwUK_EoylRBddw"

$secureSecret = ConvertTo-SecureString $clientSecret -AsPlainText -Force

# ===============================
# Connect to Compliance Center
# ===============================
Write-Host "?? Connecting to Security & Compliance Center..." -ForegroundColor Cyan
Connect-IPPSSession -AppId $AppId -Organization $TenantId -ClientSecret $SecureSecret

# ===============================
# Fetch DLP Policies & Rules
# ===============================
Write-Host "?? Fetching DLP Policies & Rules..." -ForegroundColor Cyan

$dlpPolicies = Get-DlpCompliancePolicy -IncludeRulesMetadata -ErrorAction Stop
$dlpRules = Get-DlpComplianceRule -ErrorAction Stop

# ===============================
# Combine Policy + Rule Data
# ===============================
$report = foreach ($rule in $dlpRules) {
    $policy = $dlpPolicies | Where-Object { $_.Name -eq $rule.Policy }

    [PSCustomObject]@{
        PolicyName = $policy.Name
        PolicyState = $policy.State
        PolicyMode = $policy.Mode
        PolicyDescription = $policy.Description
        ExchangeLocation = ($policy.ExchangeLocation -join "; ")
        SharePointLocation= ($policy.SharePointLocation -join "; ")
        OneDriveLocation = ($policy.OneDriveLocation -join "; ")
        TeamsLocation = ($policy.TeamsLocation -join "; ")
        RuleName = $rule.Name
        RuleMode = $rule.Mode
        SensitiveInfo = ($rule.ContentContainsSensitiveInformation -join "; ")
        BlockAccess = $rule.BlockAccess
        NotifyUser = ($rule.NotifyUser -join "; ")
        IncidentReport = $rule.GenerateIncidentReport
    }
}

# ===============================
# Export Combined Report
# ===============================
$csvPath = "$ExportPath\DLP_Full_Report_$timestamp.csv"
$report | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8

Write-Host "? DLP Full Report exported to $csvPath" -ForegroundColor Green

# ===============================
# Disconnect Session
# ===============================
Disconnect-IPPSSession
Write-Host "?? Disconnected from Compliance Center" -ForegroundColor Yellow




