$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\Deprecated_Site_Template\Deprecated_Site_Template_Report_$timestamp.csv"


# Define supported modern templates (based on Microsoft documentation)
$supportedTemplates = @(
    "STS#3",                    # Modern Team Site
    "GROUP#0",                  # Office 365 Group Site
    "SITEPAGEPUBLISHING#0",     # Communication Site
    "COMM#0"                    # Communication Site (alternate ID)
)

# Get all sites in the tenant (excluding OneDrive)
$allSites = Get-PnPTenantSite -IncludeOneDriveSites:$false

# Identify sites using templates NOT in the supported list
$deprecatedSites = $allSites | Where-Object {
    $supportedTemplates -notcontains $_.Template
}

# Optional: Add a custom column to flag deprecated status
$deprecatedSitesWithFlag = $deprecatedSites | Select-Object *, @{Name="IsDeprecated"; Expression={"Yes"}}

# Export all attributes to CSV
$deprecatedSitesWithFlag | Export-Csv -Path $reportPath -NoTypeInformation







