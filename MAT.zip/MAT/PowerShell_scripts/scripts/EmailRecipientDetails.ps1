$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name



# Connect to Exchange Online
Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

# Connect to Exchange Online
# Connect-ExchangeOnline -UserPrincipalName youradmin@domain.com

$reportPath = "$network_drive\Exchange\RecipientDetails\RecipientDetails_Report_$timestamp.csv"
$Result = @()

$recipients = Get-Recipient -ResultSize Unlimited

foreach ($recipient in $recipients) {
    $mailbox = Get-Mailbox -Identity $recipient.Identity -ErrorAction SilentlyContinue

    $Result += [PSCustomObject]@{
        PrimarySmtpAddress              = $recipient.PrimarySmtpAddress
        RecipientType                   = $recipient.RecipientType
        RecipientTypeDetails            = $recipient.RecipientTypeDetails
        Identity                        = $recipient.Identity
        Alias                           = $recipient.Alias
        ArchiveGuid                     = $mailbox.ArchiveGuid
        ExternalEmailAddress            = $recipient.ExternalEmailAddress
        DisplayName                     = $recipient.DisplayName
        FirstName                       = $recipient.FirstName
        HiddenFromAddressListsEnabled   = $recipient.HiddenFromAddressListsEnabled
        LastName                        = $recipient.LastName
        Manager                         = $recipient.Manager
        Name                            = $recipient.Name
        OrganizationalUnit              = $recipient.OrganizationalUnit
        SamAccountName                  = $recipient.SamAccountName
        WhenMailboxCreated              = $mailbox.WhenMailboxCreated
        DistinguishedName               = $recipient.DistinguishedName
        WhenCreated                     = $recipient.WhenCreated
        Status                          = if ($mailbox -ne $null) { "Mailbox" } else { "Non-Mailbox" }
    }
}

# Export to CSV
$Result | Export-Csv -Path $reportPath -NoTypeInformation




