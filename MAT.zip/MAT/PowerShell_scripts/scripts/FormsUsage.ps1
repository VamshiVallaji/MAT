$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint
$secret = $config.AppSecret


#Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
#$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

#$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
#Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
 #   -ClientId $ClientId `
   # -Tenant $tenantId `
    #-Thumbprint $Thumbprint 





# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization


$reportPath = "$network_drive\Sharepoint\Forms_Usage\Forms_Usage_Report_$timestamp.csv"

$Scope = "https://graph.microsoft.com/.default"
$AuthUrl = "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token"

# Request access token
$Body = @{
    client_id = $ClientId
    scope = $Scope
    client_secret = $secret
    grant_type = "client_credentials"
}

$TokenResponse = Invoke-RestMethod -Method POST -Uri $AuthUrl -Body $Body
$AccessToken = $TokenResponse.access_token

# Period can be D7, D30, D90, D180
$Period = "D30"
$Uri = "https://graph.microsoft.com/beta/reports/getFormsUserActivityUserDetail(period='$Period')"

# Call Graph API with bearer token
$Headers = @{ Authorization = "Bearer $AccessToken" }

#Invoke-WebRequest -Method Get -Uri $Uri -Headers $Headers -OutFile $report


$response = Invoke-RestMethod -Method GET -Uri $Uri -Headers $Headers

$report = $response.value | ForEach-Object {
    $user = $_
    foreach ($period in $user.formsUsageUserDetailsByPeriod) {
        [PSCustomObject]@{
            UserPrincipalName = $user.userPrincipalName
            LastActivityDate  = $user.lastActivityDate
            ReportPeriod      = $period.reportPeriod
            CreatedCount      = $period.createdCount
            RespondedCount    = $period.respondedCount
        }
    }
}

# Export clean CSV
$report | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8






# Save as CSV
#$outputPath = "FormsUserActivityDetail_$Period.csv"
#$response.value | Export-Csv -Path $reportPath -NoTypeInformation


#$response = Invoke-WebRequest -Uri $Uri -Headers $Headers -Method Get -MaximumRedirection 0 -ErrorAction SilentlyContinue

# Extract CSV download URL
#$downloadUrl = $response.Headers["Location"]

#if ($downloadUrl) {
    # Download the CSV file
 #   Invoke-WebRequest -Uri $downloadUrl -OutFile $reportPath
  #  Write-Host "Onedrive usage report exported to $reportPath"
#} else {
 #   Write-Host "No download URL found. Check token and permissions."##


#Write-Host "Report saved to $reportPath"
