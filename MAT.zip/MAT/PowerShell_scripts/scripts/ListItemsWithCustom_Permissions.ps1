$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\ListItemsWithCustom_Permissions\ListItemsWithCustom_Permissions_Report_$timestamp.csv"



# Get all site collections (filter if needed)
$sites = Get-PnPTenantSite -IncludeOneDriveSites:$false

# Prepare final report
$finalReport = @()

foreach ($site in $sites) {
    Write-Host "Scanning site: $($site.Url)" -ForegroundColor Cyan

    # Connect to each site
    Connect-PnPOnline -Url $site.Url `
        -ClientId $ClientId `
        -Tenant $tenantId `
        -Thumbprint $Thumbprint

    # Get all lists (you can filter for document libraries only)
    $lists = Get-PnPList | Where-Object { $_.BaseTemplate -eq 101 -and $_.Hidden -eq $false }  # 101 = Document Library

    foreach ($list in $lists) {
        Write-Host "  ? Checking list: $($list.Title)"

        $items = Get-PnPListItem -List $list.Title -PageSize 1000

        foreach ($item in $items) {
            if ($item.HasUniqueRoleAssignments) {
                $roles = Get-PnPProperty -ClientObject $item -Property RoleAssignments
                foreach ($role in $roles) {
                    $member = Get-PnPProperty -ClientObject $role -Property Member
                    $roleDef = Get-PnPProperty -ClientObject $role -Property RoleDefinitionBindings

                    foreach ($def in $roleDef) {
                        $finalReport += [PSCustomObject]@{
                            SiteURL       = $site.Url
                            ListTitle     = $list.Title
                            ItemID        = $item.Id
                            Title         = $item["Title"]
                            FileRef       = $item["FileRef"]
                            ContentType   = $item["ContentType"]
                            Modified      = $item["Modified"]
                            Editor        = $item["Editor"]
                            HasUniquePerm = $true
                            Principal     = $member.Title
                            PrincipalType = $member.PrincipalType
                            Role          = $def.Name
                        }
                    }
                }
            }
        }
    }
}

# Output to console or export
#$finalReport | Format-Table -AutoSize
# Optional: Export to CSV
$finalReport | Export-Csv -Path $reportPath -NoTypeInformation





