$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\ListViewsApproachingRecommendedThresholds\ListViews_Approaching_Thresholds_$timestamp.csv"



# Get all site collections
$sites = Get-PnPTenantSite

# Threshold definition
$threshold = 5000
$warningLevel = $threshold * 0.2

# Prepare report
$report = @()

foreach ($site in $sites) {
    Write-Host "?? Scanning site: $($site.Url)" -ForegroundColor Cyan

    try {
        Connect-PnPOnline -Url $site.Url `
        -ClientId $ClientId `
        -Tenant $tenantId `
        -Thumbprint $Thumbprint

        $lists = Get-PnPList

        foreach ($list in $lists) {
            if ($list.ItemCount -ge $warningLevel) {
                $report += [PSCustomObject]@{
                    SiteUrl                  = $site.Url
                    ListTitle                = $list.Title
                    ListId                   = $list.Id
                    ItemCount                = $list.ItemCount
                    ApproachingThreshold     = if ($list.ItemCount -ge $threshold) { "Exceeded" } else { "Approaching" }
                    BaseTemplate             = $list.BaseTemplate
                    BaseType                 = $list.BaseType
                    Created                  = $list.Created
                    LastModified             = $list.LastItemModifiedDate
                    LastDeleted              = $list.LastItemDeletedDate
                    Hidden                   = $list.Hidden
                    EnableVersioning         = $list.EnableVersioning
                    EnableMinorVersions      = $list.EnableMinorVersions
                    EnableModeration         = $list.EnableModeration
                    EnableAttachments        = $list.EnableAttachments
                    EnableFolderCreation     = $list.EnableFolderCreation
                    ContentTypesEnabled      = $list.ContentTypesEnabled
                    DefaultViewUrl           = $list.DefaultViewUrl
                    RootFolderServerRelativeUrl = $list.RootFolder.ServerRelativeUrl
                    RootFolderItemCount      = $list.RootFolder.ItemCount
                    RootFolderSize           = $list.RootFolder.Size
                    HasUniqueRoleAssignments = $list.HasUniqueRoleAssignments
                    NoCrawl                  = $list.NoCrawl
                    IsApplicationList        = $list.IsApplicationList
                    IsCatalog                = $list.IsCatalog
                    IsSiteAssetsLibrary      = $list.IsSiteAssetsLibrary
                    IsSystemList             = $list.IsSystemList
                    IsPrivate                = $list.IsPrivate
                }
            }
        }
    } catch {
        Write-Warning "?? Could not process site: $($site.Url)"
    }
}

$report | Export-Csv -Path $reportPath -NoTypeInformation

Write-Host "? Report generated: $reportPath"





