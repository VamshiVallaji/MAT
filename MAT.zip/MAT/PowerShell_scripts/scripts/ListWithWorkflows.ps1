$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint
# Authentication details
$tenantId    = "e9c255e0-7344-4dd3-b700-76c1d79f7bbc"
$clientId    = "a0f545dd-9c85-4b46-a95d-40b393044a19"
$thumbprint  = "BE8651CCFBE25546E70D14F1EE544D291C6D30F0"

# Connect to Microsoft Graph to get tenant name
Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object { $_.isInitial -eq $true } | Select-Object -ExpandProperty Name
$TenantName = $Organization.Split(".")[0]

# Connect to SharePoint Admin Center
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $clientId `
    -Tenant $tenantId `
    -Thumbprint $thumbprint

# Report path
$reportPath = "$network_drive\Sharepoint\ListWithWorkflows\ListsWithWorkflows_Report_$timestamp.csv"
$combinedReport = @()

# Get all site collections
$sites = Get-PnPTenantSite

foreach ($site in $sites) {
    Write-Host "?? Scanning site: $($site.Url)"
    Connect-PnPOnline -Url $site.Url `
        -ClientId $clientId `
        -Tenant $tenantId `
        -Thumbprint $thumbprint

    $lists = Get-PnPList | Where-Object { $_.Hidden -eq $false }

    foreach ($list in $lists) {
        $ctx = Get-PnPContext
        $ctx.Load($list.WorkflowAssociations)
        $ctx.ExecuteQuery()

        if ($list.WorkflowAssociations.Count -gt 0) {
            foreach ($workflow in $list.WorkflowAssociations) {
                $combinedReport += [PSCustomObject]@{
                    Source        = "SharePoint Designer"
                    SiteUrl       = $site.Url
                    ListTitle     = $list.Title
                    WorkflowName  = $workflow.Name
                    WorkflowType  = $workflow.BaseId
                    Enabled       = $workflow.Enabled
                    Created       = $workflow.Created
                    Modified      = $workflow.Modified
                    Creator       = "N/A"
                    TriggerType   = "N/A"
                }
            }
        }
    }
}



# If no workflows found, create an empty object with headers
if ($combinedReport.Count -eq 0) {
    $combinedReport += [PSCustomObject]@{
        Source        = ""
        SiteUrl       = ""
        ListTitle     = ""
        WorkflowName  = ""
        WorkflowType  = ""
        Enabled       = ""
        Created       = ""
        Modified      = ""
        Creator       = ""
        TriggerType   = ""
    }
}


# Export to CSV
$combinedReport | Export-Csv -Path $reportPath -NoTypeInformation
Write-Host "? Report generated: $reportPath"






