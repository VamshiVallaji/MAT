$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome

$reportPath = "$network_drive\Teams\ListOfTeams\List_of_Teams_$timestamp.csv"




# Get all Microsoft 365 Groups that are Teams-enabled
$teamsGroups = Get-MgGroup -Filter "resourceProvisioningOptions/Any(x:x eq 'Team')" -All

$report = @()

foreach ($group in $teamsGroups) {
    # Get basic team details
    $team = Get-MgTeam -TeamId $group.Id

    # Get team owners
    $owners = Get-MgGroupOwner -GroupId $group.Id
    $ownerNames = ($owners | ForEach-Object { $_.DisplayName }) -join ", "


    # Build report entry
    $report += [PSCustomObject]@{
        TeamName           = $group.DisplayName
        TeamId             = $group.Id
        Description        = $group.Description
        Visibility         = $group.Visibility
        CreatedDateTime    = $group.CreatedDateTime
        MailNickname       = $group.MailNickname
        Owners             = $ownerNames
        IsArchived         = $team.IsArchived
        Specialization     = $team.Specialization
        Classification     = $team.Classification
        WebUrl             = $group.WebUrl
    }
}

# Export to CSV (optional)
$report | Export-Csv -Path $reportPath -NoTypeInformation

# Display the report
#$report



