$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\ListsWithoutMajorVersionLimit\Lists_Without_Major_Version_Limit_$timestamp.csv"


# Get all site collections
$sites = Get-PnPTenantSite

# Prepare report
$report = @()

foreach ($site in $sites) {
    Write-Host "Scanning site: $($site.Url)" -ForegroundColor Cyan
    #Connect-PnPOnline -Url $site.Url -Interactive
    Connect-PnPOnline -Url $site.Url `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint

    $lists = Get-PnPList

    foreach ($list in $lists) {
        # Apply filtering conditions
        $versioningDisabled = -not $list.EnableVersioning
        $majorLimitInvalid = $list.MajorVersionLimit -eq 0 -or $list.MajorVersionLimit -gt 100
        $retentionDisabled = -not $list.EnableRetention
        $moderationDisabled = -not $list.EnableModeration

        if ($versioningDisabled -or $majorLimitInvalid -or $retentionDisabled -or $moderationDisabled) {
            $report += [PSCustomObject]@{
                SiteUrl              = $site.Url
                SiteTitle            = $site.Title
                ListTitle            = $list.Title
                ListUrl              = $list.RootFolder.ServerRelativeUrl
                Template             = $list.BaseTemplate
                Created              = $list.Created
                LastModified         = $list.LastItemModifiedDate
                ItemCount            = $list.ItemCount
                Hidden               = $list.Hidden
                EnableVersioning     = $list.EnableVersioning
                EnableMinorVersions  = $list.EnableMinorVersions
                MajorVersionLimit    = $list.MajorVersionLimit
                DraftVersionVisibility = $list.DraftVersionVisibility
                ContentTypesEnabled  = $list.ContentTypesEnabled
                EnableAttachments    = $list.EnableAttachments
                EnableFolderCreation = $list.EnableFolderCreation
                EnableModeration     = $list.EnableModeration
                EnableRetention      = $list.EnableRetention
            }
        }
    }
}

# Output to console
#$report | Format-Table -AutoSize

# Optional: Export to CSV
$report | Export-Csv -Path $reportPath -NoTypeInformation




