$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint
$tenantId     = "e9c255e0-7344-4dd3-b700-76c1d79f7bbc"
$clientId     = "a0f545dd-9c85-4b46-a95d-40b393044a19"
$clientSecret = "zNk8Q~VxfIv9G7RHtxTYfRYljcCwUK_EoylRBddw"

$secureSecret = ConvertTo-SecureString $clientSecret -AsPlainText -Force



$clientSecretCredential = New-Object System.Management.Automation.PSCredential ($clientId, $secureSecret)

#Connect-MgGraph -TenantId $tenantId -ClientId $clientId -ClientSecret $clientSecret

Connect-MgGraph -TenantId $tenantId -ClientSecretCredential $clientSecretCredential -NoWelcome


# Get all M365 Groups (Unified groups)
$groups = Get-MgGroup -Filter "groupTypes/any(c:c eq 'Unified')" -All

# Prepare an array to hold group details
$groupDetails = @()

foreach ($group in $groups) {
    Write-Host "Processing Group: $($group.DisplayName)"

    # Get group configuration details
    $groupInfo = Get-MgGroup -GroupId $group.Id

    # Get group members
    $members = Get-MgGroupMember -GroupId $group.Id -All
    $memberNames = $members | ForEach-Object {
        if ($_.AdditionalProperties["displayName"]) {
            $_.AdditionalProperties["displayName"]
        } else {
            $_.Id
        }
    }

    # Create a custom object for export
    $groupDetails += [PSCustomObject]@{
        GroupName       = $groupInfo.DisplayName
        GroupId         = $groupInfo.Id
        Description     = $groupInfo.Description
        Mail            = $groupInfo.Mail
        Visibility      = $groupInfo.Visibility
        CreatedDateTime = $groupInfo.CreatedDateTime
        Members         = ($memberNames -join "; ")
    }
}

# Export to CSV
$groupDetails | Export-Csv -Path "M365GroupsReport_$timestamp.csv" -NoTypeInformation -Encoding UTF8

Write-Host "? Report generated: M365GroupsReport_$timestamp.csv"




