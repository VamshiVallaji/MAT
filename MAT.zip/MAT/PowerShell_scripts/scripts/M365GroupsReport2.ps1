$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name



# Connect to Exchange Online
Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization


# Get all M365 Groups
$groups = Get-UnifiedGroup -ResultSize Unlimited -IncludeAllProperties

# Initialize result array
$results = @()

foreach ($group in $groups) {
    $groupDetails = Get-UnifiedGroup -Identity $group.Identity -IncludeAllProperties
    $members = Get-UnifiedGroupLinks -Identity $group.Identity -LinkType Member

    foreach ($member in $members) {
        $props = [ordered]@{
        $props['AccessType'] = $groupDetails.AccessType
        $props['AuditLogAgeLimit'] = $groupDetails.AuditLogAgeLimit
        $props['AutoSubscribeNewMembers'] = $groupDetails.AutoSubscribeNewMembers
        $props['AlwaysSubscribeMembersToCalendarEvents'] = $groupDetails.AlwaysSubscribeMembersToCalendarEvents
        $props['CalendarMemberReadOnly'] = $groupDetails.CalendarMemberReadOnly
        $props['CalendarUrl'] = $groupDetails.CalendarUrl
        $props['Database'] = $groupDetails.Database
        $props['ExchangeGuid'] = $groupDetails.ExchangeGuid
        $props['FileNotificationsSettings'] = $groupDetails.FileNotificationsSettings
        $props['GroupSKU'] = $groupDetails.GroupSKU
        $props['InboxUrl'] = $groupDetails.InboxUrl
        $props['IsExternalResourcesPublished'] = $groupDetails.IsExternalResourcesPublished
        $props['IsMailboxConfigured'] = $groupDetails.IsMailboxConfigured
        $props['Language'] = $groupDetails.Language
        $props['MailboxProvisioningConstraint'] = $groupDetails.MailboxProvisioningConstraint
        $props['ManagedByDetails'] = $groupDetails.ManagedByDetails
        $props['Notes'] = $groupDetails.Notes
        $props['PeopleUrl'] = $groupDetails.PeopleUrl
        $props['PhotoUrl'] = $groupDetails.PhotoUrl
        $props['ServerName'] = $groupDetails.ServerName
        $props['SharePointSiteUrl'] = $groupDetails.SharePointSiteUrl
        $props['SharePointDocumentsUrl'] = $groupDetails.SharePointDocumentsUrl
        $props['SharePointNotebookUrl'] = $groupDetails.SharePointNotebookUrl
        $props['SubscriptionEnabled'] = $groupDetails.SubscriptionEnabled
        $props['WelcomeMessageEnabled'] = $groupDetails.WelcomeMessageEnabled
        $props['ConnectorsEnabled'] = $groupDetails.ConnectorsEnabled
        $props['IsMembershipDynamic'] = $groupDetails.IsMembershipDynamic
        $props['Classification'] = $groupDetails.Classification
        $props['GroupPersonification'] = $groupDetails.GroupPersonification
        $props['YammerEmailAddress'] = $groupDetails.YammerEmailAddress
        $props['GroupMemberCount'] = $groupDetails.GroupMemberCount
        $props['MailboxRegion'] = $groupDetails.MailboxRegion
        $props['GroupExternalMemberCount'] = $groupDetails.GroupExternalMemberCount
        $props['AllowAddGuests'] = $groupDetails.AllowAddGuests
        $props['WhenSoftDeleted'] = $groupDetails.WhenSoftDeleted
        $props['HiddenFromExchangeClientsEnabled'] = $groupDetails.HiddenFromExchangeClientsEnabled
        $props['ExpirationTime'] = $groupDetails.ExpirationTime
        $props['DataEncryptionPolicy'] = $groupDetails.DataEncryptionPolicy
        $props['ResourceProvisioningOptions'] = $groupDetails.ResourceProvisioningOptions
        $props['InformationBarrierMode'] = $groupDetails.InformationBarrierMode
        $props['ResourceBehaviorOptions'] = $groupDetails.ResourceBehaviorOptions
        $props['ServiceEndpointUris'] = $groupDetails.ServiceEndpointUris
        $props['SensitivityLabel'] = $groupDetails.SensitivityLabel
        $props['InPlaceHolds'] = $groupDetails.InPlaceHolds
        $props['InPlaceHoldsRaw'] = $groupDetails.InPlaceHoldsRaw
        $props['IsMemberAllowedToEditContent'] = $groupDetails.IsMemberAllowedToEditContent
        $props['EmailAddresses'] = $groupDetails.EmailAddresses
        $props['PrimarySmtpAddress'] = $groupDetails.PrimarySmtpAddress
        $props['Name'] = $groupDetails.Name
        $props['DisplayName'] = $groupDetails.DisplayName
        $props['RequireSenderAuthenticationEnabled'] = $groupDetails.RequireSenderAuthenticationEnabled
        $props['ModerationEnabled'] = $groupDetails.ModerationEnabled
        $props['SendModerationNotifications'] = $groupDetails.SendModerationNotifications
        $props['SendOofMessageToOriginatorEnabled'] = $groupDetails.SendOofMessageToOriginatorEnabled
        $props['BypassModerationFromSendersOrMembers'] = $groupDetails.BypassModerationFromSendersOrMembers
        $props['ModeratedBy'] = $groupDetails.ModeratedBy
        $props['GroupType'] = $groupDetails.GroupType
        $props['IsDirSynced'] = $groupDetails.IsDirSynced
        $props['ManagedBy'] = $groupDetails.ManagedBy
        $props['MigrationToUnifiedGroupInProgress'] = $groupDetails.MigrationToUnifiedGroupInProgress
        $props['HiddenGroupMembershipEnabled'] = $groupDetails.HiddenGroupMembershipEnabled
        $props['ExpansionServer'] = $groupDetails.ExpansionServer
        $props['AcceptMessagesOnlyFromWithDisplayNames'] = $groupDetails.AcceptMessagesOnlyFromWithDisplayNames
        $props['AcceptMessagesOnlyFromSendersOrMembersWithDisplayNames'] = $groupDetails.AcceptMessagesOnlyFromSendersOrMembersWithDisplayNames
        $props['AcceptMessagesOnlyFromDLMembersWithDisplayNames'] = $groupDetails.AcceptMessagesOnlyFromDLMembersWithDisplayNames
        $props['BypassModerationFromSendersOrMembersWithDisplayNames'] = $groupDetails.BypassModerationFromSendersOrMembersWithDisplayNames
        $props['GrantSendOnBehalfToWithDisplayNames'] = $groupDetails.GrantSendOnBehalfToWithDisplayNames
        $props['ModeratedByWithDisplayNames'] = $groupDetails.ModeratedByWithDisplayNames
        $props['RejectMessagesFromSendersOrMembersWithDisplayNames'] = $groupDetails.RejectMessagesFromSendersOrMembersWithDisplayNames
        $props['ReportToManagerEnabled'] = $groupDetails.ReportToManagerEnabled
        $props['ReportToOriginatorEnabled'] = $groupDetails.ReportToOriginatorEnabled
        $props['Description'] = $groupDetails.Description
        $props['BccBlocked'] = $groupDetails.BccBlocked
        $props['AcceptMessagesOnlyFrom'] = $groupDetails.AcceptMessagesOnlyFrom
        $props['AcceptMessagesOnlyFromDLMembers'] = $groupDetails.AcceptMessagesOnlyFromDLMembers
        $props['AcceptMessagesOnlyFromSendersOrMembers'] = $groupDetails.AcceptMessagesOnlyFromSendersOrMembers
        $props['AddressListMembership'] = $groupDetails.AddressListMembership
        $props['AdministrativeUnits'] = $groupDetails.AdministrativeUnits
        $props['Alias'] = $groupDetails.Alias
        $props['OrganizationalUnit'] = $groupDetails.OrganizationalUnit
        $props['CustomAttribute1'] = $groupDetails.CustomAttribute1
        $props['CustomAttribute10'] = $groupDetails.CustomAttribute10
        $props['CustomAttribute11'] = $groupDetails.CustomAttribute11
        $props['CustomAttribute12'] = $groupDetails.CustomAttribute12
        $props['CustomAttribute13'] = $groupDetails.CustomAttribute13
        $props['CustomAttribute14'] = $groupDetails.CustomAttribute14
        $props['CustomAttribute15'] = $groupDetails.CustomAttribute15
        $props['CustomAttribute2'] = $groupDetails.CustomAttribute2
        $props['CustomAttribute3'] = $groupDetails.CustomAttribute3
        $props['CustomAttribute4'] = $groupDetails.CustomAttribute4
        $props['CustomAttribute5'] = $groupDetails.CustomAttribute5
        $props['CustomAttribute6'] = $groupDetails.CustomAttribute6
        $props['CustomAttribute7'] = $groupDetails.CustomAttribute7
        $props['CustomAttribute8'] = $groupDetails.CustomAttribute8
        $props['CustomAttribute9'] = $groupDetails.CustomAttribute9
        $props['ExtensionCustomAttribute1'] = $groupDetails.ExtensionCustomAttribute1
        $props['ExtensionCustomAttribute2'] = $groupDetails.ExtensionCustomAttribute2
        $props['ExtensionCustomAttribute3'] = $groupDetails.ExtensionCustomAttribute3
        $props['ExtensionCustomAttribute4'] = $groupDetails.ExtensionCustomAttribute4
        $props['ExtensionCustomAttribute5'] = $groupDetails.ExtensionCustomAttribute5
        $props['GrantSendOnBehalfTo'] = $groupDetails.GrantSendOnBehalfTo
        $props['ExternalDirectoryObjectId'] = $groupDetails.ExternalDirectoryObjectId
        $props['HiddenFromAddressListsEnabled'] = $groupDetails.HiddenFromAddressListsEnabled
        $props['LastExchangeChangedTime'] = $groupDetails.LastExchangeChangedTime
        $props['LegacyExchangeDN'] = $groupDetails.LegacyExchangeDN
        $props['MaxSendSize'] = $groupDetails.MaxSendSize
        $props['MaxReceiveSize'] = $groupDetails.MaxReceiveSize
        $props['PoliciesIncluded'] = $groupDetails.PoliciesIncluded
        $props['PoliciesExcluded'] = $groupDetails.PoliciesExcluded
        $props['EmailAddressPolicyEnabled'] = $groupDetails.EmailAddressPolicyEnabled
        $props['RecipientType'] = $groupDetails.RecipientType
        $props['RecipientTypeDetails'] = $groupDetails.RecipientTypeDetails
        $props['RejectMessagesFrom'] = $groupDetails.RejectMessagesFrom
        $props['RejectMessagesFromDLMembers'] = $groupDetails.RejectMessagesFromDLMembers
        $props['RejectMessagesFromSendersOrMembers'] = $groupDetails.RejectMessagesFromSendersOrMembers
        $props['MailTip'] = $groupDetails.MailTip
        $props['MailTipTranslations'] = $groupDetails.MailTipTranslations
        $props['Identity'] = $groupDetails.Identity
        $props['Id'] = $groupDetails.Id
        $props['IsValid'] = $groupDetails.IsValid
        $props['ExchangeVersion'] = $groupDetails.ExchangeVersion
        $props['DistinguishedName'] = $groupDetails.DistinguishedName
        $props['ObjectCategory'] = $groupDetails.ObjectCategory
        $props['ObjectClass'] = $groupDetails.ObjectClass
        $props['WhenChanged'] = $groupDetails.WhenChanged
        $props['WhenCreated'] = $groupDetails.WhenCreated
        $props['WhenChangedUTC'] = $groupDetails.WhenChangedUTC
        $props['WhenCreatedUTC'] = $groupDetails.WhenCreatedUTC
        $props['ExchangeObjectId'] = $groupDetails.ExchangeObjectId
        $props['OrganizationalUnitRoot'] = $groupDetails.OrganizationalUnitRoot
        $props['OrganizationId'] = $groupDetails.OrganizationId
        $props['Guid'] = $groupDetails.Guid
        $props['OriginatingServer'] = $groupDetails.OriginatingServer
        $props['ObjectState'] = $groupDetails.ObjectState

        $props['MemberName'] = $member.Name
        $props['MemberEmail'] = $member.PrimarySmtpAddress
        $props['MemberType'] = $member.RecipientType
        }

        $results += New-Object PSObject -Property $props
    }
}

# Export to CSV
$results | Export-Csv -Path "C:\MAT\Reports\M365GroupsReport." -NoTypeInformation -Encoding UTF8




