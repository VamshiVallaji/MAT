$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name



# Connect to Exchange Online
Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization


$reportPath = "$network_drive\Exchange\M365Groups\M365Groups_FullReport_$timestamp.csv"

#$reportPath = "\\matpowershell.file.core.windows.net\matpowershell\Exchange\M365Groups_FullReport_$timestamp.csv"


$sampleGroup = Get-UnifiedGroup -ResultSize 1 -IncludeAllProperties
$columnOrder = $sampleGroup.PSObject.Properties.Name


$columnOrder += "MemberName","MemberEmail","MemberType","Role"


# Get all groups with all properties
$allGroups = Get-UnifiedGroup -ResultSize Unlimited -IncludeAllProperties

$report = foreach ($group in $allGroups) {

    # Get members, owners, guests
    $members = Get-UnifiedGroupLinks -Identity $group.Identity -LinkType Members -ResultSize Unlimited
    $owners = Get-UnifiedGroupLinks -Identity $group.Identity -LinkType Owners -ResultSize Unlimited
    $guests = Get-UnifiedGroupLinks -Identity $group.Identity -LinkType Subscribers -ResultSize Unlimited

    # Build combined list of links
    $allLinks = @()
    if ($members) { $allLinks += $members | ForEach-Object { $_ | Add-Member -NotePropertyName "Role" -NotePropertyValue "Member" -PassThru } }
    if ($owners) { $allLinks += $owners | ForEach-Object { $_ | Add-Member -NotePropertyName "Role" -NotePropertyValue "Owner" -PassThru } }
    if ($guests) { $allLinks += $guests | ForEach-Object { $_ | Add-Member -NotePropertyName "Role" -NotePropertyValue "Guest" -PassThru } }

    if ($allLinks) {
        foreach ($link in $allLinks) {
            # Convert the group to hashtable so all ~135 attributes become columns
            $groupHash = @{}
            $group.PSObject.Properties | ForEach-Object { $groupHash[$_.Name] = $_.Value }

            # Add member details
            $groupHash["MemberName"] = $link.DisplayName
            $groupHash["MemberEmail"] = $link.PrimarySmtpAddress
            $groupHash["MemberType"] = $link.RecipientType
            $groupHash["Role"] = $link.Role

            # Output as object
            [PSCustomObject]$groupHash | Select-Object $columnOrder
        }
    }
    else {
        # No members/owners/guests
        $groupHash = @{}
        $group.PSObject.Properties | ForEach-Object { $groupHash[$_.Name] = $_.Value }

        $groupHash["MemberName"] = ""
        $groupHash["MemberEmail"] = ""
        $groupHash["MemberType"] = ""
        $groupHash["Role"] = ""

        [PSCustomObject]$groupHash | Select-Object $columnOrder
    }
}

# Export to CSV
$report | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "? Full report with ~135 group properties + members exported to $reportPath"




