$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name



# Connect to Exchange Online
Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "C:\MAT\Reports\M365Groups_FullReport2_$timestamp.csv"

$sampleGroup = Get-UnifiedGroup -ResultSize 1 -IncludeAllProperties
$columnOrder = $sampleGroup.PSObject.Properties.Name

$allGroups = Get-UnifiedGroup -ResultSize Unlimited -IncludeAllProperties

$report = foreach ($group in $allGroups) {

    # Get members, owners, and guests
    $members = Get-UnifiedGroupLinks -Identity $group.Identity -LinkType Members -ResultSize Unlimited
    $owners = Get-UnifiedGroupLinks -Identity $group.Identity -LinkType Owners -ResultSize Unlimited
    $guests = Get-UnifiedGroupLinks -Identity $group.Identity -LinkType Subscribers -ResultSize Unlimited

    # Convert group properties (~135 attributes) into hashtable
    $groupHash = [ordered]@{}

    foreach ($column in $columnOrder) {
        $groupHash[$column] = $group.$column
        }


    # Add flattened membership info
    $groupHash["Owners"] = ($owners | ForEach-Object {$_.PrimarySmtpAddress}) -join ";"
    $groupHash["Members"] = ($members | ForEach-Object {$_.PrimarySmtpAddress}) -join ";"
    $groupHash["Guests"] = ($guests | ForEach-Object {$_.PrimarySmtpAddress}) -join ";"

    # Output object
    [PSCustomObject]$groupHash
}

# Export to CSV
$report | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "? Full report exported to $reportPath"







