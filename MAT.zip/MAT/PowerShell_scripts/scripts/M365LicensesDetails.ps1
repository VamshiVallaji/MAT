$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint
$tenantId     = "e9c255e0-7344-4dd3-b700-76c1d79f7bbc"
$clientId     = "a0f545dd-9c85-4b46-a95d-40b393044a19"
$clientSecret = "HB_8Q~y8JUMedFaP7-cnT1WSRVWg15dYn8DB8ctR"

# Convert secret to secure string
$SecureSecret = ConvertTo-SecureString $ClientSecret -AsPlainText -Force

$clientSecretCredential = New-Object System.Management.Automation.PSCredential ($clientId, $secureSecret)


Connect-MgGraph -TenantId $tenantId -ClientSecretCredential $clientSecretCredential -NoWelcome



# Get all users
$users = Get-MgUser -All

# Prepare array to hold license info
$licenseDetails = @()

foreach ($user in $users) {
    $license = Get-MgUserLicenseDetail -UserId $user.Id

    foreach ($lic in $license) {
        $enabledServices = $lic.ServicePlans | Where-Object { $_.ProvisioningStatus -eq "Success" } | Select-Object -ExpandProperty ServicePlanName

        $licenseDetails += [PSCustomObject]@{
            DisplayName     = $user.DisplayName
            UserPrincipalName = $user.UserPrincipalName
            SkuPartNumber   = $lic.SkuPartNumber
            EnabledServices = ($enabledServices -join "; ")
        }
    }
}

# Export to CSV
$reportPath = "$network_drive\Exchange\M365Licenses\M365UserLicenses_$timestamp.csv"
$licenseDetails | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "? License report generated: M365UserLicenses_$timestamp.csv"




