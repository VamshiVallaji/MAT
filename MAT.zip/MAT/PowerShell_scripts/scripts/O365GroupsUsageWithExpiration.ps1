$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint
# ============================
# Config
# ============================




Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]

$ReportPeriod = "D30"   # Valid values: D7, D30, D90, D180
$OutputFile = "$network_drive\Sharepoint\O365_GroupsUsageAndExpiration\O365GroupsUsageWithExpiration_$timestamp.csv"

# ============================
# Connect using Certificate Thumbprint
# ============================
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" -ClientId $ClientId -Tenant $tenantId -Thumbprint $Thumbprint

# ============================
# Step 1: Download O365 Groups Usage Report
# ============================
$reportUrl = "https://graph.microsoft.com/v1.0/reports/getOffice365GroupsActivityDetail(period='$ReportPeriod')"
$reportStream = Invoke-PnPGraphMethod -Url $reportUrl -Method GET -ContentType "application/json"
$reader = New-Object System.IO.StreamReader($reportStream)
$csvContent = $reader.ReadToEnd()
$reader.Close()
$UsageReport = $csvContent | ConvertFrom-Csv

# ============================
# Step 2: Get Group Expiration Policies
# ============================
$Policies = Get-PnPGroupLifecyclePolicy

# ============================
# Step 3: Get Group Metadata (Creation Date etc.)
# ============================
$AllGroups = Get-PnPMicrosoft365Group -IncludeSiteUrl

# ============================
# Step 4: Join Usage Report with Expiration Info
# ============================
$FinalReport = foreach ($group in $UsageReport) {
    $grpMeta = $AllGroups | Where-Object { $_.Id -eq $group.GroupId }
    $policy = $null
    $expirationDate = ""

    if ($Policies) {
        $policy = $Policies | Where-Object { $_.GroupId -eq $group.GroupId }
        if ($policy -and $grpMeta -and $grpMeta.CreatedDateTime) {
            $expirationDate = (Get-Date $grpMeta.CreatedDateTime).AddDays($policy.GroupLifetimeInDays)
        }
    }

    [PSCustomObject]@{
        GroupId                       = $group.GroupId
        GroupDisplayName              = $group.GroupDisplayName
        IsDeleted                     = $group.IsDeleted
        OwnerPrincipalName            = $group.OwnerPrincipalName
        LastActivityDate              = $group.LastActivityDate
        GroupType                     = $group.GroupType
        ExchangeReceivedEmailCount    = $group.ExchangeReceivedEmailCount
        YammerPostedMessageCount      = $group.YammerPostedMessageCount
        YammerReadMessageCount        = $group.YammerReadMessageCount
        YammerLikedMessageCount       = $group.YammerLikedMessageCount
        SharePointActiveFileCount     = $group.SharePointActiveFileCount
        SharePointTotalFileCount      = $group.SharePointTotalFileCount
        ExchangeMailboxTotalItemCount = $group.ExchangeMailboxTotalItemCount
        ExchangeMailboxStorageUsedMB  = $group.ExchangeMailboxStorageUsedInBytes
        SharePointSiteStorageUsedMB   = $group.SharePointSiteStorageUsedInBytes
        ReportPeriod                  = $group.ReportPeriod
        ReportRefreshDate             = $group.ReportRefreshDate

        # Expiration details
        PolicyId                      = if ($policy) { $policy.Id } else { "" }
        ExpirationInDays              = if ($policy) { $policy.GroupLifetimeInDays } else { "" }
        ExpirationDate                = $expirationDate
        AlternateNotificationEmails   = if ($policy) { $policy.AlternateNotificationEmails } else { "" }
    }
}

# ============================
# Step 5: Export Final Report
# ============================
$FinalReport | Export-Csv -Path $OutputFile -NoTypeInformation -Encoding UTF8

Write-Host "Report generated: $OutputFile"




