$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint




Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]

$ReportPeriod = "D30"   # Valid values: D7, D30, D90, D180
$reportPath = "$network_drive\Sharepoint\O365_GroupsUsageAndExpiration\O365GroupsUsageWithExpiration_$timestamp.csv"


# Download Office 365 Group activity report
$initialreport = "GroupsActivity_$timestamp.csv"
Get-MgReportOffice365GroupActivityDetail -Period "D30" -OutFile $initialreport

# Import activity report
$activityDetails = Import-Csv $initialreport

# Get all Office 365 Groups
$groups = Get-MgGroup -Filter "groupTypes/any(c:c eq 'Unified')" -All

# Get expiration policy
$expirationPolicy = Get-MgGroupLifecyclePolicy

# Prepare report data
$report = @()

foreach ($group in $groups) {
    $activity = $activityDetails | Where-Object { $_.'Group Id' -eq $group.Id }

    $createdDate = $group.CreatedDateTime
    $groupLifetime = $expirationPolicy.GroupLifetimeInDays
    $expirationDate = $createdDate.AddDays($groupLifetime)
    $daysToExpire = ($expirationDate - (Get-Date)).Days
    $isExpiringSoon = $daysToExpire -le 30

    $report += [PSCustomObject]@{
        "Report Refresh Date"               = (Get-Date).ToString("yyyy-MM-dd")
        "Group Display Name"                = $group.DisplayName
        "Group Id"                          = $group.Id
        "Is Deleted"                        = $group.DeletedDateTime -ne $null
        "Owner Principal Name"              = ($group.Owners | ForEach-Object { $_.UserPrincipalName }) -join ", "
        "Last Activity Date"                = $activity.'Last Activity Date'
        "Group Type"                        = "Office 365"
        "Member Count"                      = $activity.'Member Count'
        "External Member Count"             = $activity.'External Member Count'
        "Exchange Received Email Count"     = $activity.'Exchange Received Email Count'
        "SharePoint Active File Count"      = $activity.'SharePoint Active File Count'
        "Yammer Posted Message Count"       = $activity.'Yammer Posted Message Count'
        "Yammer Read Message Count"         = $activity.'Yammer Read Message Count'
        "Yammer Liked Message Count"        = $activity.'Yammer Liked Message Count'
        "Exchange Mailbox Total Item Count" = $activity.'Exchange Mailbox Total Item Count'
        "Exchange Mailbox Storage Used (Byte)" = $activity.'Exchange Mailbox Storage Used (Byte)'
        "SharePoint Total File Count"       = $activity.'SharePoint Total File Count'
        "SharePoint Site Storage Used (Byte)" = $activity.'SharePoint Site Storage Used (Byte)'
        "Report Period"                     = "Last 30 Days"
        "Created DateTime"                  = $createdDate
        "Expiration DateTime"               = $expirationDate
        "Renewed DateTime"                  = $expirationDate  # inferred
        "Policy GroupLifetimeInDays"        = $groupLifetime
        "Policy ManagedGroupTypes"          = $expirationPolicy.ManagedGroupTypes
        "Policy AltNotificationEmails"      = $expirationPolicy.AlternateNotificationEmails
        "Is Expiring Soon"                  = $isExpiringSoon
    }
}

# Export final report
$report | Export-Csv -Path $reportPath -NoTypeInformation

Write-Host "? Full report generated: O365GroupsFullUsageAndExpirationReport_$timestamp.csv"




