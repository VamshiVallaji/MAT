$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "C:\MAT\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome


$timestamp = Get-Date -Format "MM_dd_yyyy hh_mm_ss tt"
$filePath = "C:\MAT\onedrive\reports\OnedriveUsage\OneDriveUsageDetail$timestamp_$timestamp.csv"

# Fetch Onedrive usage report for the past 30 days

Get-MgReportOneDriveUsageAccountDetail -Period D30 -OutFile $filePath


Write-Host "Onedrive usage report saved to $filePath"




