$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
#Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
 #   -ClientId $ClientId `
  #  -Tenant $tenantId `
   # -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\Tenant_PowerAutomate_Flows\PowerAutomate_Flows_Report_$timestamp.csv"





# Get all environments
$environments = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/beta/solutions/powerPlatform/environments"

$report = @()

foreach ($env in $environments.value) {
    $envId = $env.id
    Write-Host "?? Scanning environment: $($env.displayName)"

    # Get flows in the environment
    $flowsUri = "https://graph.microsoft.com/beta/solutions/powerPlatform/environments/$envId/flows"
    $flows = Invoke-MgGraphRequest -Method GET -Uri $flowsUri


foreach ($flow in $flows.value) {
    # Get full flow definition
    $definitionUri = "https://graph.microsoft.com/beta/solutions/powerPlatform/environments/$envId/flows/$($flow.name)/definition"
    $definition = Invoke-MgGraphRequest -Method GET -Uri $definitionUri

    # Parse trigger type
    $triggerType = $definition.triggers.Keys | Select-Object -First 1

    # Count actions for complexity
    $actionCount = ($definition.actions.Keys).Count

    # Get connector references
    $connectors = $definition.connectorReferences.Keys -join ", "

    # Get shared users
    $sharedUri = "https://graph.microsoft.com/beta/solutions/powerPlatform/environments/$envId/flows/$($flow.name)/sharedWithUsers"
    $sharedUsers = Invoke-MgGraphRequest -Method GET -Uri $sharedUri
    $sharedWith = ($sharedUsers.value | Select-Object -ExpandProperty userPrincipalName) -join ", "

    # Add to report
    $report += [PSCustomObject]@{
        EnvironmentName = $env.displayName
        FlowName        = $flow.displayName
        FlowType        = $flow.flowType
        TriggerType     = $triggerType
        ConnectorUsage  = $connectors
        ActionCount     = $actionCount
        SharedWith      = $sharedWith
        Status          = $flow.state
        $owner = if ($flow.owner -and $flow.owner.user -and $flow.owner.user.userPrincipalName) {
    $flow.owner.user.userPrincipalName
} else {
    "Unknown"
}       
        CreatedDate     = $flow.createdDateTime
        LastModified    = $flow.lastModifiedDateTime
    }
}


   
}

# Output to console or export
#$report | Format-Table -AutoSize
# Optional: Export to CSV
$report | Export-Csv -Path $reportPath -NoTypeInformation
