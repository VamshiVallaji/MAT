$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint
$secret = $config.AppSecret
#$username = "VamshiV@M365x95823790.onmicrosoft.com"

Add-PowerAppsAccount -TenantId $tenantId -ApplicationId $ClientId -ClientSecret $secret


#Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
#$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

#$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
#Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
 #   -ClientId $ClientId `
  #  -Tenant $tenantId `
   # -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\Tenant_PowerAutomate_Flows\PowerAutomate_Flows_Report_$timestamp.csv"



$flows = Get-AdminFlow

if (-not $flows -or $flows.Count -eq 0) {
    Write-Warning "No flows found or insufficient permissions."
    exit
}

$report = foreach ($flow in $flows) {
    try {
        # Get owners / permissions
        $owners = Get-AdminFlowOwnerRole -FlowName $flow.FlowName -EnvironmentName $flow.EnvironmentName
        $ownerUPNs = ($owners | Select-Object -ExpandProperty PrincipalObjectId) -join ";"
    } catch {
        $ownerUPNs = "Error/NoAccess"
    }

    [PSCustomObject]@{
        DisplayName = $flow.DisplayName
        FlowName = $flow.FlowName
        EnvironmentName = $flow.EnvironmentName
        CreatedTime = $flow.CreatedTime
        LastModifiedTime = $flow.LastModifiedTime
        FlowType = $flow.FlowType
        State = $flow.State
        Owner = $flow.Creator.UserId
        Owners = $ownerUPNs
    }
}

# --- Export ---
$report |
    Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "Tenant-wide Power Automate flows report generated: $reportPath" -ForegroundColor Green
