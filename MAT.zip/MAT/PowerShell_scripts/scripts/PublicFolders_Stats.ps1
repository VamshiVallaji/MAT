$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name



# Connect to Exchange Online
Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization


$reportPath = "$network_drive\Exchange\PublicFolders_Stats\PublicFolders_Stats_Report_$timestamp.csv"

# Create empty report
$report = @()

try {
    # Get all public folders with stats
    $publicFolders = Get-PublicFolder -Recurse -ResultSize Unlimited -ErrorAction Stop
}
catch {
    Write-Host "No Public Folders found." -ForegroundColor Yellow
    $publicFolders = @()
}

foreach ($pf in $publicFolders) {
    try {
        $stats = Get-PublicFolderStatistics -Identity $pf.Identity -ErrorAction Stop
        $report += [PSCustomObject]@{
            FolderPath = $pf.FolderPath
            Name = $pf.Name
            EntryId = $stats.EntryId
            DeletedItemCount = $stats.DeletedItemCount
            ItemCount = $stats.ItemCount
            CreationTime = $stats.CreationTime
            LastModificationTime = $stats.LastModificationTime
            OwnerCount = $stats.OwnerCount
            TotalAssociatedItemSize= $stats.TotalAssociatedItemSize
            TotalDeletedItemSize = $stats.TotalDeletedItemSize
            TotalItemSize = $stats.TotalItemSize
            MailboxOwnerId = $pf.MailboxOwnerId
            "Migrated to M365Group"= $pf.MigratedToGroupMailbox
        }
    }
    catch {
        Write-Host "Error fetching stats for $($pf.Identity)" -ForegroundColor Red
    }
}

# If no PFs found, still export headers
if (-not $report) {
    $report = [PSCustomObject]@{
        FolderPath = $null
        Name = $null
        EntryId = $null
        DeletedItemCount = $null
        ItemCount = $null
        CreationTime = $null
        LastModificationTime = $null
        OwnerCount = $null
        TotalAssociatedItemSize= $null
        TotalDeletedItemSize = $null
        TotalItemSize = $null
        MailboxOwnerId = $null
        "Migrated to M365Group"= $null
    }
}

# Export to CSV (Excel-compatible)
$report | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "Public Folder Stats Report exported to $reportPath" -ForegroundColor Green




