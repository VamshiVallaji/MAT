$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome


$reportPath = "$network_drive\Teams\TeamsAutoAttendants\TeamsAutoAttendant_$timestamp.csv"


# Connect to Microsoft Teams
Connect-MicrosoftTeams


# Get all Auto Attendants
$autoAttendants = Get-CsAutoAttendant

# Get all resource accounts
$resourceAccounts = Get-CsOnlineApplicationInstance

# Prepare report array
$report = @()

foreach ($aa in $autoAttendants) {
    # Get linked resource accounts via ApplicationInstances
    $linkedResourceAccounts = @()
    foreach ($ra in $resourceAccounts) {
        if ($aa.ApplicationInstances -contains $ra.ObjectId) {
            $linkedResourceAccounts += $ra.DisplayName
        }
    }

    $resourceAccountCount = $linkedResourceAccounts.Count
    $resourceAccountsEnabled = $resourceAccountCount -gt 0
    $resourceAccountNames = if ($resourceAccountCount -gt 0) { $linkedResourceAccounts -join ", " } else { "None" }

    # Add all attributes to report
    $report += [PSCustomObject]@{
        Identity                 = $aa.Identity
        TenantId                 = $aa.TenantId
        Name                     = $aa.Name
        LanguageId               = $aa.LanguageId
        VoiceId                  = $aa.VoiceId
        DefaultCallFlow          = $aa.DefaultCallFlow
        Operator                 = $aa.Operator
        TimeZoneId               = $aa.TimeZoneId
        VoiceResponseEnabled     = $aa.VoiceResponseEnabled
        CallFlows                = $aa.CallFlows
        Schedules                = $aa.Schedules
        CallHandlingAssociations = $aa.CallHandlingAssociations
        Status                   = $aa.Status
        DialByNameResourceId     = $aa.DialByNameResourceId
        DirectoryLookupScope     = $aa.DirectoryLookupScope
        ApplicationInstances     = $aa.ApplicationInstances -join ", "
        AuthorizedUsers          = $aa.AuthorizedUsers
        HideAuthorizedUsers      = $aa.HideAuthorizedUsers
        UserNameExtension        = $aa.UserNameExtension
        MainlineAttendantEnabled = $aa.MainlineAttendantEnabled
        ResourceAccountsEnabled  = $resourceAccountsEnabled
        ResourceAccountCount     = $resourceAccountCount
        ResourceAccountNames     = $resourceAccountNames
    }
}

# Export to CSV
#$reportPath = "$env:USERPROFILE\Desktop\AutoAttendantReport.csv"
$report | Export-Csv $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "? Report generated: $reportPath"


