$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome


$reportPath = "$network_drive\Teams\TeamsCallQueues\TeamsCallQueues_$timestamp.csv"


# Connect to Microsoft Teams
Connect-MicrosoftTeams

# Get all Call Queues
$callQueues = Get-CsCallQueue

# Get all resource accounts
$resourceAccounts = Get-CsOnlineApplicationInstance

# Display total count
Write-Host "Total Call Queues: $($callQueues.Count)"

# Build report
$results = foreach ($cq in $callQueues) {
    # Get agent list
    $agents = ($cq.Agents | ForEach-Object { $_.ObjectId }) -join "; "

    # Get overflow settings
    $overflowAction = $cq.OverflowAction.Type
    $overflowTarget = $cq.OverflowAction.TargetObjectId

    # Get timeout settings
    $timeoutAction = $cq.TimeoutAction.Type
    $timeoutTarget = $cq.TimeoutAction.TargetObjectId

    # Match resource account names
    $linkedAccounts = @()
    foreach ($raId in $cq.ApplicationInstances) {
        $ra = $resourceAccounts | Where-Object { $_.ObjectId -eq $raId }
        if ($ra) {
            $linkedAccounts += $ra.DisplayName
        }
    }

    $resourceAccountNames = if ($linkedAccounts.Count -gt 0) { $linkedAccounts -join ", " } else { "None" }
    $resourceAccountCount = $linkedAccounts.Count
    $resourceAccountsEnabled = $resourceAccountCount -gt 0

    [PSCustomObject]@{
        Name                    = $cq.Name
        Identity                = $cq.Identity
        Enabled                 = $cq.Enabled
        ResourceAccountsEnabled = $resourceAccountsEnabled
        ResourceAccountNames    = $resourceAccountNames
        ResourceAccountCount    = $resourceAccountCount
        Agents                  = $agents
        OverflowAction          = $overflowAction
        OverflowTarget          = $overflowTarget
        TimeoutAction           = $timeoutAction
        TimeoutTarget           = $timeoutTarget
        TotalCount              = $callQueues.Count
    }
}

# Export to CSV
#$reportPath = "$env:USERPROFILE\Desktop\CallQueueReport.csv"
$results | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "? Call Queue report generated: $reportPath"
