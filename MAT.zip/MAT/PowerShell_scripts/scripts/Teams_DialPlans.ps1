﻿$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome


$reportPath = "$network_drive\Teams\DialPlans\Teams_DialPlans_$timestamp.csv"



$skus = Get-MgSubscribedSku
$teamsSkus = $skus | Where-Object {
    ($_.ServicePlans.ServicePlanName -contains "TEAMS1") -or
    ($_.SkuPartNumber -match "Teams" -and $_.SkuPartNumber -notmatch "no_Teams")
}

$teamsSkuIds = $teamsSkus.SkuId
$allUsers = Get-MgUser -All -Property Id,DisplayName,UserPrincipalName,AssignedLicenses
$teamsUsers = $allUsers | Where-Object {
    $_.AssignedLicenses | Where-Object { $teamsSkuIds -contains $_.SkuId }
}

# Connect to Microsoft Teams
Connect-MicrosoftTeams

# Get all dial plans
$dialPlans = Get-CsTenantDialPlan

# Get all users with dial plan assignments
#$usersWithDialPlan = Get-CsOnlineUser | Where-Object {
 #   try {
  #      $assignment = Get-CsUserPolicyAssignment -Identity $_.UserPrincipalName -PolicyType TenantDialPlan
   #     $assignment.PolicyName -ne $null
  #  } catch {
   #     $false
    #}
#}

# Get all group policy assignments for dial plans
$groupAssignments = Get-CsGroupPolicyAssignment -PolicyType TenantDialPlan

# Prepare report array
$report = @()

foreach ($dp in $dialPlans) {
    # Determine if it's a custom policy
    $isCustom = if ($dp.Identity -ne "Global") { "Yes" } else { "No" }

    # Build normalization rules summary
    $normRules = if ($dp.NormalizationRules.Count -gt 0) {
        ($dp.NormalizationRules | ForEach-Object {
            "[$($_.Name)] Pattern: $($_.Pattern), Translation: $($_.Translation)"
        }) -join " | "
    } else { "None" }

    # Check if any users are assigned to this dial plan
    $userAssigned = $teamsUsers | Where-Object {
        try {
            $assignment = Get-CsUserPolicyAssignment -Identity $_.UserPrincipalName -PolicyType TenantDialPlan
            $assignment.PolicyName -eq $dp.Identity
        } catch {
            $false
        }
    }
    $assignedToUsers = if ($userAssigned.Count -gt 0) { "Yes" } else { "No" }

   # # Check if any groups are assigned to this dial plan
    $groupAssigned = $groupAssignments | Where-Object { $_.PolicyName -eq $dp.Identity }
    $assignedToGroups = if ($groupAssigned.Count -gt 0) { "Yes" } else { "No" }

    # Add to report
    $report += [PSCustomObject]@{
        DialPlanName       = $dp.Identity
        Description        = $dp.Description
        SimpleName         = $dp.SimpleName
        CustomPolicy       = $isCustom
        NormalizationRules = $normRules
        AssignedToUsers    = $assignedToUsers
        AssignedToGroups   = $assignedToGroups
    }
}

# Export to CSV
#$reportPath = "$env:USERPROFILE\Desktop\TeamsDialPlanReport.csv"
$report | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "✅ Dial Plan report generated: $reportPath"