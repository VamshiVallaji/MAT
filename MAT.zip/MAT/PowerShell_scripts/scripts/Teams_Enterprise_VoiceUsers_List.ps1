$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome


$reportPath = "$network_drive\Teams\Teams_Enterprise_VoiceUsers_List\Teams_Enterprise_VoiceUsers_List_$timestamp.csv"

# Connect to Microsoft Teams
Connect-MicrosoftTeams

# Get all online users
$users = Get-CsOnlineUser

# Filter users with Enterprise Voice enabled
$evUsers = $users | Where-Object { $_.EnterpriseVoiceEnabled -eq $true }

# Display total count
$totalEVUsers = $evUsers.Count
Write-Host "Total Enterprise Voice Users: $totalEVUsers"

# Build report
$results = foreach ($user in $evUsers) {
    [PSCustomObject]@{
        DisplayName           = $user.DisplayName
        UserPrincipalName     = $user.UserPrincipalName
        TelephoneNumber       = $user.LineUri
        Country               = $user.IsoCountryCode
        VoiceRoutingPolicy    = $user.VoiceRoutingPolicy
        CallingPolicy         = $user.TeamsCallingPolicy
        DialPlan              = $user.TeamsDialPlan
        EnterpriseVoiceEnabled = $user.EnterpriseVoiceEnabled
        totalEVUsers         = $evUsers.Count
    }
}

# Output to console
#$results | Format-Table -AutoSize

# Optional: Export to CSV
$results | Export-Csv -Path $reportPath -NoTypeInformation


