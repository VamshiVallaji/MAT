$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome


$reportPath = "$network_drive\Teams\Teams_Policies\TeamsPolicies_$timestamp.csv"


# Get all Teams
#$teams = Get-MgGroup -All -Filter "resourceProvisioningOptions/Any(x:x eq 'Team')"

# Connect to Graph and Teams before this point

#$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"


# Ensure folder exists
#New-Item -ItemType Directory -Force -Path $reportBasePath | Out-Null
# Connect to Microsoft Graph and get Teams-enabled userDetailss
$skus = Get-MgSubscribedSku
$teamsSkus = $skus | Where-Object {
    ($_.ServicePlans.ServicePlanName -contains "TEAMS1") -or
    ($_.SkuPartNumber -match "Teams" -and $_.SkuPartNumber -notmatch "no_Teams")
}

$teamsSkuIds = $teamsSkus.SkuId
$allUsers = Get-MgUser -All -Property Id,DisplayName,UserPrincipalName,AssignedLicenses
$teamsUsers = $allUsers | Where-Object {
    $_.AssignedLicenses | Where-Object { $teamsSkuIds -contains $_.SkuId }
}
# Connect to Microsoft Teams
Connect-MicrosoftTeams


# Helper function to format policy values
function FormatPolicy($value) {
    if ([string]::IsNullOrEmpty($value)) {
        return "Global (default)"
    } else {
        return $value
    }
}

# Build report
$results = foreach ($user in $teamsUsers) {
     $userDetails = Get-CsOnlineUser -Identity $user.UserPrincipalName -ErrorAction SilentlyContinue

    [PSCustomObject]@{
        DisplayName                     = $user.DisplayName
        UserPrincipalName               = $user.UserPrincipalName
        TeamsCallingPolicy              = FormatPolicy $userDetails.TeamsCallingPolicy
        TeamsMeetingPolicy              = FormatPolicy $userDetails.TeamsMeetingPolicy
        TeamsMessagingPolicy            = FormatPolicy $userDetails.TeamsMessagingPolicy
        TeamsAppSetupPolicy             = FormatPolicy $userDetails.TeamsAppSetupPolicy
        TeamsAppPermissionPolicy        = FormatPolicy $userDetails.TeamsAppPermissionPolicy
        TeamsUpdateManagementPolicy     = FormatPolicy $userDetails.TeamsUpdateManagementPolicy
        TeamsChannelsPolicy             = FormatPolicy $userDetails.TeamsChannelsPolicy
        TeamsFeedbackPolicy             = FormatPolicy $userDetails.TeamsFeedbackPolicy
        TeamsMeetingBroadcastPolicy     = FormatPolicy $userDetails.TeamsMeetingBroadcastPolicy
        TeamsEmergencyCallingPolicy     = FormatPolicy $userDetails.TeamsEmergencyCallingPolicy
        TeamsEmergencyCallRoutingPolicy = FormatPolicy $userDetails.TeamsEmergencyCallRoutingPolicy
        TeamsCortanaPolicy              = FormatPolicy $userDetails.TeamsCortanaPolicy
        TeamsEnhancedEncryptionPolicy   = FormatPolicy $userDetails.TeamsEnhancedEncryptionPolicy
        TeamsMobilityPolicy             = FormatPolicy $userDetails.TeamsMobilityPolicy
        TeamsVdiPolicy                  = FormatPolicy $userDetails.TeamsVdiPolicy
        TeamsEducationAssignmentsPolicy = FormatPolicy $userDetails.TeamsEducationAssignmentsPolicy
        TeamsUpgradePolicy              = FormatPolicy $userDetails.TeamsUpgradePolicy
        TeamsCallParkPolicy             = FormatPolicy $userDetails.TeamsCallParkPolicy
        CallerIdPolicy                  = FormatPolicy $userDetails.CallerIdPolicy
        TeamsDialPlan                   = FormatPolicy $userDetails.TenantDialPlan
        VoiceRoutingPolicy              = FormatPolicy $userDetails.OnlineVoiceRoutingPolicy
        TeamsCallingLineIdentity        = FormatPolicy $userDetails.CallingLineIdentity
    }
}

# Output to console
#$results | Format-Table -AutoSize

# Optional: Export to CSV
$results | Export-Csv -Path $reportPath -NoTypeInformation
