$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome


$reportPath = "$network_drive\Teams\Teams_ResourceAccounts\Teams_ResourceAccounts_$timestamp.csv"

Connect-MicrosoftTeams

$resourceAccounts = Get-CsOnlineApplicationInstance

Write-Host "Total Resource Accounts: $($resourceAccounts.Count)"

$results = foreach ($ra in $resourceAccounts) {
    [PSCustomObject]@{
        DisplayName              = $ra.DisplayName
        UserPrincipalName        = $ra.UserPrincipalName
        ApplicationId            = $ra.ApplicationId
        PhoneNumber              = $ra.PhoneNumber
        AssignedToTargetId       = $ra.AssignedToTargetId
        AssignedToTargetName     = $ra.AssignedToTargetName
        AssignedToTargetType     = $ra.AssignedToTargetType
        SipAddress               = $ra.SipAddress
        ObjectId                 = $ra.ObjectId
        TenantId                 = $ra.TenantId
        Identity                 = $ra.Identity
        IsSipEnabled             = $ra.IsSipEnabled
        IsTeamsUser              = $ra.IsTeamsUser
        IsAudioConferenceUser    = $ra.IsAudioConferenceUser
        IsEnterpriseVoiceEnabled = $ra.IsEnterpriseVoiceEnabled
        TotalCount               = $resourceAccounts.Count
    }
}

#$results | Format-Table -AutoSize
# Optional: Export to CSV
$results | Export-Csv -Path $reportPath -NoTypeInformation
