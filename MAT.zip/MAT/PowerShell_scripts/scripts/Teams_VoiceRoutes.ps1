﻿$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome


$reportPath = "$network_drive\Teams\VoiceRoutes\Teams_VoiceRoutes_$timestamp.csv"

# Connect to Microsoft Teams
Connect-MicrosoftTeams

# Get all voice routes
$voiceRoutes = Get-CsOnlineVoiceRoute

# Prepare report array
$report = @()

foreach ($route in $voiceRoutes) {
    $pstnUsages = if ($route.OnlinePstnUsages.Count -gt 0) {
        $route.OnlinePstnUsages -join ", "
    } else { "None" }

    $pstnGateways = if ($route.OnlinePstnGatewayList.Count -gt 0) {
        $route.OnlinePstnGatewayList -join ", "
    } else { "None" }

    $report += [PSCustomObject]@{
        Identity                = $route.Identity
        Name                    = $route.Name
        Description             = $route.Description
        Priority                = $route.Priority
        NumberPattern           = $route.NumberPattern
        OnlinePstnUsages        = $pstnUsages
        OnlinePstnGatewayList   = $pstnGateways
        BridgeSourcePhoneNumber = $route.BridgeSourcePhoneNumber
    }
}

# Export to CSV
#$reportPath = "$env:USERPROFILE\Desktop\TeamsVoiceRoutesReport.csv"
$report | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "✅ Voice Routes report generated: $reportPath"


