$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome


#$reportPath = "$network_drive\Teams\Teams_Policies\TeamsPolicies_$timestamp.csv"


# Get all Teams
#$teams = Get-MgGroup -All -Filter "resourceProvisioningOptions/Any(x:x eq 'Team')"

# Connect to Graph and Teams before this point

#$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"


# Ensure folder exists
#New-Item -ItemType Directory -Force -Path $reportBasePath | Out-Null
# Connect to Microsoft Graph and get Teams-enabled users
$skus = Get-MgSubscribedSku
$teamsSkus = $skus | Where-Object {
    ($_.ServicePlans.ServicePlanName -contains "TEAMS1") -or
    ($_.SkuPartNumber -match "Teams" -and $_.SkuPartNumber -notmatch "no_Teams")
}

$teamsSkuIds = $teamsSkus.SkuId
$allUsers = Get-MgUser -All -Property Id,DisplayName,UserPrincipalName,AssignedLicenses
$teamsUsers = $allUsers | Where-Object {
    $_.AssignedLicenses | Where-Object { $teamsSkuIds -contains $_.SkuId }
}

# Connect to Microsoft Teams
Connect-MicrosoftTeams

# Regular policy types
$policyTypes = @(
    "TeamsAppPermissionPolicy",
    "TeamsPolicy",
    "TeamsMeetingPolicy",
    "TeamsCallingPolicy",
    "TeamsCallHoldPolicy",
    "TeamsCallParkPolicy",
    "TeamsCallingLineIdentity",
    "OnlineVoicemailPolicy",
    "OnlineVoiceRoutingPolicy"
)

# Emergency policies to combine
$emergencyPolicies = @(
    "TeamsEmergencyCallRoutingPolicy",
    "TeamsEmergencyCallingPolicy"
)

# Export regular policy types
foreach ($policyType in $policyTypes) {
    Write-Host "Exporting $policyType..."

    $reportBasePath = "$network_drive\Teams\$policyType"
    if (-not (Test-Path $reportBasePath)) {
        New-Item -ItemType Directory -Path $reportBasePath | Out-Null
    }

    $results = foreach ($user in $teamsUsers) {
        $userDetails = Get-CsOnlineUser -Identity $user.UserPrincipalName -ErrorAction SilentlyContinue
        $policyValue = $userDetails.$policyType

        if (-not $policyValue) {
            $policyValue = "Inherited or Default"
        }

        [PSCustomObject]@{
            DisplayName              = $user.DisplayName
            UserPrincipalName        = $user.UserPrincipalName
            PolicyType               = $policyType
            PolicyName               = $policyValue
            InterpretedUserType      = $userDetails.InterpretedUserType
            UsageLocation            = $userDetails.UsageLocation
            EnterpriseVoiceEnabled   = $userDetails.EnterpriseVoiceEnabled
            TeamsUpgradeEffectiveMode = $userDetails.TeamsUpgradeEffectiveMode
            Department               = $userDetails.Department
            Title                    = $userDetails.Title
            SipAddress               = $userDetails.SipAddress
        }
    }

    $results | Export-Csv -NoTypeInformation -Path "$reportBasePath\$policyType`_$timestamp.csv"
}

# Export combined emergency policies
Write-Host "Exporting TeamsEmergencyPolicy..."

$reportBasePath = "$network_drive\Teams\TeamsEmergencyPolicy"
if (-not (Test-Path $reportBasePath)) {
    New-Item -ItemType Directory -Path $reportBasePath | Out-Null
}

$results = foreach ($user in $teamsUsers) {
    $userDetails = Get-CsOnlineUser -Identity $user.UserPrincipalName -ErrorAction SilentlyContinue

    foreach ($policyType in $emergencyPolicies) {
        $policyValue = $userDetails.$policyType
        if (-not $policyValue) {
            $policyValue = "Inherited or Default"
        }

        [PSCustomObject]@{
            DisplayName              = $user.DisplayName
            UserPrincipalName        = $user.UserPrincipalName
            PolicyType               = $policyType
            PolicyName               = $policyValue
            InterpretedUserType      = $userDetails.InterpretedUserType
            UsageLocation            = $userDetails.UsageLocation
            EnterpriseVoiceEnabled   = $userDetails.EnterpriseVoiceEnabled
            TeamsUpgradeEffectiveMode = $userDetails.TeamsUpgradeEffectiveMode
            Department               = $userDetails.Department
            Title                    = $userDetails.Title
            SipAddress               = $userDetails.SipAddress
        }
    }
}

$results | Export-Csv -NoTypeInformation -Path "$reportBasePath\TeamsEmergencyPolicy_$timestamp.csv"




