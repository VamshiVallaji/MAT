$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome


$reportPath = "$network_drive\Teams\Unassigned_Numbers\Unassigned_Numbers_$timestamp.csv"


# Connect to Microsoft Teams
Connect-MicrosoftTeams

# Get all phone number assignments
$allNumbers = Get-CsPhoneNumberAssignment

# Filter for unassigned numbers
$unassignedNumbers = $allNumbers | Where-Object {
    $_.PstnAssignmentStatus -eq "Unassigned"
}

# Display total count
$totalUnassigned = $unassignedNumbers.Count
Write-Host "Total Unassigned Numbers: $totalUnassigned"

# Build report
$results = foreach ($num in $unassignedNumbers) {
    [PSCustomObject]@{
        TelephoneNumber     = $num.TelephoneNumber
        NumberType          = $num.NumberType
        ActivationState     = $num.ActivationState
        IsoCountryCode      = $num.IsoCountryCode
        AssignmentStatus    = $num.PstnAssignmentStatus
        Capabilities        = ($num.Capabilities -join ", ")
        totalUnassigned     = $unassignedNumbers.Count
    }
}

# Output to console
#$results | Format-Table -AutoSize

# Optional: Export to CSV
$results | Export-Csv -Path $reportPath -NoTypeInformation
