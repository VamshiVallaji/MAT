$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$timestamp = Get-Date -Format "ddMMyyyy_HHmm"

Install-Module Microsoft.Graph.Reports -Scope CurrentUser -Force

# Install the Beta module for lifecycle policy
Install-Module Microsoft.Graph.Beta.Groups -Scope CurrentUser -Force

# Import modules (optional if auto-import is enabled)
#Import-Module Microsoft.Graph
Import-Module Microsoft.Graph.Reports
Import-Module Microsoft.Graph.Beta.Groups




