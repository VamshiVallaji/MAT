$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$folderPath = "C:\MAT"
$linesToAdd = @(
   '$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID'
   
   '$JsonPath = "$network_drive\Config.json"'

   '$config = Get-Content $JsonPath | ConvertFrom-Json'

   '$tenantId = $config.TenantId'
   '$ClientId = $config.AppId'
   '$Thumbprint = $config.Thumbprint'
)

# Get all files in the folder
Get-ChildItem -Path $folderPath -File | ForEach-Object {
    $filePath = $_.FullName
    $originalContent = Get-Content -Path $filePath
    $newContent = $linesToAdd + $originalContent
    Set-Content -Path $filePath -Value $newContent
}




