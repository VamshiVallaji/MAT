$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\WSP-APP_CatalogReport\WSP-APP_Catalog_Report_$timestamp.csv"

$Report = @()

# ================================
# 1. Tenant App Catalog
# ================================
$TenantApps = Get-PnPApp -Scope Tenant -ErrorAction SilentlyContinue

foreach ($App in $TenantApps) {
    $Report += [PSCustomObject]@{
        CatalogScope = "Tenant"
        AppId = $App.Id
        Title = $App.Title
        AppProductId = $App.AppProductID
        Version = $App.AppVersion
        Deployed = $App.Deployed
        Installed = $App.Installed
        AppType = $App.AppType
        Publisher = $App.Publisher
    }
}

# ================================
# 2. Site Collection App Catalogs
# ================================
$Sites = Get-PnPTenantSite -IncludeOneDriveSites:$false -Filter "Url -like 'sharepoint.com/sites/'"

foreach ($Site in $Sites) {
    try {
        Connect-PnPOnline -Url $Site.Url -ClientId $ClientId -Thumbprint $Thumbprint -Tenant $tenantId

        $SiteApps = Get-PnPApp -Scope Site -ErrorAction SilentlyContinue

        foreach ($App in $SiteApps) {
            $Report += [PSCustomObject]@{
                CatalogScope = "Site"
                SiteUrl = $Site.Url
                AppId = $App.Id
                Title = $App.Title
                AppProductId = $App.AppProductID
                Version = $App.AppVersion
                Deployed = $App.Deployed
                Installed = $App.Installed
                AppType = $App.AppType
                Publisher = $App.Publisher
            }
        }
    }
    catch {
        Write-Host "?? Could not access site app catalog for $($Site.Url)" -ForegroundColor Red
    }
}

# ================================
# Export to CSV
# ================================
if ($Report.Count -gt 0) {
    $Report | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8
    Write-Host "? App Catalog report generated: $reportPath" -ForegroundColor Green
} else {
    Write-Host "?? No apps found in tenant or site app catalogs" -ForegroundColor Yellow
}




