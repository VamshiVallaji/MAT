<#
.SYNOPSIS
  Export on-prem Active Directory group inventory (distribution + security).

.DESCRIPTION
  - PowerShell 5.1 compatible.
  - Requires ActiveDirectory module (RSAT) installed.
  - Produces two CSVs: AD_Groups_Summary.csv and AD_GroupMembers.csv.
  - Can scope to a SearchBase (OU) if desired.
  - Streams members to CSV to handle large groups.

.PARAMETER OutFolder
  Output folder for CSVs (default .\AD_GroupsInventory_yyyyMMdd_HHmmss).

.PARAMETER SearchBase
  Optional LDAP search base (e.g. "OU=Groups,DC=contoso,DC=com"). If empty, searches all groups in the domain.

.PARAMETER ExpandMembers
  Switch. If set, expands group membership using Get-ADGroupMember -Recursive (may be slow for very large groups). If not set, only counts members and writes none to members CSV.

.PARAMETER MaxMembersPerGroup
  When ExpandMembers is set, this limits how many member rows per group will be written (0 = unlimited). Default 0 (no limit).

.EXAMPLE
  .\Get-AD-GroupsInventory.ps1 -OutFolder C:\Reports -SearchBase "OU=Groups,DC=contoso,DC=com" -ExpandMembers
#>

param(
  [string]$SearchBase = "",
  [switch]$ExpandMembers,
  [int]$MaxMembersPerGroup = 0
)
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$OutFolder = "$network_drive\ActiveDirectory\AD_ADDistributionGroupsconifiguration"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
# Ensure TLS (harmless)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$summaryCsv = Join-Path $OutFolder "GroupsSummary\AD_Groups_Summary_$timeStamp.csv"
$membersCsv = Join-Path $OutFolder "GroupMembers\AD_GroupMembers_$timeStamp.csv"

# Check ActiveDirectory module
if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) {
  Write-Host "ActiveDirectory module (RSAT) is not available on this machine. Install RSAT or run on a DC/management host." -ForegroundColor Red
  return
}
Import-Module ActiveDirectory -ErrorAction Stop

# Prepare Get-ADGroup parameters
$ga = @{
  Filter = '*'
  Properties = @('samAccountName','distinguishedName','groupCategory','groupScope','mail','proxyAddresses','managedBy','whenCreated','whenChanged','description','member')
  ErrorAction = 'Stop'
}
if ($SearchBase -and $SearchBase.Trim() -ne '') { $ga['SearchBase'] = $SearchBase }

Write-Host "Querying AD for groups..." -ForegroundColor Cyan
try {
  $groups = Get-ADGroup @ga
} catch {
  Write-Host "Get-ADGroup failed: $($_.Exception.Message)" -ForegroundColor Red
  throw
}

if (-not $groups -or $groups.Count -eq 0) {
  Write-Host "No groups found in scope. Creating header-only CSVs." -ForegroundColor Yellow

  "" | Select-Object `
    Name, SamAccountName, DistinguishedName, GroupCategory, GroupScope, Mail, ProxyAddresses, ManagedBy, MemberCount, WhenCreated, WhenChanged, Description |
    Export-Csv -Path $summaryCsv -NoTypeInformation -Encoding UTF8

  "" | Select-Object GroupDistinguishedName, GroupName, MemberDistinguishedName, MemberSamAccountName, MemberType |
    Export-Csv -Path $membersCsv -NoTypeInformation -Encoding UTF8

  Write-Host "Header-only CSVs created at: $OutFolder" -ForegroundColor Yellow
  return
}

Write-Host ("Retrieved {0} groups. Processing..." -f $groups.Count) -ForegroundColor Green

# Initialize summary rows array (we'll export at end)
$summaryRows = @()

# Prepare members CSV: write header first (streaming)
"" | Select-Object GroupDistinguishedName, GroupName, MemberDistinguishedName, MemberSamAccountName, MemberType |
  Export-Csv -Path $membersCsv -NoTypeInformation -Encoding UTF8

foreach ($g in $groups) {
  # safe assignments
  $name = ""; $sam = ""; $dn = ""; $category = ""; $scope = ""; $mail = ""; $proxy = ""; $managedBy = ""; $created = ""; $changed = ""; $desc = ""
  $memberCount = 0

  try { if ($g.Name) { $name = $g.Name } } catch {}
  try { if ($g.samAccountName) { $sam = $g.samAccountName } } catch {}
  try { if ($g.DistinguishedName) { $dn = $g.DistinguishedName } } catch {}
  try { if ($g.groupCategory) { $category = $g.groupCategory } } catch {}
  try { if ($g.groupScope) { $scope = $g.groupScope } } catch {}
  try { if ($g.mail) { $mail = $g.mail } } catch {}
  try { if ($g.proxyAddresses) { $proxy = ($g.proxyAddresses -join ";") } } catch {}
  try { if ($g.managedBy) { $managedBy = $g.managedBy } } catch {}
  try { if ($g.whenCreated) { $created = $g.whenCreated } } catch {}
  try { if ($g.whenChanged) { $changed = $g.whenChanged } } catch {}
  try { if ($g.description) { $desc = $g.description } } catch {}

  # Member count (use member attribute length if present else call Get-ADGroupMember.Count)
  try {
    if ($g.member -and $g.member.Count -gt 0) { $memberCount = $g.member.Count }
    else {
      # attempt to get count via Get-ADGroupMember (may be slower)
      try {
        $tmp = Get-ADGroupMember -Identity $dn -ErrorAction SilentlyContinue
        if ($tmp) { $memberCount = $tmp.Count }
      } catch { $memberCount = 0 }
    }
  } catch { $memberCount = 0 }

  # If ExpandMembers switch provided, enumerate members and append to members CSV
  if ($ExpandMembers) {
    $written = 0
    try {
      # Use -Recursive to expand nested groups
      $members = Get-ADGroupMember -Identity $dn -Recursive -ErrorAction SilentlyContinue
      if ($members) {
        foreach ($m in $members) {
          $mDn = ""; $mSam = ""; $mType = ""
          try { if ($m.distinguishedName) { $mDn = $m.distinguishedName } } catch {}
          try { if ($m.SamAccountName) { $mSam = $m.SamAccountName } } catch {}
          try { if ($m.objectClass) { $mType = $m.objectClass } } catch {}
          # Append row to members CSV
          $row = [PSCustomObject]@{
            GroupDistinguishedName = $dn
            GroupName = $name
            MemberDistinguishedName = $mDn
            MemberSamAccountName = $mSam
            MemberType = $mType
          }
          $row | Export-Csv -Path $membersCsv -NoTypeInformation -Encoding UTF8 -Append
          $written += 1
          if ($MaxMembersPerGroup -gt 0 -and $written -ge $MaxMembersPerGroup) { break }
        }
      }
    } catch {
      # on errors, append a single row noting failure
      $errRow = [PSCustomObject]@{
        GroupDistinguishedName = $dn
        GroupName = $name
        MemberDistinguishedName = "ERROR: " + $_.Exception.Message
        MemberSamAccountName = ""
        MemberType = "Error"
      }
      $errRow | Export-Csv -Path $membersCsv -NoTypeInformation -Encoding UTF8 -Append
    }
  }

  # Add summary entry
  $summaryRows += [PSCustomObject]@{
    Name = $name
    SamAccountName = $sam
    DistinguishedName = $dn
    GroupCategory = $category
    GroupScope = $scope
    Mail = $mail
    ProxyAddresses = $proxy
    ManagedBy = $managedBy
    MemberCount = $memberCount
    WhenCreated = $created
    WhenChanged = $changed
    Description = $desc
  }
}

# Export summary CSV
try {
  $summaryRows | Export-Csv -Path $summaryCsv -NoTypeInformation -Encoding UTF8
  Write-Host ("Export complete. Summary rows: {0}. Files: {1}, {2}" -f $summaryRows.Count, $summaryCsv, $membersCsv) -ForegroundColor Green
} catch {
  Write-Host ("Export failed: " + $_.Exception.Message) -ForegroundColor Red
  throw
}
