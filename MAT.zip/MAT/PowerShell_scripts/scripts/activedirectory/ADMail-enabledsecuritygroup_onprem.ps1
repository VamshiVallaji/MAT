param(
  [string]$SearchBase = "",
  [int]$MaxMembersPerGroup = 200
)
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$OutFolder = "$network_drive\ActiveDirectory\AD_ADMail-enabledsecuritygroup"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$outCsv = Join-Path $OutFolder "AD_MailEnabledSecurityGroups_$timeStamp.csv"

if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) {
  Write-Host "ActiveDirectory module not found. Install RSAT/Active Directory tools or run on a domain controller/management host." -ForegroundColor Red
  return
}
Import-Module ActiveDirectory -ErrorAction Stop

$ga = @{
  Filter = '*'
  Properties = @('samAccountName','distinguishedName','groupScope','groupCategory','mail','proxyAddresses','managedBy','whenCreated','whenChanged','description','member')
  ErrorAction = 'Stop'
}
if ($SearchBase -and $SearchBase.Trim() -ne '') { $ga['SearchBase'] = $SearchBase }

Write-Host "Querying AD for security groups..." -ForegroundColor Cyan
try {
  $allSecurityGroups = Get-ADGroup @ga | Where-Object { $_.groupCategory -eq "Security" }
} catch {
  Write-Host "Get-ADGroup failed: $($_.Exception.Message)" -ForegroundColor Red
  throw
}

Write-Host ("Retrieved {0} security groups. Processing..." -f $allSecurityGroups.Count) -ForegroundColor Green

$rows = @()
foreach ($g in $allSecurityGroups) {
  $name = ""; $sam = ""; $dn = ""; $scope = ""; $category = ""; $mail = "Mail Not Set"; $proxy = "ProxyAddresses Not Set"
  $managedBy = ""; $managedByName = ""; $created = ""; $changed = ""; $desc = ""
  $memberCount = 0; $membersList = ""

  try { if ($g.Name) { $name = $g.Name } } catch {}
  try { if ($g.samAccountName) { $sam = $g.samAccountName } } catch {}
  try { if ($g.DistinguishedName) { $dn = $g.DistinguishedName } } catch {}
  try { if ($g.groupScope) { $scope = $g.groupScope } } catch {}
  try { if ($g.groupCategory) { $category = $g.groupCategory } } catch {}

  try {
    if ($g.mail -and $g.mail.Trim() -ne '') {
      $mail = $g.mail
    }
  } catch {}

  try {
    if ($g.proxyAddresses -and $g.proxyAddresses.Count -gt 0) {
      $proxy = ($g.proxyAddresses -join ";")
    }
  } catch {}

  try { if ($g.managedBy) { $managedBy = $g.managedBy } } catch {}
  try { if ($g.whenCreated) { $created = $g.whenCreated } } catch {}
  try { if ($g.whenChanged) { $changed = $g.whenChanged } } catch {}
  try { if ($g.description) { $desc = $g.description } } catch {}

  if ($managedBy -and $managedBy.Trim() -ne '') {
    try {
      $mgr = Get-ADObject -Identity $managedBy -Properties displayName -ErrorAction SilentlyContinue
      if ($mgr -and $mgr.displayName) { $managedByName = $mgr.displayName } else { $managedByName = $managedBy }
    } catch { $managedByName = $managedBy }
  }

  $membersCollected = @()
  try {
    $membs = Get-ADGroupMember -Identity $g.DistinguishedName -Recursive -ErrorAction SilentlyContinue
    if ($membs) {
      $memberCount = $membs.Count
      foreach ($m in $membs) {
        $id = ""
        try { if ($m.SamAccountName) { $id = $m.SamAccountName } } catch {}
        if ($id -eq "") {
          try { if ($m.UserPrincipalName) { $id = $m.UserPrincipalName } } catch {}
        }
        if ($id -eq "") {
          try { if ($m.Name) { $id = $m.Name } } catch {}
        }
        if ($id -ne "") { $membersCollected += $id }
        if ($membersCollected.Count -ge $MaxMembersPerGroup) { break }
      }
    }
  } catch {
    $memberCount = -1
  }

  if ($membersCollected.Count -gt 0) {
    $membersList = ($membersCollected -join ";")
  }

  $rows += [PSCustomObject]@{
    Name = $name
    SamAccountName = $sam
    DistinguishedName = $dn
    GroupScope = $scope
    GroupCategory = $category
    Mail = $mail
    ProxyAddresses = $proxy
    ManagedBy = $managedBy
    ManagedByDisplayName = $managedByName
    MemberCount = $memberCount
    Members = $membersList
    WhenCreated = $created
    WhenChanged = $changed
    Description = $desc
  }
}

try {
  $rows | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
  Write-Host ("Export complete. {0} groups written to {1}" -f $rows.Count, $outCsv) -ForegroundColor Green
} catch {
  Write-Host ("Export failed: " + $_.Exception.Message) -ForegroundColor Red
  throw
}
