<#
.SYNOPSIS Export all AD groups and optionally group members.
.PSVersion 5.1
.PARAMETER OutFolder Output folder
.PARAMETER ExpandMembers If present, expand members recursively (may be slow)
#>
param(
  [switch]$ExpandMembers
)

$network_drive = (Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" |
    Select-Object -ExpandProperty DeviceID | Select-Object -First 1)

$OutFolder = "$network_drive\ActiveDirectory\ADSecurityGroupsInformation"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")

if (-not (Test-Path $OutFolder)) { New-Item -Path $OutFolder -ItemType Directory | Out-Null }
$groupsCsv = Join-Path $OutFolder "AllGroups\All_Groups_$timeStamp.csv"
$membersCsv = Join-Path $OutFolder "AllGroupMembers\All_GroupMembers_$timeStamp.csv"

if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) {
  Write-Host "ActiveDirectory module not found. Install RSAT ActiveDirectory." -ForegroundColor Red
  return
}
Import-Module ActiveDirectory -ErrorAction Stop

# Export groups
try {
  #$allGroups = Get-ADGroup -Filter * -Properties samAccountName,groupCategory,groupScope,description,whenCreated,whenChanged -ErrorAction Stop | Sort-Object Name
$allGroups = Get-ADGroup -Filter * -Properties samAccountName,groupCategory,groupScope,description,whenCreated,whenChanged,mail -ErrorAction Stop | Sort-Object Name

} catch {
  Write-Host "Get-ADGroup failed: $($_.Exception.Message)" -ForegroundColor Red
  $allGroups = @()
}

if ($allGroups.Count -eq 0) {
  #"" | Select-Object Name,SamAccountName,GroupCategory,GroupScope,Description,WhenCreated,WhenChanged | Export-Csv -Path $groupsCsv -NoTypeInformation -Encoding UTF8
"" | Select-Object Name,SamAccountName,GroupCategory,GroupScope,Description,whenCreated,whenChanged,
    @{Name = 'IsMailEnabled'; Expression = { if ($_.mail) { $true } else { $false } } } |
    Export-Csv -Path $groupsCsv -NoTypeInformation -Encoding UTF8

  Write-Host "No groups found; header-only CSV created." -ForegroundColor Yellow
} else {
  #$allGroups | Select-Object Name,SamAccountName,GroupCategory,GroupScope,Description,whenCreated,whenChanged | Export-Csv -Path $groupsCsv -NoTypeInformation -Encoding UTF8
$allGroups | Select-Object Name,SamAccountName,GroupCategory,GroupScope,Description,whenCreated,whenChanged,
    @{Name = 'IsMailEnabled'; Expression = { if ($_.mail) { $true } else { $false } } } |
    Export-Csv -Path $groupsCsv -NoTypeInformation -Encoding UTF8

  Write-Host ("Groups exported to: " + $groupsCsv) -ForegroundColor Green
}

# Prepare members CSV header
#"" | Select-Object GroupName,GroupDistinguishedName,MemberDistinguishedName,MemberSamAccountName,MemberType | Export-Csv -Path $membersCsv -NoTypeInformation -Encoding UTF8
"" | Select-Object GroupName,GroupDistinguishedName,MemberDistinguishedName,MemberSamAccountName,MemberType,MemberMail,IsMailEnabled | Export-Csv -Path $membersCsv -NoTypeInformation -Encoding UTF8


if ($ExpandMembers) {
  Write-Host "Expanding members (recursive)..." -ForegroundColor Cyan
  foreach ($g in $allGroups) {
    $gName = $g.Name
    $gDN = $g.DistinguishedName
    try {
      $members = Get-ADGroupMember -Identity $gDN -Recursive -ErrorAction SilentlyContinue
      if ($members) {
        foreach ($m in $members) {
          <#$mDn = "" ; $mSam = "" ; $mType = ""
          try { $mDn = $m.DistinguishedName } catch {}
          try { $mSam = $m.SamAccountName } catch {}
          try { $mType = $m.ObjectClass } catch {}#>
$mDn = "" ; $mSam = "" ; $mType = "" ; $mMail = "" ; $mIsMailEnabled = $false
try { $mDn = $m.DistinguishedName } catch {}
try { $mSam = $m.SamAccountName } catch {}
try { $mType = $m.ObjectClass } catch {}
try { $mMail = $m.mail } catch {}
if ($mMail) { $mIsMailEnabled = $true }

          $row = [PSCustomObject]@{
    GroupName = $gName
    GroupDistinguishedName = $gDN
    MemberDistinguishedName = $mDn
    MemberSamAccountName = $mSam
    MemberType = $mType
    MemberMail = $mMail
    IsMailEnabled = $mIsMailEnabled
}

          $row | Export-Csv -Path $membersCsv -NoTypeInformation -Encoding UTF8 -Append
        }
      }
    } catch {
      $err = [PSCustomObject]@{ GroupName = $gName; GroupDistinguishedName = $gDN; MemberDistinguishedName = "ERROR: " + $_.Exception.Message; MemberSamAccountName = ""; MemberType = "Error" }
      $err | Export-Csv -Path $membersCsv -NoTypeInformation -Encoding UTF8 -Append
    }
  }
  Write-Host "Member expansion complete." -ForegroundColor Green
} else {
  Write-Host "Member expansion skipped. To expand members, re-run with -ExpandMembers." -ForegroundColor Yellow
}
