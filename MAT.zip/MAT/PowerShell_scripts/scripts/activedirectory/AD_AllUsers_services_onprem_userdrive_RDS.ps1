# --- All Users export (network drive, timestamped, includes location + service account flag) ---

# Find a mapped network drive (DriveType=4). Take the first if there are many.
$network_drive = (Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" |
    Select-Object -ExpandProperty DeviceID | Select-Object -First 1)

# Build report path & filename
$Timestamp = Get-Date -Format "yyyyMMdd-HHmm"
$Dom = (Get-ADDomain).DNSRoot
$ReportPath = Join-Path $network_drive "ActiveDirectory\AD_AllUsers_Services"

if (-not (Test-Path -Path $ReportPath)) {
    New-Item -Path $ReportPath -ItemType Directory -Force | Out-Null
}

$FileName = "ADAllUsers_Services_{0}_{1}.csv" -f $Dom, $Timestamp
$FullPath = Join-Path $ReportPath $FileName

# Choose mode: single domain query or per-DC queries
$PerDcQuery = $false

# Properties to request
$props = @(
    'CN', 'Name', 'GivenName', 'Surname', 'DisplayName', 'SamAccountName', 'DistinguishedName',
    'Description', 'UserPrincipalName', 'EmailAddress', 'EmployeeID', 'EmployeeNumber',
    'Office', 'Enabled', 'Manager', 'Title', 'Company', 'Country',
    'Department', 'City', 'HomeDirectory', 'HomeDrive', 'ms-DS-ConsistencyGuid', 'objectGUID',
    'objectSid', 'Organization', 'ProfilePath', 'ScriptPath', 'SIDHistory', 'TrustedForDelegation',
    'PasswordNeverExpires', 'PasswordNotRequired', 'LastLogonDate', 'PasswordLastSet',
    'userParameters'
)

$requestedProps = $props + 'l'
#$calcLocation = @{ Name = 'Location'; Expression = { $_.l } }

if (-not $PerDCQuery) {
    # Calculated properties
    $defaultSuffix = (Get-ADDomain).DNSRoot
    Get-ADUser -Filter * -Properties $requestedProps -ErrorAction Stop |
    Select-Object -Property @($props + @(
            @{Name = 'Location'; Expression = { $_.l } },
            @{Name = 'LastLogonTimestampAgeDays'; Expression = { if ($_.LastLogonDate) { ((Get-Date) - $_.LastLogonDate).Days } else { $null } } },
            @{Name = 'UPNSuffix'; Expression = { if ($_.UserPrincipalName) { $_.UserPrincipalName.Split('@')[1] } else { $null } } },
            @{Name = 'IsAdditionalUPN'; Expression = { if ($_.UserPrincipalName -and ($_.UserPrincipalName -notlike "*$defaultSuffix")) { $true } else { $false } } },
            @{Name = 'IsRoutableUPN'; Expression = {
                    if ($_.UserPrincipalName) {
                        $suffix = $_.UserPrincipalName.Split('@')[1]
                        if ($suffix -notmatch '\.local$|\.corp$|\.internal$') { $true } else { $false }
                    }
                    else { $false }
                }
            },
            @{Name = 'IsServiceAccount'; Expression = {
                    $name = $_.SamAccountName
                    $desc = $_.Description
                    $title = $_.Title
                    $pwdNeverExpires = $_.PasswordNeverExpires

                    if (
                        $name -match '^(svc_|sql_|app_|service_)' -or
            ($desc -and $desc -match 'service|account|automation') -or
            ($title -and $title -match 'service|automation') -or
                        $pwdNeverExpires
                    ) { $true } else { $false }
                }
            }
            @{Name = 'RDSHomeDrive'; Expression = {
                    if ($_.userParameters -match 'TerminalServicesHomeDrive=([^\0]+)') {
                        $matches[1]
                    }
                    else { $null }
                }
            },
            @{Name = 'RDSHomeDirectory'; Expression = {
                    if ($_.userParameters -match 'TerminalServicesHomeDirectory=([^\0]+)') {
                        $matches[1]
                    }
                    else { $null }
                }
            },
            @{Name = 'RDSProfilePath'; Expression = {
                    if ($_.userParameters -match 'TerminalServicesProfilePath=([^\0]+)') {
                        $matches[1]
                    }
                    else { $null }
                }
            }

            
        ))
}
# Run query
if (-not $PerDcQuery) {
    # Single query (recommended) - queries the domain once and exports all users
    $defaultSuffix = (Get-ADDomain).DNSRoot

    Get-ADUser -Filter * -Properties $requestedProps -ErrorAction Stop |
    Select-Object -Property @($props + @(
            @{Name = 'Location'; Expression = { $_.l } },
            @{Name = 'LastLogonTimestampAgeDays'; Expression = { if ($_.LastLogonDate) { ((Get-Date) - $_.LastLogonDate).Days } else { $null } } },
            @{Name = 'UPNSuffix'; Expression = { if ($_.UserPrincipalName) { $_.UserPrincipalName.Split('@')[1] } else { $null } } },
            @{Name = 'IsAdditionalUPN'; Expression = { if ($_.UserPrincipalName -and ($_.UserPrincipalName -notlike "*$defaultSuffix")) { $true } else { $false } } },
            @{Name = 'IsRoutableUPN'; Expression = {
                    if ($_.UserPrincipalName) {
                        $suffix = $_.UserPrincipalName.Split('@')[1]
                        if ($suffix -notmatch '\.local$|\.corp$|\.internal$') { $true } else { $false }
                    }
                    else {
                        $false
                    }
                }
            }
           
            @{Name = 'IsServiceAccount'; Expression = {
                    $name = $_.SamAccountName
                    $desc = $_.Description
                    $title = $_.Title
                    $pwdNeverExpires = $_.PasswordNeverExpires

                    if (
                        $name -match '^(svc_|sql_|app_|service_)' -or
                    ($desc -and $desc -match 'service|account|automation') -or
                    ($title -and $title -match 'service|automation') -or
                        $pwdNeverExpires
                    ) { $true } else { $false }
                }
            }
            @{Name = 'RDSHomeDrive'; Expression = {
                    if ($_.userParameters -match 'TerminalServicesHomeDrive=([^\0]+)') {
                        $matches[1]
                    }
                    else { $null }
                }
            },
            @{Name = 'RDSHomeDirectory'; Expression = {
                    if ($_.userParameters -match 'TerminalServicesHomeDirectory=([^\0]+)') {
                        $matches[1]
                    }
                    else { $null }
                }
            },
            @{Name = 'RDSProfilePath'; Expression = {
                    if ($_.userParameters -match 'TerminalServicesProfilePath=([^\0]+)') {
                        $matches[1]
                    }
                    else { $null }
                }
            }


        )) |
    Export-Csv -Path $FullPath -NoTypeInformation -Encoding UTF8


    Write-Host "Saved All users report to: $FullPath"
}
else {
    $dcs = Get-ADDomainController -Filter * | Select-Object -ExpandProperty HostName
    if (-not $dcs) { Throw "No domain controllers found." }

    if (Test-Path $FullPath) { Remove-Item $FullPath -Force }

    $first = $true
    foreach ($dc in $dcs) {
        Write-Host "Querying DC: $dc" -ForegroundColor Cyan
        try {
            $defaultSuffix = (Get-ADDomain).DNSRoot
            $users = Get-ADUser -Server $dc -Filter * -Properties $requestedProps -ErrorAction Stop |
            Select-Object -Property @($props + @(
                    @{Name = 'Location'; Expression = { $_.l } },
                    @{Name = 'LastLogonTimestampAgeDays'; Expression = { if ($_.LastLogonDate) { ((Get-Date) - $_.LastLogonDate).Days } else { $null } } },
                    @{Name = 'UPNSuffix'; Expression = { if ($_.UserPrincipalName) { $_.UserPrincipalName.Split('@')[1] } else { $null } } },
                    @{Name = 'IsAdditionalUPN'; Expression = { if ($_.UserPrincipalName -and ($_.UserPrincipalName -notlike "*$defaultSuffix")) { $true } else { $false } } }
                    @{Name = 'IsRoutableUPN'; Expression = {
                            if ($_.UserPrincipalName) {
                                $suffix = $_.UserPrincipalName.Split('@')[1]
                                if ($suffix -notmatch '\.local$|\.corp$|\.internal$') { $true } else { $false }
                            }
                            else {
                                $false
                            }
                        }
                    }
                    
                    @{Name = 'IsServiceAccount'; Expression = {
                            $name = $_.SamAccountName
                            $desc = $_.Description
                            $title = $_.Title
                            $pwdNeverExpires = $_.PasswordNeverExpires

                            if (
                                $name -match '^(svc_|sql_|app_|service_)' -or
                    ($desc -and $desc -match 'service|account|automation') -or
                    ($title -and $title -match 'service|automation') -or
                                $pwdNeverExpires
                            ) { $true } else { $false }
                        }
                    }
                    @{Name = 'RDSHomeDrive'; Expression = {
                            if ($_.userParameters -match 'TerminalServicesHomeDrive=([^\0]+)') {
                                $matches[1]
                            }
                            else { $null }
                        }
                    },
                    @{Name = 'RDSHomeDirectory'; Expression = {
                            if ($_.userParameters -match 'TerminalServicesHomeDirectory=([^\0]+)') {
                                $matches[1]
                            }
                            else { $null }
                        }
                    },
                    @{Name = 'RDSProfilePath'; Expression = {
                            if ($_.userParameters -match 'TerminalServicesProfilePath=([^\0]+)') {
                                $matches[1]
                            }
                            else { $null }
                        }
                    }


                ))

            if ($first) {
                $users | Export-Csv -Path $FullPath -NoTypeInformation -Encoding UTF8
                $first = $false
            }
            else {
                $users | Export-Csv -Path $FullPath -NoTypeInformation -Encoding UTF8 -Append
            }
        }
        catch {
            Write-Warning "Failed to query $dc : $_"
        }
    }

    Write-Host "Saved per-DC All users report to: $FullPath"
}
