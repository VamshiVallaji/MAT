#Export DFSN
$network_drive = (Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" |
    Select-Object -ExpandProperty DeviceID | Select-Object -First 1)
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$outputCsv = "$network_drive\ActiveDirectory\AD_DFS\DFSN_Export_$timestamp.csv"
$results = @()

# Get configuration naming context
$configurationContainer = ([adsi]"LDAP://RootDSE").Get("ConfigurationNamingContext")
$partitions = ([adsi]"LDAP://CN=Partitions,$configurationContainer").psbase.children

# Get all domain controllers
$DCs = Get-ADDomainController -Filter * | Select-Object -ExpandProperty HostName

foreach ($partition in $partitions) {
    if ($partition.netbiosName -ne "") {
        $partitionDN = $partition.ncName
        $dnsName = $partitionDN.ToString().Replace("DC=", ".").Replace(",", "").Substring(1)
        $domain = $partition.netbiosName

        foreach ($dc in $DCs) {
            Write-Host "Querying DFS roots from DC: $dc for domain: $domain" -ForegroundColor Cyan
            try {
                $dfsContainer = [adsi]"LDAP://$dc/cn=Dfs-Configuration,cn=System,$partitionDN"
                $dfsRoots = $dfsContainer.psbase.children

                if ($dfsRoots.Count -eq 0) {
                    Write-Warning "No DFS roots found on DC: $dc for domain: $domain"
                }

                foreach ($dfsRoot in $dfsRoots) {
                    $rootName = $dfsRoot.cn
                    $dfsPath = "\\$dnsName\$rootName"
                    $xmlPath = "C:\Temp\$domain\$rootName.xml"

                    # Ensure domain folder exists
                    if (-not (Test-Path "C:\Temp\$domain")) {
                        New-Item -Path "C:\Temp\$domain" -ItemType Directory | Out-Null
                    }

                    # Export DFS root to XML
                    dfsutil root export $dfsPath $xmlPath

                    # Log and collect result
                    Write-Host "Exported DFS root: $dfsPath to $xmlPath"
                    $results += [PSCustomObject]@{
                        Domain         = $domain
                        DCQueried      = $dc
                        DFSRoot        = $rootName
                        DFSPath        = $dfsPath
                        ExportedXml    = $xmlPath
                    }
                }
            } catch {
                Write-Warning "Failed to query DFS roots from DC $dc for domain $domain $_"
            }
        }
    }
}

# Fallback if no data collected
if ($results.Count -eq 0) {
    Write-Warning "No DFS roots found across all DCs. Adding fallback row to CSV."
    $results += [PSCustomObject]@{
        Domain         = "No data"
        DCQueried      = "N/A"
        DFSRoot        = "N/A"
        DFSPath        = "N/A"
        ExportedXml    = "N/A"
    }
}

# Export results to CSV
$results | Export-Csv -Path $outputCsv -NoTypeInformation -Encoding UTF8
Write-Host "DFS configuration exported to: $outputCsv" -ForegroundColor Green
