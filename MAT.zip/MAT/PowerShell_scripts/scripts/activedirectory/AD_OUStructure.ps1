# Set output path
$network_drive = (Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" |
    Select-Object -ExpandProperty DeviceID | Select-Object -First 1)

$Timestamp = Get-Date -Format "yyyyMMdd-HHmm"
$Domain = (Get-ADDomain).DNSRoot
$OutputPath = "$network_drive\ActiveDirectory\AD_OUStructure\OU_Structure_$Domain_$Timestamp.csv"

$DCs = Get-ADDomainController -Filter * | Select-Object -ExpandProperty HostName
$allOUs = @()

foreach ($dc in $DCs) {
    Write-Host "Querying DC: $dc" -ForegroundColor Cyan
    try {
        $OUs = Get-ADOrganizationalUnit -Server $dc -Filter * -Properties * |
        Sort-Object DistinguishedName | ForEach-Object {
            [PSCustomObject]@{
                DC                  = $dc
                Name                = $_.Name
                DistinguishedName   = $_.DistinguishedName
                Path                = $_.CanonicalName
                ParentOU            = ($_.DistinguishedName -replace '^.+?,OU=(.+)$', 'OU=\1')
                ProtectedFromAccidentalDeletion = $_.ProtectedFromAccidentalDeletion
            }
        }
        $allOUs += $OUs
    }
    catch {
        Write-Warning "Failed to query $dc : $_"
    }
}

$allOUs | Export-Csv -Path $OutputPath -NoTypeInformation -Encoding UTF8
Write-Host "OU structure exported to: $OutputPath"
