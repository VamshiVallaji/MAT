$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
Get-ADUser -Filter * -Properties DisplayName, SamAccountName, UserPrincipalName | Select-Object DisplayName, SamAccountName, UserPrincipalName | Export-Csv "Z:\ActiveDirectory\AD_AdditionalUPNlist\AD_Users_UPN_$timeStamp.csv" -NoTypeInformation -Force
