<#
.SYNOPSIS
  Export AD computer inventory using Get-ADComputer (the cmd you mentioned).

.DESCRIPTION
  Uses Get-ADComputer -Filter * -Properties ... to collect computer accounts and export CSV.
  Includes basic checks for ActiveDirectory module, domain join and simple error handling.

.PARAMETER OutFolder
  Output folder for CSV (default current folder with timestamp).
.PARAMETER SearchBase
  Optional LDAP search base to scope results (leave empty to search whole domain).
#>
param(
    [string]$SearchBase = ""
)
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$OutFolder = "$network_drive\ActiveDirectory\AD_AllComputersInventory"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
# Create output folder
$csvPath = Join-Path $OutFolder "AD_ComputersInventory_$timeStamp.csv"

# Quick pre-checks
Write-Host "Checking ActiveDirectory module..." -ForegroundColor Cyan
if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) {
  Write-Host "ActiveDirectory module (RSAT) not available. Install RSAT or run on a DC / management host." -ForegroundColor Red
  return
}

# Import module
try { Import-Module ActiveDirectory -ErrorAction Stop } catch { Write-Host "Failed to import AD module: $($_.Exception.Message)" -ForegroundColor Red; return }

# Verify domain context
try {
  $domain = (Get-ADDomain -ErrorAction Stop).DNSRoot
  Write-Host "Running in domain: $domain" -ForegroundColor Green
} catch {
  Write-Host "Unable to determine domain. Are you on a domain-joined machine with permission to query AD?" -ForegroundColor Red
  return
}

# Build properties list like your cmd (add commonly useful attributes)
$properties = @(
  'Name','DNSHostName','OperatingSystem','OperatingSystemVersion','Enabled',
  'Description','DistinguishedName','whenCreated','whenChanged','LastLogonDate',
  'pwdLastSet','PasswordLastSet','ManagedBy','servicePrincipalName','userAccountControl'
)

# Prepare parameters for Get-ADComputer
$ga = @{
  Filter = '*'
  Properties = $properties
  ErrorAction = 'Stop'
}
if ($SearchBase -and $SearchBase.Trim() -ne '') { $ga['SearchBase'] = $SearchBase }

# Run the query (this is the core "cmd you gave" approach)
Write-Host "Querying AD for computers..." -ForegroundColor Cyan
try {
  $computers = Get-ADComputer @ga
} catch {
  Write-Host "Get-ADComputer failed: $($_.Exception.Message)" -ForegroundColor Red
  return
}

if (-not $computers -or $computers.Count -eq 0) {
  Write-Host "No computer objects returned. Possible causes:" -ForegroundColor Yellow
  Write-Host " - Incorrect SearchBase (if provided)" -ForegroundColor Yellow
  Write-Host " - Insufficient permissions to read computer objects" -ForegroundColor Yellow
  Write-Host " - There are indeed no computer objects in this scope" -ForegroundColor Yellow
  # create header-only CSV
  "" | Select-Object Name,DNSHostName,OperatingSystem,OperatingSystemVersion,Enabled,Description,DistinguishedName,WhenCreated,WhenChanged,LastLogonDate,PasswordLastSet,ManagedBy,ServicePrincipalNames,UserAccountControl |
    Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
  Write-Host "Header-only CSV created at $csvPath" -ForegroundColor Yellow
  return
}

# Flatten results and export CSV
Write-Host ("Processing {0} computer objects..." -f $computers.Count) -ForegroundColor Green
$rows = @()
foreach ($c in $computers) {
  # safe retrieval of attributes
  $name = ""; $dns = ""; $os = ""; $osver = ""; $enabled = ""; $desc = ""; $dn = ""
  $created = ""; $changed = ""; $lastLogon = ""; $pwdSet = ""; $managedBy = ""; $spns = ""; $uac = ""
  try { if ($c.Name) { $name = $c.Name } } catch {}
  try { if ($c.DNSHostName) { $dns = $c.DNSHostName } } catch {}
  try { if ($c.OperatingSystem) { $os = $c.OperatingSystem } } catch {}
  try { if ($c.OperatingSystemVersion) { $osver = $c.OperatingSystemVersion } } catch {}
  try { if ($c.Enabled -ne $null) { $enabled = $c.Enabled } } catch {}
  try { if ($c.Description) { $desc = $c.Description } } catch {}
  try { if ($c.DistinguishedName) { $dn = $c.DistinguishedName } } catch {}
  try { if ($c.whenCreated) { $created = $c.whenCreated } } catch {}
  try { if ($c.whenChanged) { $changed = $c.whenChanged } } catch {}
  try { if ($c.LastLogonDate) { $lastLogon = $c.LastLogonDate } } catch {}
  # password last set
  try {
    if ($c.PasswordLastSet) { $pwdSet = $c.PasswordLastSet }
    elseif ($c.pwdLastSet) {
      $raw = [string]$c.pwdLastSet
      if ($raw -match '^\d+$') {
        try { $pwdSet = [DateTime]::FromFileTimeUtc([int64]$raw) } catch { $pwdSet = $raw }
      } else { $pwdSet = $raw }
    }
  } catch {}
  try { if ($c.managedBy) { $managedBy = $c.managedBy } } catch {}
  try { if ($c.servicePrincipalName) { $spns = ($c.servicePrincipalName -join ';') } } catch {}
  try { if ($c.userAccountControl) { $uac = $c.userAccountControl } } catch {}

  $rows += [PSCustomObject]@{
    Name = $name
    DNSHostName = $dns
    OperatingSystem = $os
    OperatingSystemVersion = $osver
    Enabled = $enabled
    Description = $desc
    DistinguishedName = $dn
    WhenCreated = $created
    WhenChanged = $changed
    LastLogonDate = $lastLogon
    PasswordLastSet = $pwdSet
    ManagedBy = $managedBy
    ServicePrincipalNames = $spns
    UserAccountControl = $uac
  }
}

# Export
try {
  $rows | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
  Write-Host ("Export complete. {0} rows written to {1}" -f $rows.Count, $csvPath) -ForegroundColor Green
} catch {
  Write-Host "Export failed: $($_.Exception.Message)" -ForegroundColor Red
}
