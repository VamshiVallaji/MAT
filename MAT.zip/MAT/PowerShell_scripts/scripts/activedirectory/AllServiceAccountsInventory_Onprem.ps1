# ===============================
# On-Prem AD Service Accounts Inventory (Non-Interactive)
# ===============================

#Set-DnsClientServerAddress -InterfaceAlias "Ethernet" -ServerAddress ("172.16.0.5","172.16.0.6")

# --- Credentials ---

$DCs= @("mataddc2.mat.com","mataddc3.mat.com")

$Username = "matpowershell2\azureuser"
$Password = "Mat@2025" | ConvertTo-SecureString -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential ($Username, $Password)


# Output CSV
$OutputCsv = "Z:\AD_Frst_ChildDmn_DC_FSMO_SitesSubnetsSitelnk_Trust_OU_DNS_AcntLockut_DFS_AllUsr_SrcAcnt\ADServiceAccountsInventory_onprem__$(Get-Date -Format 'yyyyMMdd_HHmm').csv"



$allServiceAccounts = @()

foreach ($DC in $DCs) {
Write-Host "Connecting to $DC ... "
try {

# Get all AD users where service accounts are identified
#$Users = Get-ADUser -Filter * -Server $DC -Credential $Credential -Properties 
$users = Get-ADUser -Server $DC -Credential $Credential -Filter * -Properties SamAccountName, DisplayName, UserPrincipalName, Enabled, Description, PasswordNeverExpires, PasswordExpired, AccountExpirationDate, WhenCreated, WhenChanged, Manager, Department, Title, ServicePrincipalName 

$serviceAccounts = $users | Where-Object {
    ($_.Description -match "svc|service|app") -or ($_.SamAccountName -match "svc|sa|app")
}

$allServiceAccounts += $serviceAccounts
}
catch {
Write-Warning "Failed to connect to $DC. Error: $_"
}
}

$uniqueServiceAccounts = $allServiceAccounts | Sort-Object SamAccountName -Unique
# Format inventory with Yes/No for boolean fields
$inventory = $uniqueServiceAccounts | Select-Object `
    Name,
    SamAccountName,
    UserPrincipalName,
    @{Name='Enabled';Expression={if ($_.Enabled) {'Yes'} else {'No'}}},
    @{Name='PasswordNeverExpires';Expression={if ($_.PasswordNeverExpires) {'Yes'} else {'No'}}},
    @{Name='PasswordExpired';Expression={if ($_.PasswordExpired) {'Yes'} else {'No'}}},
    AccountExpirationDate,
    WhenCreated,
    WhenChanged,
    Department,
    Title,
    Manager,
    Description,
    @{Name='ServicePrincipalNames';Expression={[string]::join(";", ($_.ServicePrincipalName))}}

# Export to CSV
$inventory | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding UTF8
Write-Host "On-Prem AD Service Accounts exported to $OutputCsv"
