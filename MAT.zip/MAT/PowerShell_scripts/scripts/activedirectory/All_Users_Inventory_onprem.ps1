# ================================
# Configuration
# ================================
$DomainControllers = @("mataddc2.mat.com","mataddc3.mat.com")
$OutputFile = "Z:\AD_Frst_ChildDmn_DC_FSMO_SitesSubnetsSitelnk_Trust_OU_DNS_AcntLockut_DFS_AllUsr_SrcAcnt\AD_OnPrem_Users_Inventory__$(Get-Date -Format 'yyyyMMdd_HHmm').csv"
#$Credential = New-Object System.Management.Automation.PSCredential ("DOMAIN\AdminUser",(ConvertTo-SecureString "YourPassword" -AsPlainText -Force))

$Username = "matpowershell2\azureuser"
$Password = "Mat@2025" | ConvertTo-SecureString -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential ($Username, $Password)


# Prepare report array
$Report = @()

# ================================
# Loop through each DC
# ================================
foreach ($DC in $DomainControllers) {
    Write-Host "`nProcessing users from $DC ..." -ForegroundColor Cyan

    $Users = Get-ADUser -Filter * -Server $DC -Credential $Credential -Properties CN,Name,GivenName,Surname,DisplayName,SamAccountName,DistinguishedName,Description,UserPrincipalName,EmailAddress,EmployeeID,EmployeeNumber,Enabled,Manager,Title,Company,Country,Department,HomeDirectory,HomeDrive,'mS-DS-ConsistencyGuid',ObjectGUID,ObjectSid,Organization,ProfilePath,ScriptPath,SID,SIDHistory,TrustedForDelegation,PasswordNeverExpires,PasswordNotRequired,LastLogonDate,PasswordLastSet,LastLogonTimestamp,whenCreated,whenChanged

    foreach ($User in $Users) {
        $ManagerName = $null
        if ($User.Manager) {
            $ManagerName = (Get-ADUser -Identity $User.Manager -Properties DisplayName -Server $DC -Credential $Credential -ErrorAction SilentlyContinue).DisplayName
        }

        $Report += [PSCustomObject]@{
            DC = $DC
            CN = $User.CN
            Name = $User.Name
            GivenName = $User.GivenName
            Surname = $User.Surname
            DisplayName = $User.DisplayName
            SamAccountName = $User.SamAccountName
            DistinguishedName = $User.DistinguishedName
            Description = $User.Description
            UserPrincipalName = $User.UserPrincipalName
            EmailAddress = $User.EmailAddress
            EmployeeID = $User.EmployeeID
            EmployeeNumber = $User.EmployeeNumber
            Enabled = $User.Enabled
            Manager = $ManagerName
            Title = $User.Title
            Company = $User.Company
            Country = $User.Country
            Department = $User.Department
            HomeDirectory = $User.HomeDirectory
            HomeDrive = $User.HomeDrive
            'mS-DS-ConsistencyGuid'= if ($User.'mS-DS-ConsistencyGuid') { [System.Guid]::New($User.'mS-DS-ConsistencyGuid')}
else {$null}
            ObjectGUID = $User.ObjectGUID
            ObjectSid = $User.ObjectSid
            Organization = $User.Organization
            ProfilePath = $User.ProfilePath
            ScriptPath = $User.ScriptPath
            SID = $User.SID
            SIDHistory = ($User.SIDHistory -join ";")
            TrustedForDelegation = $User.TrustedForDelegation
            PasswordNeverExpires = $User.PasswordNeverExpires
            PasswordNotRequired = $User.PasswordNotRequired
            LastLogonDate = $User.LastLogonDate
            PasswordLastSet = $User.PasswordLastSet
            LastLogonTimestamp = if ($User.LastLogonTimestamp) { [DateTime]::FromFileTime($User.LastLogonTimestamp) } else { $null }
            Age = ((Get-Date) - $User.whenCreated).Days
            Status = if ($User.Enabled) {"Active"} else {"Disabled"}
        }
    }
}

# ================================
# Export Combined Report
# ================================
Write-Host "`nRemoving duplicate users based on ObjectGUID..." -ForegroundColor Yellow
$UniqueReport = $Report | Sort-Object ObjectGUID -Unique

Write-Host "`nExporting consolidated report to CSV..." -ForegroundColor Yellow
$UniqueReport | Export-Csv -Path $OutputFile -NoTypeInformation -Encoding UTF8
Write-Host "AD Users Inventory report generated: $OutputFile" -ForegroundColor Green
