<#
.SYNOPSIS
  Export SAML SSO configuration for enterprise applications (service principals).
  PowerShell 5.1 compatible. Creates header-only CSV when no results.

.NOTES
  - Requires Microsoft.Graph module available (no Install-Module inside).
  - App used to connect must have ServicePrincipal.Read.All or Directory.Read.All (application permission).
#>

$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\ActiveDirectory\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutFolder = "Z:\AD_ApplicationsutilizingAzureADforSSO"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$FileName = "SAML_SSO_Configurations_$timeStamp.csv"

# ensure TLS
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$outputFile = Join-Path $OutFolder $FileName

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

# collect all service principals (we'll check for saml settings)
Write-Host "Enumerating service principals..." -ForegroundColor Cyan
$allSPs = @()
$spUri = "https://graph.microsoft.com/v1.0/servicePrincipals?`$select=id,appId,displayName,preferredSingleSignOnMode,servicePrincipalType&`$top=999"

do {
  try {
    $res = Invoke-MgGraphRequest -Method GET -Uri $spUri -ErrorAction Stop
    if ($res -and $res.value) { $allSPs += $res.value }
    $spUri = $null
    try { $spUri = $res.'@odata.nextLink' } catch { $spUri = $null }
  } catch {
    Write-Warning "Failed to retrieve service principals: $_"
    $spUri = $null
  }
} while ($spUri)

Write-Host "Fetched $($allSPs.Count) service principals." -ForegroundColor Green

# prepare output collection
$ssoConfigs = @()

Write-Host "Inspecting each service principal for SAML configuration..." -ForegroundColor Cyan

foreach ($sp in $allSPs) {
  # safe extraction
  $spId = ""; try { $spId = $sp.id } catch {}
  $appId = ""; try { $appId = $sp.appId } catch {}
  $displayName = ""; try { $displayName = $sp.displayName } catch {}
  $ssoMode = ""; try { $ssoMode = $sp.preferredSingleSignOnMode } catch {}
  $spType = ""; try { $spType = $sp.servicePrincipalType } catch {}

  # We are interested in SAML configuration only for this script
  $hasSaml = $false
  $entityId = ""
  $singleSignOnUrl = ""
  $logoutUrl = ""
  $AssignmentRequired = $false
  $userAssignments = ""
  $groupAssignments = ""
  $SignInAudience = ""
  $PreferredTokenSigningKeyThumbprint = ""
  $certificateExpirationDate = ""

  try {
    # Attempt to get samlSingleSignOnSettings for the SP
    $samlUri = "https://graph.microsoft.com/v1.0/servicePrincipals/$spId/samlSingleSignOnSettings"
    $samlRes = Invoke-MgGraphRequest -Method GET -Uri $samlUri -ErrorAction SilentlyContinue

    if ($samlRes -and ($samlRes.value -and $samlRes.value.Count -gt 0)) {
      # If value array returned, pick first (settings are often objects in array)
      $samlObj = $samlRes.value[0]
      $hasSaml = $true
    } elseif ($samlRes -and ($samlRes.id -or $samlRes.entityId -or $samlRes.singleSignOnUrl)) {
      # sometimes a direct object is returned
      $samlObj = $samlRes
      $hasSaml = $true
    } else {
      # fallback: check the preferredSingleSignOnMode property
      if ($ssoMode -and $ssoMode.ToLower() -eq "saml") { $hasSaml = $true }
    }
  } catch {
    # ignore and continue
    $hasSaml = $false
  }

  if ($hasSaml) {
    # extract safe fields from $samlObj if present
    try { if ($samlObj.entityId) { $entityId = $samlObj.entityId } } catch {}
    try { if ($samlObj.singleSignOnUrl) { $singleSignOnUrl = $samlObj.singleSignOnUrl } } catch {}
    try { if ($samlObj.logoutUrl) { $logoutUrl = $samlObj.logoutUrl } } catch {}
    try { if ($samlObj.assignmentRequired -ne $null) { $AssignmentRequired = $samlObj.assignmentRequired } } catch {}
    try { if ($samlObj.preferredTokenSigningKeyThumbprint) { $PreferredTokenSigningKeyThumbprint = $samlObj.preferredTokenSigningKeyThumbprint } } catch {}
    try { if ($samlObj.certificateExpirationDateTime) { $certificateExpirationDate = $samlObj.certificateExpirationDateTime } } catch {}

    # fetch role/user assignments for the service principal (who is assigned to the enterprise app)
    try {
      $assignUri = "https://graph.microsoft.com/v1.0/servicePrincipals/$spId/appRoleAssignedTo"
      $assignRes = Invoke-MgGraphRequest -Method GET -Uri $assignUri -ErrorAction SilentlyContinue
      $users = @(); $groups = @()
      if ($assignRes -and $assignRes.value) {
        foreach ($a in $assignRes.value) {
          try {
            if ($a.principalType -and ($a.principalType -eq "User")) {
              if ($a.principalDisplayName) { $users += $a.principalDisplayName } elseif ($a.principalId) { $users += $a.principalId }
            } elseif ($a.principalType -and ($a.principalType -eq "Group")) {
              if ($a.principalDisplayName) { $groups += $a.principalDisplayName } elseif ($a.principalId) { $groups += $a.principalId }
            }
          } catch {}
        }
      }
      if ($users.Count -gt 0) { $userAssignments = ($users -join ";") }
      if ($groups.Count -gt 0) { $groupAssignments = ($groups -join ";") }
    } catch {}

    # build object and add to collection
    $obj = [PSCustomObject]@{
      ServicePrincipalId = $spId
      AppId = $appId
      DisplayName = $displayName
      ServicePrincipalType = $spType
      PreferredSingleSignOnMode = $ssoMode
      HasSamlSettings = $true
      EntityId = $entityId
      SingleSignOnUrl = $singleSignOnUrl
      LogoutUrl = $logoutUrl
      AssignmentRequired = $AssignmentRequired
      UserAssignments = $userAssignments
      GroupAssignments = $groupAssignments
      SignInAudience = $SignInAudience
      PreferredTokenSigningKeyThumbprint = $PreferredTokenSigningKeyThumbprint
      CertificateExpiration = $certificateExpirationDate
      Notes = "SAML detected"
    }

    $ssoConfigs += $obj
  } else {
    # no SAML for this SP (skip)
    # Write-Host "No SAML SSO for $displayName" -ForegroundColor Gray
  }
}

# Export: ensure header row if $ssoConfigs is empty
$headers = @(
  "ServicePrincipalId","AppId","DisplayName","ServicePrincipalType","PreferredSingleSignOnMode",
  "HasSamlSettings","EntityId","SingleSignOnUrl","LogoutUrl","AssignmentRequired",
  "UserAssignments","GroupAssignments","SignInAudience","PreferredTokenSigningKeyThumbprint",
  "CertificateExpiration","Notes"
)

if ($ssoConfigs.Count -eq 0) {
  Write-Host "No SAML SSO configurations found. Creating header-only CSV at: $outputFile" -ForegroundColor Yellow
  # create a header-only CSV (no data rows)
  "" | Select-Object $headers | Export-Csv -Path $outputFile -NoTypeInformation -Encoding UTF8
} else {
  # export real results (explicit order)
  $ssoConfigs | Select-Object $headers | Export-Csv -Path $outputFile -NoTypeInformation -Encoding UTF8
  Write-Host "Exported $($ssoConfigs.Count) SAML SSO entries to: $outputFile" -ForegroundColor Green
}

# disconnect
try { Disconnect-MgGraph -ErrorAction SilentlyContinue } catch {}
