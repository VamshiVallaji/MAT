<#
.SYNOPSIS
  Inventory Azure AD Guest accounts (userType = 'Guest') via Invoke-MgGraphRequest.

.DESCRIPTION
  - PowerShell 5.1 compatible.
  - Uses app-only auth (client secret).
  - Exports guest accounts to CSV.
  - Relies only on Invoke-MgGraphRequest (no Get-MgUser needed).

.PARAMETER TenantId
  Tenant ID or tenant domain (e.g. contoso.onmicrosoft.com)

.PARAMETER ClientId
  App (client) id used to authenticate.

.PARAMETER ClientSecret
  Client secret for the app.

.PARAMETER OutFolder
  Output folder to store CSV report.

.EXAMPLE
  .\Get-AADGuestUsers-InvokeOnly.ps1 -TenantId 'contoso.onmicrosoft.com' -ClientId 'xxxx' -ClientSecret 'secret' -OutFolder 'C:\Reports\AADGuests'
#>

$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\ActiveDirectory\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutFolder = "$network_drive\ActiveDirectory\AD_AzureADGuestAccountlist"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")

# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

# ------------------------------------
# Collect all Guest Users (Invoke-only)
# ------------------------------------
Write-Host "Fetching Guest users via Graph REST (Invoke-MgGraphRequest)..."
$guestUsers = @()
$uri = "https://graph.microsoft.com/v1.0/users?`$filter=userType eq 'Guest'&`$top=999"

try {
  do {
      $res = Invoke-MgGraphRequest -Method GET -Uri $uri -ErrorAction Stop
      if ($res.value) { $guestUsers += $res.value }
      $uri = $null
      try { $uri = $res.'@odata.nextLink' } catch {}
  } while ($uri)
} catch {
  Write-Warning "Graph call failed: $_"
  # continue so we still generate a header-only CSV if desired
}

Write-Host "Collected $($guestUsers.Count) guest accounts."

# ------------------------------------
# Build report (rows)
# ------------------------------------
$report = @()

foreach ($u in $guestUsers) {
    # safe extraction of properties
    $id = $null; try { $id = $u.id } catch {}
    $upn = $null; try { $upn = $u.userPrincipalName } catch {}
    $disp = $null; try { $disp = $u.displayName } catch {}
    $mail = $null; try { $mail = $u.mail } catch {}
    $ctype = $null; try { $ctype = $u.userType } catch {}
    $created = $null; try { $created = $u.createdDateTime } catch {}

    $extState = $null; try { $extState = $u.externalUserState } catch {}
    $extStateChange = $null; try { $extStateChange = $u.externalUserStateChangeDateTime } catch {}

    $jobTitle = $null; try { $jobTitle = $u.jobTitle } catch {}
    $dept = $null; try { $dept = $u.department } catch {}
    $company = $null; try { $company = $u.companyName } catch {}

    $otherMails = ""; try { if ($u.otherMails) { $otherMails = ($u.otherMails -join ";") } } catch {}
    $proxyAddresses = ""; try { if ($u.proxyAddresses) { $proxyAddresses = ($u.proxyAddresses -join ";") } } catch {}

    # Manager lookup (optional; safe)
    $managerName = ""
    try {
        $mgrRes = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/users/$id/manager" -ErrorAction SilentlyContinue
        if ($mgrRes -and $mgrRes.displayName) { $managerName = $mgrRes.displayName }
    } catch {}

    # Groups/roles membership count (safe)
    $memberOfCount = 0
    try {
        $memRes = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/users/$id/memberOf?$select=id" -ErrorAction SilentlyContinue
        if ($memRes -and $memRes.value) { $memberOfCount = $memRes.value.Count }
    } catch {}

    # Invitation info (who invited)
    $invitedBy = ""
    try {
        $invRes = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/invitations?`$filter=invitedUserId eq '$id'" -ErrorAction SilentlyContinue
        if ($invRes -and $invRes.value -and $invRes.value.Count -gt 0) {
            $invitedBy = $invRes.value[0].invitedByUser.displayName
        }
    } catch {}

    $report += [PSCustomObject]@{
        Id = $id
        DisplayName = $disp
        UserPrincipalName = $upn
        Mail = $mail
        UserType = $ctype
        CreatedDateTime = $created
        ExternalUserState = $extState
        ExternalUserStateChangeDate = $extStateChange
        JobTitle = $jobTitle
        Department = $dept
        CompanyName = $company
        OtherMails = $otherMails
        ProxyAddresses = $proxyAddresses
        Manager = $managerName
        MemberOfCount = $memberOfCount
        InvitedBy = $invitedBy
    }
}

# ------------------------------------
# Export: always produce CSV with clean headers (no weird #TYPE line)
# ------------------------------------
$outCsv = Join-Path $OutFolder "GuestUsers_$timeStamp.csv"

# Define headers in desired order
$headers = "Id","DisplayName","UserPrincipalName","Mail","UserType","CreatedDateTime","ExternalUserState","ExternalUserStateChangeDate","JobTitle","Department","CompanyName","OtherMails","ProxyAddresses","Manager","MemberOfCount","InvitedBy"

if ($report.Count -eq 0) {
    Write-Host "No guest users found � creating CSV with headers only at: $outCsv"
    # Create an empty object with the headers so Export-Csv writes header row only
    "" | Select-Object $headers | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
} else {
    $report | Select-Object $headers | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
    Write-Host "Guest user report exported to $outCsv (rows: $($report.Count))"
}

# Disconnect
try { Disconnect-MgGraph -ErrorAction SilentlyContinue } catch {}

Write-Host "Done."
