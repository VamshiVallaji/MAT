<#
Azure AD Premium license report (no raw REST, no @odata.nextLink)
- Uses Microsoft.Graph cmdlets which handle paging automatically (-All)
- Collects SKUs, users (assignedLicenses), and groups
- Avoids licenseDetails / group licenseDetails to prevent nextLink issues
Prereqs:
 - Install-Module Microsoft.Graph -Scope CurrentUser
 - App Registration: Application permissions (Directory.Read.All, User.Read.All, Group.Read.All) with admin consent
 - Certificate present in CurrentUser\My or LocalMachine\My (or adapt to client secret)
#>
<#
Import-Module Microsoft.Graph.Users
Import-Module Microsoft.Graph.Groups
Import-Module Microsoft.Graph.Identity.DirectoryManagement
#>

$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\ActiveDirectory\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutFolder = "$network_drive\ActiveDirectory\AD_AzureADPremiumLicenseConfiguration"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

if (-not (Get-MgContext)) { throw "Failed to connect to Microsoft Graph." }

# Ensure output folder exists
if (-not (Test-Path $OutFolder)) { New-Item -Path $OutFolder -ItemType Directory | Out-Null }

# ---------------- SKUs ----------------
Write-Host "Getting tenant SKUs..." -ForegroundColor Cyan
$skuObjects = @()
$skuMap = @{}

try {
    $skus = Get-MgSubscribedSku -ErrorAction Stop
    foreach ($s in $skus) {
        $skuIdStr = if ($s.SkuId) { $s.SkuId.ToString() } else { $null }
        $servicePlans = @()
        if ($s.ServicePlans) {
            foreach ($sp in $s.ServicePlans) {
                $pid = if ($sp.ServicePlanId) { $sp.ServicePlanId.ToString() } else { "" }
                $servicePlans += "${pid}:${($sp.ServicePlanName)}"
            }
        }
        $obj = [PSCustomObject]@{
            SkuId = $skuIdStr
            SkuPartNumber = $s.SkuPartNumber
            PrepaidUnits = $s.PrepaidUnits
            ConsumedUnits = $s.ConsumedUnits
            ServicePlans = ($servicePlans -join ";")
        }
        $skuObjects += $obj
        if ($skuIdStr) { $skuMap[$skuIdStr] = $s.SkuPartNumber }
    }
} catch {
    Write-Warning "Get-MgSubscribedSku failed: $_"
}

$skuObjects | Export-Csv (Join-Path $OutFolder "Tenant_SKUs_$timeStamp.csv") -NoTypeInformation -Force
$skuObjects | ConvertTo-Json -Depth 5 | Out-File (Join-Path $OutFolder "Tenant_SKUs_$timeStamp.json")

# ---------------- Users (using cmdlet paging) ----------------
Write-Host "Retrieving ALL users via Get-MgUser -All (this may take time)..." -ForegroundColor Cyan

# Use -All to let the SDK handle paging. Select only properties we need to reduce payload.
# Note: assignedLicenses comes from the user object (no licenseDetails used here)
$allUsers = Get-MgUser -All -Property "id,displayName,userPrincipalName,accountEnabled,userType,usageLocation,onPremisesSyncEnabled,assignedLicenses"

$usersOut = @()
foreach ($u in $allUsers) {
    $assignedSkus = @()
    if ($u.AssignedLicenses) {
        foreach ($al in $u.AssignedLicenses) {
            if ($al.SkuId) { $assignedSkus += $al.SkuId.ToString() }
        }
    }
    $friendlySkus = $assignedSkus | ForEach-Object { if ($skuMap.ContainsKey($_)) { $skuMap[$_] } else { $_ } }

    $usersOut += [PSCustomObject]@{
        Id = $u.Id
        DisplayName = $u.DisplayName
        UserPrincipalName = $u.UserPrincipalName
        AccountEnabled = $u.AccountEnabled
        UserType = $u.UserType
        UsageLocation = $u.UsageLocation
        OnPremisesSyncEnabled = $u.OnPremisesSyncEnabled
        AssignedSkuGuids = ($assignedSkus -join ";")
        AssignedSkus = ($friendlySkus -join ";")
    }
}

$usersOut | Export-Csv (Join-Path $OutFolder "Users_Licenses_Summary_$timeStamp.csv") -NoTypeInformation -Force
$usersOut | ConvertTo-Json -Depth 5 | Out-File (Join-Path $OutFolder "Users_Licenses_Summary_$timeStamp.json")

# quick split lists
$usersOut | Where-Object { -not $_.AssignedSkuGuids -or $_.AssignedSkuGuids -eq "" } | Export-Csv (Join-Path $OutFolder "Users_NoLicense_$timeStamp.csv") -NoTypeInformation -Force
$usersOut | Where-Object { $_.AssignedSkuGuids -and $_.AssignedSkuGuids -ne "" } | Export-Csv (Join-Path $OutFolder "Users_WithLicense_$timeStamp.csv") -NoTypeInformation -Force

# ---------------- Groups (using cmdlet paging) ----------------
Write-Host "Retrieving ALL groups via Get-MgGroup -All..." -ForegroundColor Cyan
$allGroups = Get-MgGroup -All -Property "id,displayName,mailNickname,securityEnabled,groupTypes,mail,visibility"

$groupsOut = $allGroups | ForEach-Object {
    [PSCustomObject]@{
        Id = $_.Id
        DisplayName = $_.DisplayName
        MailNickname = $_.MailNickname
        Mail = $_.Mail
        SecurityEnabled = $_.SecurityEnabled
        GroupTypes = $( if ($_.GroupTypes) { $_.GroupTypes -join ";" } else { "" })
        Visibility = $_.Visibility
    }
}
$groupsOut | Export-Csv (Join-Path $OutFolder "Tenant_Groups_$timeStamp.csv") -NoTypeInformation -Force

# ---------------- Tenant policy hints (best-effort, cmdlets where available) ----------------
Write-Host "Collecting tenant-level hints (best-effort)..." -ForegroundColor Cyan
$policyHints = @()

# authenticationMethodsPolicy may not have a cmdlet; try SDK endpoint but with careful check (single call)
try {
    $authPolicy = Get-MgPolicyAuthenticationStrengthRoot -ErrorAction SilentlyContinue
    if ($authPolicy) { $policyHints += [PSCustomObject]@{ Key="AuthenticationStrengthRoot"; Value = ($authPolicy | ConvertTo-Json -Depth 5) } }
} catch { }

# SSPR tenant configuration isn't consistently exposed via SDK cmdlets; just record that we've attempted
$policyHints += [PSCustomObject]@{ Key="Note"; Value = "SSPR and password-writeback information may require Azure AD Connect or additional permissions and might not be returned by Graph cmdlets." }

$policyHints | Export-Csv (Join-Path $OutFolder "Tenant_Policy_Hints_$timeStamp.csv") -NoTypeInformation -Force
$policyHints | ConvertTo-Json -Depth 5 | Out-File (Join-Path $OutFolder "Tenant_Policy_Hints_$timeStamp.json")

# ---------------- Summary ----------------
Write-Host "Summarizing license usage from Subscribed SKUs..." -ForegroundColor Cyan
$summary = @()
foreach ($s in $skuObjects) {
    $total = if ($s.PrepaidUnits -and $s.PrepaidUnits.Enabled) { $s.PrepaidUnits.Enabled } else { 0 }
    $consumed = if ($s.ConsumedUnits) { $s.ConsumedUnits } else { 0 }
    $summary += [PSCustomObject]@{
        SkuId = $s.SkuId
        SkuPartNumber = $s.SkuPartNumber
        Consumed = $consumed
        Total = $total
        Remaining = ($total - $consumed)
    }
}
$summary | Export-Csv (Join-Path $OutFolder "License_Usage_Summary_$timeStamp.csv") -NoTypeInformation -Force
$summary | ConvertTo-Json -Depth 5 | Out-File (Join-Path $OutFolder "License_Usage_Summary_$timeStamp.json")

# Final listing
Write-Host "Completed exports to $OutFolder" -ForegroundColor Green
Get-ChildItem -Path $OutFolder | ForEach-Object { Write-Host " - $($_.Name)" }

# Disconnect
try { Disconnect-MgGraph -Confirm:$false } catch {}
