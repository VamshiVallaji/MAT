# Collect all servers from AD
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$AllServers = Get-ADComputer -Filter {Enabled -eq $true -and OperatingSystem -like "*Server*"} -Properties OperatingSystem, DNSHostName

$Results = foreach ($Server in $AllServers) {
    try {
        # Get SMB shares remotely
        Get-SmbShare -CimSession $Server.DNSHostName -ErrorAction Stop | ForEach-Object {
            [PSCustomObject]@{
                ComputerName = $Server.DNSHostName
                OS = $Server.OperatingSystem
                ShareName = $_.Name
                Path = $_.Path
                Description = $_.Description
            }
        }
    }
    catch {
        Write-Warning "Could not query $($Server.DNSHostName): $_"
    }
}

# Export results to CSV
$Results | Export-Csv "$network_drive\ActiveDirectory\AD_FileServersdetails\FileServers_SMBShares_$timeStamp.csv" -NoTypeInformation -Encoding UTF8
Write-Host "File server SMB shares report saved to FileServers_SMBShares_$timeStamp.csv" -ForegroundColor Green

