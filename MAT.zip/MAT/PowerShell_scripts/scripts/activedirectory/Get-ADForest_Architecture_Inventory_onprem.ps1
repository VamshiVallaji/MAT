<#
.SYNOPSIS
    Gathers AD Forest, Domain, OU, and ACL details in non-interactive mode from multiple Domain Controllers.

.DESCRIPTION
    This script:
    - Connects to each provided Domain Controller (DC)
    - Gathers AD forest details, domain details, FSMO roles, global catalogs, and sites
    - Enumerates all Organizational Units (OUs)
    - Extracts ACLs (permissions) for each OU
    - Exports data into two separate CSV reports:
        1. AD_Forest_Domain_Architecture.csv
        2. AD_OU_ACL_Inventory.csv
#>

# Load AD module
Import-Module ActiveDirectory

# Domain Controllers
$DomainControllers = @("mataddc2.mat.com","mataddc3.mat.com")

# Non-interactive credentials
#$Username = "matpowershell2\azureuser"
$Username = "mat\azureuser"
$Password = "Mat@2025" | ConvertTo-SecureString -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential ($Username, $Password)

# Output files
$OutputForest = "Z:\AD_Frst_ChildDmn_DC_FSMO_SitesSubnetsSitelnk_Trust_OU_DNS_AcntLockut_DFS_AllUsr_SrcAcnt\AD_Forest_Domain_Architecture_onprem_$(Get-Date -Format 'yyyyMMdd_HHmm').csv"
$OutputOUACL = "Z:\AD_Frst_ChildDmn_DC_FSMO_SitesSubnetsSitelnk_Trust_OU_DNS_AcntLockut_DFS_AllUsr_SrcAcnt\AD_OU_ACL_Inventory_onprem_$(Get-Date -Format 'yyyyMMdd_HHmm').csv"

# Arrays to store data
$ForestReport = @()
$OUACLReport = @()

Write-Host "`nConnecting to AD Forest and gathering details..." -ForegroundColor Cyan

foreach ($DC in $DomainControllers) {
    try {
        Write-Host "`nProcessing $DC..." -ForegroundColor Yellow

        # --- Forest and Domain Info ---
	#$users = Get-ADUser -Server $DC -Credential $Credential -Filter
        $Forest = Get-ADForest -Server $DC -Credential $Credential
        $Domains = $Forest.Domains

        foreach ($Domain in $Domains) {
            Write-Host " Gathering domain info for: $Domain" -ForegroundColor Green
            $DomainInfo = Get-ADDomain -Server $DC -Credential $Credential
            $DCs = Get-ADDomainController -Server $DC -Credential $Credential -Filter *

            $ForestReport += [PSCustomObject]@{
                ForestName = $Forest.Name
                ForestFunctionalLevel = $Forest.ForestMode
                RootDomain = $Forest.RootDomain
                DomainName = $DomainInfo.DNSRoot
                DomainFunctionalLevel = $DomainInfo.DomainMode
                DomainSID = $DomainInfo.DomainSID
                PDCEmulator = $DomainInfo.PDCEmulator
                RIDMaster = $DomainInfo.RIDMaster
                InfrastructureMaster = $DomainInfo.InfrastructureMaster
                SchemaMaster = $Forest.SchemaMaster
                DomainNamingMaster = $Forest.DomainNamingMaster
                GlobalCatalogs = ($Forest.GlobalCatalogs -join "; ")
                Sites = ($Forest.Sites -join "; ")
                DomainControllers = ($DCs.HostName -join "; ")
                ReportGeneratedOn = (Get-Date)
                ProcessedByDC = $DC
            }
        }

        # --- OU and ACL Info ---
        Write-Host " Gathering OU and ACL information..." -ForegroundColor Green
        $OUs = Get-ADOrganizationalUnit -Server $DC -Credential $Credential -Filter *

        foreach ($OU in $OUs) {
            try {
                $ACLs = Get-Acl -Path ("AD:\" + $OU.DistinguishedName)
                foreach ($Access in $ACLs.Access) {
                    $OUACLReport += [PSCustomObject]@{
                        Forest = $Forest.Name
                        Domain = $Domain
                        DomainController = $DC
                        OUName = $OU.Name
                        OUDistinguishedName = $OU.DistinguishedName
                        IdentityReference = $Access.IdentityReference
                        ActiveDirectoryRights = $Access.ActiveDirectoryRights
                        AccessControlType = $Access.AccessControlType
                        InheritanceType = $Access.InheritanceType
                        IsInherited = $Access.IsInherited
                        ReportGeneratedOn = (Get-Date)
                    }
                }
            }
            catch {
                Write-Warning "Failed to retrieve ACLs for OU: $($OU.DistinguishedName)"
            }
        }
    }
    catch {
        Write-Warning "Failed to process $DC. Error: $_"
    }
}

# Export Reports
$ForestReport | Export-Csv -Path $OutputForest -NoTypeInformation -Encoding UTF8
$OUACLReport | Export-Csv -Path $OutputOUACL -NoTypeInformation -Encoding UTF8

Write-Host "`nExport complete:" -ForegroundColor Cyan
Write-Host " - Forest & Domain report: $OutputForest"
Write-Host " - OU & ACL report: $OutputOUACL"
