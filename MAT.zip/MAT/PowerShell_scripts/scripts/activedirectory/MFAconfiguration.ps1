<# ==========================================================
MFA inventory (non-interactive, certificate auth)
Outputs (UTF-8 CSVs):
  - MFA_UserRegistration.csv (one row per user)
  - MFA_Registration_Summary.csv (tenant summary)
  - CA_Policies_RequiringMFA.csv (CA policies that require MFA)
Prereqs: Microsoft.Graph modules + app-only perms:
  Reports.Read.All, Policy.Read.All, Directory.Read.All
========================================================== #>

# ====== INPUTS ======
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\ActiveDirectory\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint


# ====== Output locations ======
$OutDir = "$network_drive\ActiveDirectory\AD_MFAconfiguration"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")

New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$csvUsers = Join-Path $OutDir "MFA_UserRegistration_$timeStamp.csv"
$csvSummary = Join-Path $OutDir "MFA_Registration_Summary_$timeStamp.csv"
$csvCA = Join-Path $OutDir "CA_Policies_RequiringMFA_$timeStamp.csv"

# ====== Connect non-interactively with certificate ======
Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null
#Select-MgProfile -Name "beta" # userRegistrationDetails is most complete in beta; fallbacks included

# -------------------------
# 1) Authentication Methods � user registration details
# -------------------------
$userRows = @()
try {
    # This report includes: userId, userDisplayName, userPrincipalName, methodsRegistered,
    # isMfaRegistered, isSsprRegistered, isPasswordlessCapable, defaultMfaMethod (if present)
    $reg = Get-MgReportAuthenticationMethodUserRegistrationDetail -All -ErrorAction Stop

    foreach ($u in $reg) {
        $methods = @()
        if ($u.methodsRegistered) { $methods = $u.methodsRegistered }
        $userRows += [pscustomobject]@{
            UserDisplayName = $u.userDisplayName
            UserPrincipalName = $u.userPrincipalName
            UserId = $u.userID
            IsMfaRegistered = $u.isMfaRegistered
            IsSsprRegistered = $u.isSsprRegistered
            IsPasswordlessCapable = $u.isPasswordlessCapable
            MethodsRegistered = ($methods -join ';')
            DefaultMfaMethod = $u.defaultMfaMethod
            # Additional helpful flags present in many tenants
            IsCapable = $u.isCapable
            IsEnabled = $u.isEnabled
            IsMfaCapable = $u.isMfaCapable
        }
    }
} catch {
    Write-Warning "Could not retrieve Authentication Methods registration details: $($_.Exception.Message)"
}

# If nothing returned, still write a CSV with headers
if (-not $userRows) {
    [pscustomobject]@{
        UserDisplayName='';UserPrincipalName='';UserId='';
        IsMfaRegistered=$false;IsSsprRegistered=$false;IsPasswordlessCapable=$false;
        MethodsRegistered='';DefaultMfaMethod='';IsCapable=$null;IsEnabled=$null;IsMfaCapable=$null
    } | Export-Csv -Path $csvUsers -NoTypeInformation -Encoding UTF8
} else {
    $userRows | Sort-Object UserPrincipalName | Export-Csv -Path $csvUsers -NoTypeInformation -Encoding UTF8
}

# -------------------------
# 2) Registration summary (counts, percentages, methods breakdown)
# -------------------------
$summaryRows = @()
if ($userRows) {
    $total = $userRows.Count
    $mfaUsers = ($userRows | Where-Object { $_.IsMfaRegistered -eq $true }).Count
    $pct = if ($total -gt 0) { [math]::Round(($mfaUsers/$total)*100,2) } else { 0 }

    # Count methods
    $methodCounts = @{}
    foreach ($r in $userRows) {
        $r.MethodsRegistered -split ';' | ForEach-Object {
            $m = $_.Trim()
            if ([string]::IsNullOrWhiteSpace($m)) { return }
            if (-not $methodCounts.ContainsKey($m)) { $methodCounts[$m] = 0 }
            $methodCounts[$m]++
        }
    }
    $methodsSummary = ($methodCounts.GetEnumerator() | Sort-Object Name | ForEach-Object { "$($_.Name)=$($_.Value)" }) -join '; '

    $summaryRows += [pscustomobject]@{
        TotalUsers = $total
        UsersMfaRegistered = $mfaUsers
        PercentMfaRegistered = $pct
        MethodsBreakdown = $methodsSummary
        GeneratedUtc = [DateTime]::UtcNow.ToString("u")
    }
}

if (-not $summaryRows) {
    [pscustomobject]@{
        TotalUsers=0;UsersMfaRegistered=0;PercentMfaRegistered=0;MethodsBreakdown='';GeneratedUtc=[DateTime]::UtcNow.ToString("u")
    } | Export-Csv -Path $csvSummary -NoTypeInformation -Encoding UTF8
} else {
    $summaryRows | Export-Csv -Path $csvSummary -NoTypeInformation -Encoding UTF8
}

# -------------------------
# 3) Conditional Access policies that require MFA
# -------------------------
$caRows = @()
try {
    # Pull all CA policies
    $pols = Get-MgIdentityConditionalAccessPolicy -All -ErrorAction Stop
    foreach ($p in $pols) {
        $requiresMfa = $false
        $strengthPolicy = $null

        # Classic "Grant" MFA control
        if ($p.grantControls -and $p.grantControls.builtInControls) {
            if ($p.grantControls.builtInControls -contains "mfa") { $requiresMfa = $true }
        }

        # Authentication Strength (if used)
        if ($p.grantControls -and $p.grantControls.authenticationStrength) {
            $requiresMfa = $true
            $strengthPolicy = $p.grantControls.authenticationStrength.id
        }

        if ($requiresMfa) {
            $usersIncl = ($p.conditions.users.includeUsers -join ',')
            $usersExcl = ($p.conditions.users.excludeUsers -join ',')
            $rolesIncl = ($p.conditions.users.includeRoles -join ',')
            $appsIncl = ($p.conditions.applications.includeApplications -join ',')

            $caRows += [pscustomobject]@{
                PolicyName = $p.displayName
                State = $p.state
                AuthenticationStrengthPolicyId = $strengthPolicy
                IncludesUsers = $usersIncl
                ExcludesUsers = $usersExcl
                IncludesRoles = $rolesIncl
                IncludesApplications = $appsIncl
            }
        }
    }
} catch {
    Write-Warning "Could not retrieve Conditional Access policies: $($_.Exception.Message)"
}

if (-not $caRows) {
    [pscustomobject]@{
        PolicyName='';State='';AuthenticationStrengthPolicyId='';
        IncludesUsers='';ExcludesUsers='';IncludesRoles='';IncludesApplications=''
    } | Export-Csv -Path $csvCA -NoTypeInformation -Encoding UTF8
} else {
    $caRows | Sort-Object PolicyName | Export-Csv -Path $csvCA -NoTypeInformation -Encoding UTF8
}

Write-Host "MFA user registration : $csvUsers" -ForegroundColor Green
Write-Host "MFA registration summary : $csvSummary" -ForegroundColor Green
Write-Host "CA policies requiring MFA : $csvCA" -ForegroundColor Green

Disconnect-MgGraph | Out-Null
