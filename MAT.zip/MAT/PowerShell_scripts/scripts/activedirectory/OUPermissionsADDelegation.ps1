<#
.SYNOPSIS
  Export OU permissions / AD delegation for on-prem Active Directory.

.DESCRIPTION
  - Enumerates OUs (root or under specified SearchBase)
  - Reads NT security descriptor (Get-Acl via AD: provider)
  - Outputs per-ACE rows: OU, Trustee, ActiveDirectoryRights, AccessControlType (Allow/Deny),
    IsInherited, InheritanceType, AppliesTo (ObjectType GUID / schema name if resolvable), Sid, TrusteeType
  - Exports CSV suitable for auditing/delegation review.

.NOTES
  - Requires ActiveDirectory module (Install RSAT -> RSAT-AD-PowerShell)
  - Run as a domain account with read access to AD ACLs
#>

# --------------------- CONFIG ---------------------
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$TimeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$CsvOut = "$network_drive\ActiveDirectory\AD_OUPermissionsADDelegation\AD_OU_Delegation_$TimeStamp.csv"

# Optional: restrict to a subtree (distinguishedName of OU) or leave $SearchBase = $null to enumerate all OUs
# Example: $SearchBase = "OU=Sites,DC=contoso,DC=com"
$SearchBase = $null

# Optional: preserve your Connect-MgGraph line if you need Graph elsewhere (kept but commented)
# Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

# --------------------- PRECHECKS ---------------------
# Ensure ActiveDirectory module
if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) {
    Write-Error "ActiveDirectory module not found. Install RSAT/ActiveDirectory PowerShell and re-run."
    return
}
Import-Module ActiveDirectory -ErrorAction Stop

# Create helper: attempt to resolve schemaIDGUID (objectType GUID) to readable schema display name
function Resolve-SchemaGuid {
    param([Guid]$guid)
    if (-not $guid) { return $null }
    try {
        # schema objects are in CN=Schema,CN=Configuration,<forestDN>
        $schemaObj = Get-ADObject -LDAPFilter "(schemaIDGUID=$($guid.ToByteArray() | ForEach-Object { "{0:x2}" -f $_ } -join ''))" -SearchBase ((Get-ADRootDSE).schemaNamingContext) -Properties lDAPDisplayName,description -ErrorAction SilentlyContinue
        if ($schemaObj) { return $schemaObj.lDAPDisplayName }
    } catch {
        # fallback: return GUID string
    }
    return $guid.Guid
}

# Helper: format rights (ActiveDirectoryRights is a flags enum)
function Format-Rights {
    param([System.DirectoryServices.ActiveDirectoryRights]$rights)
    if (-not $rights) { return '' }
    return ([string]$rights)
}

# --------------------- COLLECT OUs ---------------------
Write-Host "Enumerating OUs..."
if ($SearchBase) {
    $OUs = Get-ADOrganizationalUnit -SearchBase $SearchBase -Filter * -Properties distinguishedName,whenCreated,whenChanged | Sort-Object DistinguishedName
} else {
    $OUs = Get-ADOrganizationalUnit -Filter * -Properties distinguishedName,whenCreated,whenChanged | Sort-Object DistinguishedName
}

Write-Host "Found $($OUs.Count) OUs. Querying ACLs..."

$results = @()

foreach ($ou in $OUs) {
    $dn = $ou.DistinguishedName
    $adPath = "AD:$dn" # AD: provider allows Get-Acl on AD objects
    try {
        $acl = Get-Acl -Path $adPath -ErrorAction Stop
    } catch {
        Write-Warning "Cannot read ACL for $dn. Error: $($_.Exception.Message)"
        continue
    }

    # Each ACE is an ActiveDirectoryAccessRule
    foreach ($ace in $acl.Access) {
        # ACE.IdentityReference is usually a SecurityIdentifier or NTAccount
        $sid = $ace.IdentityReference.Value
        # Try to resolve to a readable account name if it's a SID
        try {
            $nt = (New-Object System.Security.Principal.SecurityIdentifier($sid)).Translate([System.Security.Principal.NTAccount]).Value
        } catch {
            $nt = $sid
        }

        # try to determine trustee type (User/Group/WellKnown)
        $trusteeType = 'Unknown'
        try {
            $obj = Get-ADUser -Identity $nt -ErrorAction SilentlyContinue
            if ($obj) { $trusteeType = 'User' } else {
                $g = Get-ADGroup -Identity $nt -ErrorAction SilentlyContinue
                if ($g) { $trusteeType = 'Group' } else {
                    $c = Get-ADComputer -Identity $nt -ErrorAction SilentlyContinue
                    if ($c) { $trusteeType = 'Computer' } else { $trusteeType = 'AccountOrSID' }
                }
            }
        } catch { $trusteeType = 'AccountOrSID' }

        # object type (GUID) the ACE applies to (may be empty)
        $objTypeGuid = $null
        $appliesTo = $null
        try {
            if ($ace.ObjectType -and ($ace.ObjectType -ne [Guid]::Empty)) {
                $objTypeGuid = $ace.ObjectType
                $appliesTo = Resolve-SchemaGuid -guid $objTypeGuid
            }
        } catch {}

        $results += [PSCustomObject]@{
            OU_DistinguishedName = $dn
            OU_Name = ($dn -split ',')[0] -replace '^OU='
            Trustee = $nt
            TrusteeType = $trusteeType
            SID = $sid
            ActiveDirectoryRights = Format-Rights -rights $ace.ActiveDirectoryRights
            AccessControlType = $ace.AccessControlType.ToString()
            IsInherited = $ace.IsInherited
            InheritanceType = $ace.InheritanceType.ToString()
            AppliesTo_ObjectTypeGuid = $(if ($objTypeGuid) { $objTypeGuid.Guid } else { '' })
            #AppliesTo_SchemaName = $(if ($appliesTo) { $appliesTo } else { '' })
            #AceFlags = $ace.AceFlags.ToString()
            #AceQualifier = $ace.AceQualifier.ToString()
            WhenCreated = $ou.whenCreated
            WhenChanged = $ou.whenChanged
        }
    }
}

# --------------------- EXPORT ---------------------
if (-not (Test-Path (Split-Path $CsvOut -Parent))) { New-Item -ItemType Directory -Path (Split-Path $CsvOut -Parent) -Force | Out-Null }

Write-Host "Exporting $($results.Count) delegation entries to $CsvOut ..."
$results | Export-Csv -Path $CsvOut -NoTypeInformation -Encoding UTF8 -Force

Write-Host "Done. CSV exported to $CsvOut"
