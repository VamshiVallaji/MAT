<# ==========================================================
Password Writeback (SSPR on-premises integration) � cloud report
Outputs (UTF-8 CSVs):
  - PasswordWriteback_Settings.csv (all key/value pairs from �Password Reset Policy�)
  - PasswordWriteback_Summary.csv (condensed yes/no + key values)
Requires: Microsoft.Graph.* SDK, App-only cert auth, Directory.Read.All
Works on PS 5.x or 7.x
========================================================== #>

# === INPUTS (fill these) ===
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\ActiveDirectory\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutDir = "$network_drive\ActiveDirectory\AD_PasswordWritebackconfiguration"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")

$CsvAll = Join-Path $OutDir "PasswordWriteback_Settings_$timeStamp.csv"
$CsvSum = Join-Path $OutDir "PasswordWriteback_Summary_$timeStamp.csv"
New-Item -ItemType Directory -Path $OutDir -Force | Out-Null

# --- Connect non-interactively with certificate ---
Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null
#Select-MgProfile -Name "v1.0"

# --- Helper: safe exporter with headers even if empty ---
function Export-WithHeaders {
    param(
        [Parameter(Mandatory)]$Object,
        [Parameter(Mandatory)][string]$Path
    )
    $Object | Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8
}

# 1) Organization flags (dirsync)
$org = $null
try { $org = Get-MgOrganization -ErrorAction Stop } catch { Write-Warning $_.Exception.Message }

$onPremSyncEnabled = $org.OnPremisesSyncEnabled

# 2) Subscribed SKUs (check for AAD P1/P2)
$skus = @()
try {
    $skus = Get-MgSubscribedSku -All -ErrorAction Stop
} catch { Write-Warning $_.Exception.Message }

$skuStrings = ($skus | ForEach-Object {
    "{0} ({1})" -f $_.SkuPartNumber, $_.SkuId
}) -join '; '

$hasP1 = ($skus.SkuPartNumber -match 'AAD_PREMIUM' -or $skus.SkuPartNumber -match 'ENTERPRISEPREMIUM') # includes E3/E5 bundles
$hasP2 = ($skus.SkuPartNumber -match 'AAD_PREMIUM_P2' -or $skus.SkuPartNumber -match 'IDENTITY_GOV' -or $skus.SkuPartNumber -match 'EMS_E5')

# 3) �Password Reset Policy� directory setting (where writeback lives)
# Look up the template, then find the tenant�s instance created from it
$prTemplate = $null
$prInstance = $null
try {
    $prTemplate = Get-MgDirectorySettingTemplate -All | Where-Object { $_.DisplayName -eq "Password Reset Policy" }
    if ($prTemplate) {
        $prInstance = Get-MgDirectorySetting -All | Where-Object { $_.TemplateId -eq $prTemplate.Id }
    }
} catch { Write-Warning $_.Exception.Message }

# Extract all key/value pairs so you can see everything your tenant has set
$allRows = @()
if ($prInstance -and $prInstance.Values) {
    foreach ($v in $prInstance.Values) {
        $allRows += [pscustomobject]@{
            SettingName = $v.Name
            SettingValue = $v.Value
        }
    }
} else {
    # If there is no instance, the tenant is using defaults (writeback effectively OFF from cloud standpoint)
    $allRows += [pscustomobject]@{
        SettingName = "Info"
        SettingValue = "No Password Reset Policy instance found (defaults in effect)"
    }
}

# Known important flags (names are stable in Azure AD directory settings)
function Get-SettingValue {
param([Parameter(Mandatory)][string]$name) 
$row = $allRows | Where-Object { $_.SettingName -eq $name } | Select-Object -First 1
if ($null -ne $row -and $row.PSObject.Properties.Match('SettingValue')) {
return $row.SettingValue
}
return $null
}

$enableWriteback = Get-SettingValue "EnableOnPremisePasswordWriteback" # "True"/"False"
$ssprEnabled = Get-SettingValue "Enabled" # "True"/"False" (SSPR service enabled)
$scope = Get-SettingValue "Scope" # "All" | "Selected"
$groups = Get-SettingValue "SelectedGroups" # GUID list when Scope=Selected
$registrationReq = Get-SettingValue "EnforceRegistration" # "True"/"False"
$unlockWithMfa = Get-SettingValue "AllowUsersToUnlockWithoutResetting" # varies by template versions
$notificationEmail = Get-SettingValue "NotifyUsersOnPasswordReset" # "True"/"False"
$writebackNote = if ($enableWriteback -match 'true') { "Enabled" } else { "Disabled" }

# 4) Write CSVs
Export-WithHeaders -Object $allRows -Path $CsvAll

$summary = [pscustomobject]@{
    OnPremisesSyncEnabled = $onPremSyncEnabled
    HasAzureADPremiumP1orBundle = [bool]$hasP1
    HasAzureADPremiumP2orBundle = [bool]$hasP2
    PasswordWritebackEnabled = ( $enableWriteback -as [bool] )
    SSPRServiceEnabled = ( $ssprEnabled -as [bool] )
    SSPRScope = $scope
    SSPRSelectedGroups = $groups
    EnforceRegistration = ( $registrationReq -as [bool] )
    NotifyUsersOnPasswordReset = ( $notificationEmail -as [bool] )
    Notes = $writebackNote
    SubscribedSkus = $skuStrings
    GeneratedUtc = [DateTime]::UtcNow.ToString("u")
}

Export-WithHeaders -Object $summary -Path $CsvSum

Write-Host "Password Reset Policy settings : $CsvAll" -ForegroundColor Green
Write-Host "Password Writeback summary : $CsvSum" -ForegroundColor Green

Disconnect-MgGraph | Out-Null
