<# Print server inventory (non-interactive)
   Output: .\PrintServers.csv and .\Printers.csv
#>

Import-Module ActiveDirectory
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$OutputDir = "$network_drive\ActiveDirectory\AD_PrintServersdetails"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$servers = Get-ADComputer -Filter 'Enabled -eq $true -and OperatingSystem -like "Windows Server*"' `
            -Properties DNSHostName,OperatingSystem,IPv4Address |
           Where-Object { $_.DNSHostName }

$printServers = @()
$printers = @()

foreach ($srv in $servers) {
    $name = $srv.DNSHostName

    # Spooler state (if service exists)
    try {
        $spooler = Get-Service -ComputerName $name -Name Spooler -ErrorAction Stop
    } catch {
        $spooler = $null
    }

    $spoolerState = if ($spooler) { $spooler.Status.ToString() } else { 'NotFound' }

    # Try to read printers (shared & non-shared) from the server
    $srvPrinters = @()
    try {
        # Get-Printer uses the PrintManagement stack; works without interactive logon
        $srvPrinters = Get-Printer -ComputerName $name -ErrorAction Stop
    } catch {
        # Fallback to WMI if PrintManagement RPC is blocked/not present
        try {
            $srvPrinters = Get-CimInstance -ClassName Win32_Printer -ComputerName $name -ErrorAction Stop |
                           ForEach-Object {
                               [pscustomobject]@{
                                   Name = $_.Name
                                   ShareName = $_.ShareName
                                   Shared = [bool]$_.Shared
                                   DriverName = $_.DriverName
                                   PortName = $_.PortName
                                   Location = $_.Location
                                   Comment = $_.Comment
                                   Published = $false
                               }
                           }
        } catch {
            $srvPrinters = @()
        }
    }
    $allPrinters = @($srvPrinters)
    $printerCount = $allPrinters.Count
    $sharedItems = $allPrinters | Where-Object { $_.Shared -eq $true }
    $sharedCount = @($sharedItems).Count
    # Add server summary row
    $printServers += [pscustomobject]@{
        Server = $name
        IPv4Address = $srv.IPv4Address
        OperatingSystem = $srv.OperatingSystem
        SpoolerState = $spoolerState
        PrinterCount = $printerCount
        SharedCount = $sharedCount
    }

    # Add per-printer rows
    foreach ($p in $srvPrinters) {
        $printers += [pscustomobject]@{
            Server = $name
            Name = $p.Name
            Shared = $p.Shared
            ShareName = $p.ShareName
            DriverName = $p.DriverName
            PortName = $p.PortName
            Location = $p.Location
            Comment = $p.Comment
            Published = $p.Published # $true if coming from Get-Printer and published
        }
    }
}

$psCsv = Join-Path $OutputDir "PrintServers\PrintServers_$timeStamp.csv"
$prCsv = Join-Path $OutputDir "Printers\Printers_$timeStamp.csv"
$printServers | Sort-Object Server | Export-Csv $psCsv -NoTypeInformation -Encoding UTF8
$printers | Sort-Object Server,Name | Export-Csv $prCsv -NoTypeInformation -Encoding UTF8

Write-Host "Print server summary saved to: $psCsv" -ForegroundColor Green
Write-Host "Printer inventory saved to: $prCsv" -ForegroundColor Green
