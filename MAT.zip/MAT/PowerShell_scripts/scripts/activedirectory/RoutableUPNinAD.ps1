$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
Get-ADUser -Filter * -Properties DisplayName, SamAccountName, UserPrincipalName | Where-Object { $_.UserPrincipalName -like "*@mat.com" } | Select-Object DisplayName, SamAccountName, UserPrincipalName | Export-Csv "Z:\ActiveDirectory\AD_RoutableUPNinAD\AD_Users_RoutableUPN_$timeStamp.csv" -NoTypeInformation
