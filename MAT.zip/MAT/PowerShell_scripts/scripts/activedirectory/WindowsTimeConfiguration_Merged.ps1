<#
.SYNOPSIS
Generates a combined report of Windows Time Configuration:
- Time status from all Domain Controllers
- Time status and configuration from the PDC Emulator
#>
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$OutFolder = "$network_drive\ActiveDirectory\AD_WindowsTimeConfiguration"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$outCsv = Join-Path $OutFolder "WindowsTimeConfig_$timeStamp.csv"

# Ensure output folder exists
if (-not (Test-Path $OutFolder)) {
    New-Item -Path $OutFolder -ItemType Directory -Force
}

# Load Active Directory module
Import-Module ActiveDirectory -ErrorAction Stop

# Get all DCs
$dcs = Get-ADDomainController -Filter * -ErrorAction Stop

# Prepare CSV header
"" | Select-Object Role,Server,Status,Configuration | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8

# Query each DC for time status
foreach ($dc in $dcs) {
    try {
        $status = Invoke-Command -ComputerName $dc.HostName -ScriptBlock { w32tm /query /status 2>&1 } -ErrorAction Stop
        $row = [PSCustomObject]@{
            Role = "DC"
            Server = $dc.HostName
            Status = $status -join "`n"
            Configuration = ""
        }
    } catch {
        $row = [PSCustomObject]@{
            Role = "DC"
            Server = $dc.HostName
            Status = "ERROR: " + $_.Exception.Message
            Configuration = ""
        }
    }
    $row | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Append
}

# Query PDC Emulator for status and configuration
try {
    $pdc = (Get-ADDomain).PDCEmulator
    $res = Invoke-Command -ComputerName $pdc -ScriptBlock {
        $s1 = w32tm /query /status 2>&1
        $s2 = w32tm /query /configuration 2>&1
        @{ Status = $s1 -join "`n"; Config = $s2 -join "`n" }
    } -ErrorAction Stop
    $row = [PSCustomObject]@{
        Role = "PDC"
        Server = $pdc
        Status = $res.Status
        Configuration = $res.Config
    }
    $row | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Append
    Write-Host ("PDC time config saved to: " + $outCsv) -ForegroundColor Green
} catch {
    Write-Host ("Failed to query PDC: " + $_.Exception.Message) -ForegroundColor Yellow
    $row = [PSCustomObject]@{
        Role = "PDC"
        Server = $pdc
        Status = "ERROR: " + $_.Exception.Message
        Configuration = ""
    }
    $row | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Append
}

Write-Host ("Combined time configuration report saved to: " + $outCsv) -ForegroundColor Cyan
