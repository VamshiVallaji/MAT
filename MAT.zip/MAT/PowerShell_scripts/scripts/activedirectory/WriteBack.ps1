#--------Run the below script from Entra server (MATENTRA)----------#
# ------------------- CONFIG BLOCK (kept as requested) -------------------
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" |
                 Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\ActiveDirectory\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json

$Out_Folder = Join-Path $network_drive "AD_ADWriteback"
if (-not (Test-Path $Out_Folder)) {
    New-Item -Path $Out_Folder -ItemType Directory -Force | Out-Null
}
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$csvPath = Join-Path $Out_Folder "ADWritebackRules.$timeStamp.csv"

# ------------------- Load ADSync Module -------------------
try {
    Import-Module ADSync -ErrorAction Stop
} catch {
    throw "ADSync PowerShell module not found. Ensure you are on the AD Connect server. Error: $($_.Exception.Message)"
}

# ------------------- Collect ADSync Rules -------------------
try {
    $allRules = Get-ADSyncRule -ErrorAction Stop
    $wbRules = $allRules | Where-Object { $_.Name -match 'Writeback|writeback' }

    if (-not $wbRules -or $wbRules.Count -eq 0) {
        Write-Warning "No rules matching 'Writeback' were found. Exporting ALL ADSync rules."
        $selectedRules = $allRules
    } else {
        $selectedRules = $wbRules
    }
} catch {
    throw "Failed to collect ADSync rules: $($_.Exception.Message)"
}

# ------------------- Build CSV Rows -------------------
$rows = foreach ($r in $selectedRules) {
    [PSCustomObject]@{
        Name = $r.Name
        Description = $r.Description
        ConnectorName = $r.ConnectorName
        Direction = $r.Direction
        Precedence = $r.Precedence
        Scope = $r.Scope
        Enabled = if ($r.IsActive -ne $null) { $r.IsActive } elseif ($r.Enabled -ne $null) { $r.Enabled } else { $null }
        ImmutableId = ($r.ImmutableIdTag -or $r.ImmutableRuleId -or $r.ImmutableId)
    }
}

# ------------------- Export to CSV -------------------
try {
    $rows | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
    Write-Host "CSV report exported to: $csvPath (Rows: $($rows.Count))"
} catch {
    throw "Failed to write CSV to $csvPath : $($_.Exception.Message)"
}
