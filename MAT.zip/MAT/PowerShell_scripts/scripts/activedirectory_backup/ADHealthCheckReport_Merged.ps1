﻿
<#!
.SYNOPSIS
  Run AD health checks and export results to a single Excel workbook.
  .PSVersion 5.1
#>

$network_drive = (Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" |
    Select-Object -ExpandProperty DeviceID | Select-Object -First 1)

$OutFolder = "$network_drive\AD_ADHealthCheckReport"

$timeStamp = Get-Date -Format "yyyyMMdd_HHmmss"

# CSV file paths
$failCsv = Join-Path $OutFolder "Replication_Failures_$timeStamp.csv"
$metaCsv = Join-Path $OutFolder "Replication_PartnerMetadata_$timeStamp.csv"
$sysCsv = Join-Path $OutFolder "DC_SYSVOL_Status_$timeStamp.csv"
$eventCsv = Join-Path $OutFolder "DC_EventErrors_$timeStamp.csv"
$excelPath = Join-Path $OutFolder "AD_HealthCheck_Report_$timeStamp.xlsx"
$Days = 1

Import-Module ActiveDirectory -ErrorAction Stop
$dcs = Get-ADDomainController -Filter * -ErrorAction Stop

# Initialize CSV headers
"" | Select-Object DC,FailureCount,FirstFailureTime,FailureDetails | Export-Csv -Path $failCsv -NoTypeInformation -Encoding UTF8
"" | Select-Object DC,Partner,LastReplicationSuccess,UpToDatenessUSN | Export-Csv -Path $metaCsv -NoTypeInformation -Encoding UTF8
"" | Select-Object DC,SysvolExists,DFSRStatus | Export-Csv -Path $sysCsv -NoTypeInformation -Encoding UTF8
"" | Select-Object DC,DirectoryServiceErrors,SystemErrors | Export-Csv -Path $eventCsv -NoTypeInformation -Encoding UTF8

foreach ($dc in $dcs) {
  try {
    $fails = Get-ADReplicationFailure -Target $dc.HostName -ErrorAction SilentlyContinue
    if ($fails) {
      foreach ($f in $fails) {
        $r = [PSCustomObject]@{
          DC = $dc.HostName
          FailureCount = $f.FailureCount
          FirstFailureTime = $f.FirstFailureTime
          FailureDetails = $f.Message
        }
        $r | Export-Csv -Path $failCsv -NoTypeInformation -Encoding UTF8 -Append
      }
    } else {
      $r = [PSCustomObject]@{ DC = $dc.HostName; FailureCount = 0; FirstFailureTime = ""; FailureDetails = "No reported failures" }
      $r | Export-Csv -Path $failCsv -NoTypeInformation -Encoding UTF8 -Append
    }

    $meta = Get-ADReplicationPartnerMetadata -Target $dc.HostName -ErrorAction SilentlyContinue
    if ($meta) {
      foreach ($m in $meta) {
        $rm = [PSCustomObject]@{
          DC = $dc.HostName
          Partner = $m.Partner
          LastReplicationSuccess = $m.LastReplicationSuccess
          UpToDatenessUSN = $m.UpToDatenessUSN
        }
        $rm | Export-Csv -Path $metaCsv -NoTypeInformation -Encoding UTF8 -Append
      }
    } else {
      $rm = [PSCustomObject]@{ DC = $dc.HostName; Partner = ""; LastReplicationSuccess = ""; UpToDatenessUSN = "" }
      $rm | Export-Csv -Path $metaCsv -NoTypeInformation -Encoding UTF8 -Append
    }

    $svc = Invoke-Command -ComputerName $dc.HostName -ScriptBlock {
      $exists = Test-Path -Path "C:\Windows\SYSVOL\domain"
      $dfsr = Get-Service -Name DFSR -ErrorAction SilentlyContinue
      @{ sysvolExists = $exists; dfsrStatus = (if ($dfsr) { $dfsr.Status } else { "NotInstalled" }) }
    } -ErrorAction SilentlyContinue
    if ($svc) {
      $sysRow = [PSCustomObject]@{ DC = $dc.HostName; SysvolExists = $svc.sysvolExists; DFSRStatus = $svc.dfsrStatus }
    } else {
      $sysRow = [PSCustomObject]@{ DC = $dc.HostName; SysvolExists = "UNKNOWN"; DFSRStatus = "ERROR" }
    }
    $sysRow | Export-Csv -Path $sysCsv -NoTypeInformation -Encoding UTF8 -Append

    $start = (Get-Date).AddDays(-1 * $Days)
    $dirEvents = Invoke-Command -ComputerName $dc.HostName -ScriptBlock { param($st) Get-WinEvent -FilterHashtable @{LogName='Directory Service'; Level=2; StartTime=$st} -ErrorAction SilentlyContinue } -ArgumentList $start -ErrorAction SilentlyContinue
    $sysEvents = Invoke-Command -ComputerName $dc.HostName -ScriptBlock { param($st) Get-WinEvent -FilterHashtable @{LogName='System'; Level=2; StartTime=$st} -ErrorAction SilentlyContinue } -ArgumentList $start -ErrorAction SilentlyContinue

    $dirStr = ""
    if ($dirEvents) {
      $pieces = @()
      foreach ($e in $dirEvents | Select-Object -First 10) {
        $msg = $e.Message
        if ($msg.Length -gt 300) { $msg = $msg.Substring(0,300) }
        $pieces += ($e.TimeCreated.ToString("o") + " | " + $e.Id + " | " + $msg)
      }
      $dirStr = $pieces -join " <||> "
    }
    $sysStr = ""
    if ($sysEvents) {
      $pieces = @()
      foreach ($e in $sysEvents | Select-Object -First 10) {
        $msg = $e.Message
        if ($msg.Length -gt 300) { $msg = $msg.Substring(0,300) }
        $pieces += ($e.TimeCreated.ToString("o") + " | " + $e.Id + " | " + $msg)
      }
      $sysStr = $pieces -join " <||> "
    }
    $evRow = [PSCustomObject]@{ DC = $dc.HostName; DirectoryServiceErrors = $dirStr; SystemErrors = $sysStr }
    $evRow | Export-Csv -Path $eventCsv -NoTypeInformation -Encoding UTF8 -Append

  } catch {
    $err = [PSCustomObject]@{ DC = $dc.HostName; FailureCount = "ERROR"; FirstFailureTime = ""; FailureDetails = $_.Exception.Message }
    $err | Export-Csv -Path $failCsv -NoTypeInformation -Encoding UTF8 -Append

    $sysRow = [PSCustomObject]@{ DC = $dc.HostName; SysvolExists = "ERROR"; DFSRStatus = $_.Exception.Message }
    $sysRow | Export-Csv -Path $sysCsv -NoTypeInformation -Encoding UTF8 -Append

    $evRow = [PSCustomObject]@{ DC = $dc.HostName; DirectoryServiceErrors = "ERROR: " + $_.Exception.Message; SystemErrors = "" }
    $evRow | Export-Csv -Path $eventCsv -NoTypeInformation -Encoding UTF8 -Append
  }
}

# Merge CSVs into Excel workbook
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$workbook = $excel.Workbooks.Add()

$reports = @{
    "Replication Failures" = $failCsv
    "Partner Metadata" = $metaCsv
    "SYSVOL Status" = $sysCsv
    "Event Errors" = $eventCsv
}

foreach ($sheetName in $reports.Keys) {
    $csvFile = $reports[$sheetName]
    if (Test-Path $csvFile) {
        $worksheet = $workbook.Sheets.Add()
        $worksheet.Name = $sheetName
        $row = 1

        $csvData = Import-Csv $csvFile
        if ($csvData.Count -gt 0) {
            # Write headers
            $col = 1
            foreach ($header in $csvData[0].PSObject.Properties.Name) {
                $worksheet.Cells.Item($row, $col).Value2 = $header
                $col++
            }
            $row++

            # Write data rows
            foreach ($record in $csvData) {
                $col = 1
                foreach ($val in $record.PSObject.Properties.Value) {
                    $worksheet.Cells.Item($row, $col).Value2 = $val
                    $col++
                }
                $row++
            }
        }
    }
}


if ($workbook.Sheets.Item(1).UsedRange.Rows.Count -eq 0) {
    $workbook.Sheets.Item(1).Delete()
}

$workbook.SaveAs($excelPath)
$workbook.Close($true)
$excel.Quit()

Write-Host "AD health check completed. Excel report saved to: $excelPath" -ForegroundColor Green
