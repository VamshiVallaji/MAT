﻿<#
.SYNOPSIS Collect AD replication failures and partner metadata.
.PSVersion 5.1
#>
$OutFolder = "Z:\AD_ADHealthCheckReport"

$failCsv = Join-Path $OutFolder "Replication_Failures_$timeStamp.csv"
$metaCsv = Join-Path $OutFolder "Replication_PartnerMetadata_$timeStamp.csv"

Import-Module ActiveDirectory -ErrorAction Stop
$dcs = Get-ADDomainController -Filter * -ErrorAction Stop

"" | Select-Object DC,FailureCount,FirstFailureTime,FailureDetails | Export-Csv -Path $failCsv -NoTypeInformation -Encoding UTF8
"" | Select-Object DC,Partner,LastReplicationSuccess,UpToDatenessUSN,ReplicationPartner | Export-Csv -Path $metaCsv -NoTypeInformation -Encoding UTF8

foreach ($dc in $dcs) {
  try {
    $fails = Get-ADReplicationFailure -Target $dc.HostName -ErrorAction SilentlyContinue
    if ($fails) {
      foreach ($f in $fails) {
        $r = [PSCustomObject]@{
          DC = $dc.HostName
          FailureCount = $f.FailureCount
          FirstFailureTime = $f.FirstFailureTime
          FailureDetails = $f.Message
        }
        $r | Export-Csv -Path $failCsv -NoTypeInformation -Encoding UTF8 -Append
      }
    } else {
      $r = [PSCustomObject]@{ DC = $dc.HostName; FailureCount = 0; FirstFailureTime = ""; FailureDetails = "No reported failures" }
      $r | Export-Csv -Path $failCsv -NoTypeInformation -Encoding UTF8 -Append
    }

    $meta = Get-ADReplicationPartnerMetadata -Target $dc.HostName -ErrorAction SilentlyContinue
    if ($meta) {
      foreach ($m in $meta) {
        $rm = [PSCustomObject]@{
          DC = $dc.HostName
          Partner = $m.Partner
          LastReplicationSuccess = $m.LastReplicationSuccess
          UpToDatenessUSN = $m.UpToDatenessUSN
        }
        $rm | Export-Csv -Path $metaCsv -NoTypeInformation -Encoding UTF8 -Append
      }
    } else {
      $rm = [PSCustomObject]@{ DC = $dc.HostName; Partner = ""; LastReplicationSuccess = ""; UpToDatenessUSN = "" }
      $rm | Export-Csv -Path $metaCsv -NoTypeInformation -Encoding UTF8 -Append
    }
  } catch {
    $err = [PSCustomObject]@{ DC = $dc.HostName; FailureCount = "ERROR"; FirstFailureTime = ""; FailureDetails = $_.Exception.Message }
    $err | Export-Csv -Path $failCsv -NoTypeInformation -Encoding UTF8 -Append
  }
}
Write-Host ("Replication data exported to: " + $failCsv + " and " + $metaCsv) -ForegroundColor Green