﻿<#
.SYNOPSIS Check SYSVOL, DFSR service and recent errors on DCs.
.PSVersion 5.1
#>
$OutFolder = "Z:\AD_ADHealthCheckReport"

$sysCsv = Join-Path $OutFolder "DC_SYSVOL_Status_$timeStamp.csv"
$eventCsv = Join-Path $OutFolder "DC_EventErrors_$timeStamp.csv"

Import-Module ActiveDirectory -ErrorAction Stop
$dcs = Get-ADDomainController -Filter * -ErrorAction Stop

"" | Select-Object DC,SysvolExists,DFSRStatus | Export-Csv -Path $sysCsv -NoTypeInformation -Encoding UTF8
"" | Select-Object DC,DirectoryServiceErrors,SystemErrors | Export-Csv -Path $eventCsv -NoTypeInformation -Encoding UTF8

foreach ($dc in $dcs) {
  try {
    $svc = Invoke-Command -ComputerName $dc.HostName -ScriptBlock {
      $exists = Test-Path -Path "C:\Windows\SYSVOL\domain"
      $dfsr = Get-Service -Name DFSR -ErrorAction SilentlyContinue
      @{ sysvolExists = $exists; dfsrStatus = (if ($dfsr) { $dfsr.Status } else { "NotInstalled" }) }
    } -ErrorAction SilentlyContinue
    if ($svc) {
      $sysRow = [PSCustomObject]@{ DC = $dc.HostName; SysvolExists = $svc.sysvolExists; DFSRStatus = $svc.dfsrStatus }
    } else {
      $sysRow = [PSCustomObject]@{ DC = $dc.HostName; SysvolExists = "UNKNOWN"; DFSRStatus = "ERROR" }
    }
    $sysRow | Export-Csv -Path $sysCsv -NoTypeInformation -Encoding UTF8 -Append
  } catch {
    $sysRow = [PSCustomObject]@{ DC = $dc.HostName; SysvolExists = "ERROR"; DFSRStatus = $_.Exception.Message }
    $sysRow | Export-Csv -Path $sysCsv -NoTypeInformation -Encoding UTF8 -Append
  }

  # Events
  try {
    $start = (Get-Date).AddDays(-1 * $Days)
    $dirEvents = Invoke-Command -ComputerName $dc.HostName -ScriptBlock { param($st) Get-WinEvent -FilterHashtable @{LogName='Directory Service'; Level=2; StartTime=$st} -ErrorAction SilentlyContinue } -ArgumentList $start -ErrorAction SilentlyContinue
    $sysEvents = Invoke-Command -ComputerName $dc.HostName -ScriptBlock { param($st) Get-WinEvent -FilterHashtable @{LogName='System'; Level=2; StartTime=$st} -ErrorAction SilentlyContinue } -ArgumentList $start -ErrorAction SilentlyContinue

    $dirStr = ""
    if ($dirEvents) {
      $pieces = @()
      foreach ($e in $dirEvents | Select-Object -First 10) {
        $msg = $e.Message
        if ($msg.Length -gt 300) { $msg = $msg.Substring(0,300) }
        $pieces += ($e.TimeCreated.ToString("o") + " | " + $e.Id + " | " + $msg)
      }
      $dirStr = $pieces -join " <||> "
    }
    $sysStr = ""
    if ($sysEvents) {
      $pieces = @()
      foreach ($e in $sysEvents | Select-Object -First 10) {
        $msg = $e.Message
        if ($msg.Length -gt 300) { $msg = $msg.Substring(0,300) }
        $pieces += ($e.TimeCreated.ToString("o") + " | " + $e.Id + " | " + $msg)
      }
      $sysStr = $pieces -join " <||> "
    }
    $evRow = [PSCustomObject]@{ DC = $dc.HostName; DirectoryServiceErrors = $dirStr; SystemErrors = $sysStr }
    $evRow | Export-Csv -Path $eventCsv -NoTypeInformation -Encoding UTF8 -Append
  } catch {
    $evRow = [PSCustomObject]@{ DC = $dc.HostName; DirectoryServiceErrors = "ERROR: " + $_.Exception.Message; SystemErrors = "" }
    $evRow | Export-Csv -Path $eventCsv -NoTypeInformation -Encoding UTF8 -Append
  }
}
Write-Host ("SYSVOL/DFSR/event checks exported to: " + $sysCsv + " and " + $eventCsv) -ForegroundColor Green