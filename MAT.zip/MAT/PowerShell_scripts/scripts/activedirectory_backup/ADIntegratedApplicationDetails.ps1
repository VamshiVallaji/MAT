﻿# -------------------------
# Build Summary (PowerShell 5.1 safe)
# -------------------------

# Ensure $SummaryCsv and individual path/count variables exist earlier in the script
# e.g. $SummaryCsv = "$OutFolder\Summary.csv"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$OutFolder = "$network_drive\AD_ADIntegratedApplicationDetails\"
$summary = @()

# Helper function to return path or $null based on count
function Get-PathIfRows {
    param(
        [int]$Count,
        [string]$Path
    )
    if ($Count -gt 0) { return $Path } else { return $null }
}

# Add each report: compute path variable first, then create PSCustomObject
# Example entries — add/remove lines to match the reports your script actually creates

# 1) Service Principal Names (SPNs)
$spnPath = Get-PathIfRows -Count $spnCount -Path $SpnCsv
$summary += [PSCustomObject]@{
    Report = 'Service Principal Names (SPNs)'
    Path = $spnPath
    Rows = $spnCount
}

# 2) Service Accounts (heuristic)
$svcPath = Get-PathIfRows -Count $svcCount -Path $SvcCsv
$summary += [PSCustomObject]@{
    Report = 'Service Accounts (heuristic)'
    Path = $svcPath
    Rows = $svcCount
}

# 3) Managed Service Accounts (MSA)
$msaPath = Get-PathIfRows -Count $msaCount -Path $MsAcsv
$summary += [PSCustomObject]@{
    Report = 'Managed Service Accounts (MSA)'
    Path = $msaPath
    Rows = $msaCount
}

# 4) Service Connection Points (SCP)
$scpPath = Get-PathIfRows -Count $scpCount -Path $ScpCsv
$summary += [PSCustomObject]@{
    Report = 'Service Connection Points (SCP)'
    Path = $scpPath
    Rows = $scpCount
}

# 5) ADFS Relying Party Trusts (if your script collects these)
$adfsPath = Get-PathIfRows -Count $adfsCount -Path $AdfsCsv
$summary += [PSCustomObject]@{
    Report = 'ADFS Relying Party Trusts'
    Path = $adfsPath
    Rows = $adfsCount
}
<#
# 6) Example: Conditional Access / Other reports (add as needed)
# Replace variable names with the ones your script uses.
$otherPath = Get-PathIfRows -Count $otherCount -Path $OtherCsv
$summary += [PSCustomObject]@{
    Report = 'Other Report Name'
    Path = $otherPath
    Rows = $otherCount
}
#>
# --- Export summary ---
#$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")


if (-not (Test-Path $OutFolder)) {
New-Item -Path $OutFolder -ItemType Directory | Out-Null }

# default if not defined earlier
$SummaryCsv = Join-Path $OutFolder "Summary_$timeStamp.csv"

# Export summary to CSV (header-only when rows are all $null is handled by CSV format)
$summary | Export-Csv -Path $SummaryCsv -NoTypeInformation -Encoding UTF8

# Show summary to console nicely as table
$summary | Format-Table -AutoSize
Write-Host "Summary CSV created: $SummaryCsv" -ForegroundColor Green