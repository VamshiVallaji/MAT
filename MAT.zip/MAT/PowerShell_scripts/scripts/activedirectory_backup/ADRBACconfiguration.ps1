﻿# Export Active Directory RBAC (via Group Memberships)
# This will show each group, its members, and the type of object
$network_drive = (Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" |Select-Object -ExpandProperty DeviceID | Select-Object -First 1)
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$OutputFile = "$network_drive\AD_ADRBACconfiguration\AD_RBAC_Report_$timeStamp.csv"

# Fetch all AD groups and their members
$Results = Get-ADGroup -Filter * | ForEach-Object {
    $group = $_.Name
    $dn = $_.DistinguishedName

    try {
        Get-ADGroupMember $_ -ErrorAction Stop | ForEach-Object {
            [PSCustomObject]@{
                GroupName = $group
                GroupDistinguishedName = $dn
                MemberName = $_.Name
                MemberSamAccount = $_.SamAccountName
                MemberType = $_.ObjectClass
                MemberDistinguishedName = $_.DistinguishedName
            }
        }
    }
    catch {
        Write-Warning "Could not query members of group $group : $_"
    }
}

# Export results to CSV
$Results | Export-Csv -Path $OutputFile -NoTypeInformation -Encoding UTF8

Write-Host "RBAC report generated at: $OutputFile"
