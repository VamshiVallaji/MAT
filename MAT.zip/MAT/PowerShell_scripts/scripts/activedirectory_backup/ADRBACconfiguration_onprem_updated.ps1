﻿Import-Module ActiveDirectory -ErrorAction Stop

# Network drive & output file
$network_drive = (Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" |
    Select-Object -ExpandProperty DeviceID | Select-Object -First 1)
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$OutputFile = "$network_drive\AD_ADRBACconfiguration\AD_RBAC_Report_$timeStamp.csv"

# Helper: safely get samAccountName and DN
function Resolve-MemberInfo {
    param($adObject)
    $sam = $null
    try { $sam = $adObject.SamAccountName } catch {}
    if (-not $sam -or $sam -eq "") { $sam = $adObject.Name }
    $dn = $null
    try { $dn = $adObject.DistinguishedName } catch {}
    if (-not $dn -or $dn -eq "") {
        try {
            if ($adObject.ObjectGUID) {
                $resolved = Get-ADObject -Identity $adObject.ObjectGUID -Properties DistinguishedName -ErrorAction Stop
                $dn = $resolved.DistinguishedName
            }
        } catch {}
        if (-not $dn -or $dn -eq "") { $dn = $adObject.Name }
    }
    return [PSCustomObject]@{ Sam = $sam; DN = $dn }
}

# Recursive enumerator
function Get-GroupMembersRecursive {
    param(
        [Parameter(Mandatory)][string]$TopGroupName,
        [Parameter(Mandatory)][string]$TopGroupDN,
        [Parameter(Mandatory)][string]$CurrentGroupIdentity,
        [int]$CurrentLevel = 0,
        [string]$ParentChain = $null,
        [string]$ImmediateParent = $null,
        [ref]$Visited
    )

    if ([string]::IsNullOrEmpty($ParentChain)) {
        $chain = $TopGroupName
    } else {
        $chain = "$ParentChain > $CurrentGroupIdentity"
    }

    try {
        $members = Get-ADGroupMember -Identity $CurrentGroupIdentity -ErrorAction Stop
    } catch {
        Write-Warning "Could not query members of group '$CurrentGroupIdentity' : $_"
        return
    }

    foreach ($m in $members) {
        $info = Resolve-MemberInfo -adObject $m
        $memberDN = $info.DN
        $memberSam = $info.Sam
        $uniqueKey = $memberDN
        if (-not $uniqueKey) { $uniqueKey = "$($m.ObjectClass):$($m.Name)" }

        if ($Visited.Value.Contains($uniqueKey)) {
            [PSCustomObject]@{
                TopGroup = $TopGroupName
                TopGroupDistinguishedName = $TopGroupDN
                GroupName = $TopGroupName
                GroupDistinguishedName = $TopGroupDN
                NestedParentChain = $chain
                NestedLevel = $CurrentLevel
                ImmediateParent = $ImmediateParent
                MemberName = $m.Name
                MemberSamAccount = $memberSam
                MemberType = $m.ObjectClass
                MemberDistinguishedName = $memberDN
                DirectMember = ($CurrentLevel -eq 0)
                Note = "AlreadyVisited"
            }
            continue
        }

        $Visited.Value.Add($uniqueKey) | Out-Null

        if ($m.ObjectClass -ieq 'group') {
            [PSCustomObject]@{
                TopGroup = $TopGroupName
                TopGroupDistinguishedName = $TopGroupDN
                GroupName = $TopGroupName
                GroupDistinguishedName = $TopGroupDN
                NestedParentChain = $chain
                NestedLevel = $CurrentLevel
                ImmediateParent = $ImmediateParent
                MemberName = $m.Name
                MemberSamAccount = $memberSam
                MemberType = 'group'
                MemberDistinguishedName = $memberDN
                DirectMember = ($CurrentLevel -eq 0)
                Note = "NestedGroup"
            }

            Get-GroupMembersRecursive -TopGroupName $TopGroupName -TopGroupDN $TopGroupDN `
                -CurrentGroupIdentity $memberDN -CurrentLevel ($CurrentLevel + 1) `
                -ParentChain $chain -ImmediateParent $m.Name -Visited $Visited
        }
        else {
            [PSCustomObject]@{
                TopGroup = $TopGroupName
                TopGroupDistinguishedName = $TopGroupDN
                GroupName = $TopGroupName
                GroupDistinguishedName = $TopGroupDN
                NestedParentChain = $chain
                NestedLevel = $CurrentLevel
                ImmediateParent = $ImmediateParent
                MemberName = $m.Name
                MemberSamAccount = $memberSam
                MemberType = $m.ObjectClass
                MemberDistinguishedName = $memberDN
                DirectMember = ($CurrentLevel -eq 0)
                Note = ""
            }
        }
    }
}

# Main: iterate groups, excluding default system groups
$excludedGroups = @("Users", "Domain Users", "Domain Computers", "Domain Controllers")
$allGroups = Get-ADGroup -Filter * -Properties DistinguishedName | Where-Object {
    $excludedGroups -notcontains $_.Name
}

$results = foreach ($grp in $allGroups) {
    $topName = $grp.Name
    $topDN = $grp.DistinguishedName
    $visitedSet = New-Object System.Collections.Generic.HashSet[string]
    $visitedRef = [ref]$visitedSet

    Get-GroupMembersRecursive -TopGroupName $topName -TopGroupDN $topDN -CurrentGroupIdentity $topDN `
        -CurrentLevel 0 -ParentChain $null -ImmediateParent $null -Visited $visitedRef
}

$results | Export-Csv -Path $OutputFile -NoTypeInformation -Encoding UTF8

Write-Host "RBAC report (with nested groups expanded) generated at: $OutputFile"
