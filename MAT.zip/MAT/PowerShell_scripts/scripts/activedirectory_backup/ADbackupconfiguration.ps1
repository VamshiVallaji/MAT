﻿<#
.SYNOPSIS
  Collects existing AD/System-State backup details from domain controllers (no backups performed).

.DESCRIPTION
  - Discovers domain controllers via ActiveDirectory module (or accepts explicit list).
  - Runs 'wbadmin get versions' remotely on each DC and captures the text output.
  - Parses for backup targets, version identifiers, and best-effort last backup timestamp.
  - Outputs CSV report (C:\Reports\AD_Backup_Details_<timestamp>.csv) and includes raw wbadmin output.
  - PowerShell 5.1 compatible.

.PARAMETER DomainControllers
  Optional array of DC hostnames. If omitted the script will discover DCs via Get-ADDomainController.

.PARAMETER OutFolder
  Output folder path. Default: C:\Reports

.EXAMPLE
  .\Get-ADBackupDetails_Report.ps1
  (discovers DCs automatically)

.EXAMPLE
  .\Get-ADBackupDetails_Report.ps1 -DomainControllers "dc01","dc02" -OutFolder "D:\Reports"
#>

#$DomainControllers = @("MATADDC2","MATADDC3")
$DomainControllers = @("")
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$OutFolder = "$network_drive\AD_Adbackupconfiguration"

Set-StrictMode -Version Latest
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Fatal($m) { Write-Host "FATAL: $m" -ForegroundColor Red; exit 1 }

# Create out folder
try {
    if (-not (Test-Path -Path $OutFolder)) { New-Item -Path $OutFolder -ItemType Directory -Force | Out-Null }
} catch {
    Fatal "Cannot create output folder $OutFolder : $($_.Exception.Message)"
}

$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$outCsv = Join-Path $OutFolder ("AD_Backup_Details_{0}.csv" -f $timeStamp)

# Discover DCs if none provided
if (-not $DomainControllers -or $DomainControllers.Count -eq 0) {
    if (Get-Module -ListAvailable -Name ActiveDirectory) {
        try {
            Import-Module ActiveDirectory -ErrorAction Stop
            Write-Host "Discovering domain controllers via ActiveDirectory module..." -ForegroundColor Cyan
            $dcs = Get-ADDomainController -Filter * | Select-Object -ExpandProperty HostName
            $DomainControllers = $dcs
        } catch {
            Write-Host "Failed to discover DCs via ActiveDirectory module: $($_.Exception.Message)." -ForegroundColor Yellow
            $DomainControllers = @()
        }
    } else {
        Write-Host "ActiveDirectory module not available and no DomainControllers passed. Please supply -DomainControllers." -ForegroundColor Yellow
        $DomainControllers = @()
    }
}

if (-not $DomainControllers -or $DomainControllers.Count -eq 0) {
    Write-Host "No domain controllers to query. Creating header-only CSV and exiting." -ForegroundColor Yellow
    "" | Select-Object DCName,Reachable,VersionsFound,BackupTargets,MostRecentBackupUtc,RawOutput,Error |
        Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Force
    Write-Host "Header-only CSV created at: $outCsv" -ForegroundColor Green
    exit 0
}

Write-Host ("Will query {0} domain controller(s): {1}" -f $DomainControllers.Count, ($DomainControllers -join ', ')) -ForegroundColor Cyan

# Helper: parse wbadmin output
function Parse-WBAdminOutput {
    param([string[]]$Lines)

    $joined = ($Lines -join "`n")
    $result = @{
        VersionsFound = 0
        BackupTargets = @()
        MostRecentBackupUtc = $null
        RawOutput = $joined
    }

    if (-not $Lines -or $Lines.Count -eq 0) { return $result }

    # Count occurrences of "Version identifier" (common wbadmin label)
    $versionIdentifiers = $Lines | Where-Object { $_ -match '(?i)Version identifier' }
    if ($versionIdentifiers) {
        $result.VersionsFound = $versionIdentifiers.Count
    } else {
        # fallback: count lines that look like a date/time/version header
        $possibleVersionLines = $Lines | Where-Object { $_ -match '\d{1,2}/\d{1,2}/\d{4}' -or $_ -match '\d{4}-\d{2}-\d{2}' }
        $result.VersionsFound = ($possibleVersionLines | Measure-Object).Count
    }

    # Extract Backup Target lines (common labels: "Backup target:", "Backup Target:", "Target:")
    $targets = $Lines | Where-Object { $_ -match '(?i)backup target' -or $_ -match '(?i)^target:' -or $_ -match '(?i)backup to' }
    foreach ($t in $targets) {
        # try to capture after colon
        if ($t -match ':\s*(.+)$') { $result.BackupTargets += $matches[1].Trim() } else { $result.BackupTargets += $t.Trim() }
    }

    # Best-effort parse dates/times from the text (several common patterns)
    # Patterns:
    # - mm/dd/yyyy hh:mm[:ss] [AM|PM]
    # - yyyy-mm-dd hh:mm[:ss]
    # - mm/dd/yyyy-hh:mm (sometimes shown as date-time in identifiers)
    $dateCandidates = @()

    foreach ($line in $Lines) {
        # mm/dd/yyyy (with time)
        if ($line -match '(\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM)?)') {
            $dateCandidates += $matches[1]
        }
        # yyyy-mm-dd hh:mm[:ss]
        if ($line -match '(\d{4}-\d{2}-\d{2}\s+\d{1,2}:\d{2}(?::\d{2})?)') {
            $dateCandidates += $matches[1]
        }
        # mm/dd/yyyy-hh:mm or mm/dd/yyyy-hh:mm:ss
        if ($line -match '(\d{1,2}/\d{1,2}/\d{4}-\d{1,2}:\d{2}(?::\d{2})?)') {
            $dateCandidates += $matches[1]
        }
        # "Backup time:" style (capture following text)
        if ($line -match '(?i)Backup time[:\s-]+(.+)$') {
            $dateCandidates += $matches[1].Trim()
        }
        # "Version identifier:" sometimes contains date-like token
        if ($line -match '(?i)Version identifier[:\s-]+(.+)$') {
            $dateCandidates += $matches[1].Trim()
        }
    }

    # Normalize and parse candidates to DateTime where possible
    $parsedDates = @()
    foreach ($c in $dateCandidates) {
        $s = $c.Trim()
        # replace dash between date/time with space for parsing
        $s2 = $s -replace '-', ' '
        # attempt [datetime] cast in multiple cultures: first invariant, then en-US
        try {
            $dt = [datetime]::Parse($s2)
            $parsedDates += $dt.ToUniversalTime()
            continue
        } catch {}
        try {
            $dt = [datetime]::ParseExact($s2, 'M/d/yyyy h:mm tt', $null)
            $parsedDates += $dt.ToUniversalTime()
            continue
        } catch {}
        try {
            $dt = [datetime]::ParseExact($s2, 'yyyy-MM-dd H:mm', $null)
            $parsedDates += $dt.ToUniversalTime()
            continue
        } catch {}
        # last resort: try to find ISO-like substring
        if ($s2 -match '\d{4}-\d{2}-\d{2}T\d{2}:\d{2}') {
            try {
                $dt = [datetime]::Parse($matches[0])
                $parsedDates += $dt.ToUniversalTime()
            } catch {}
        }
    }

    if ($parsedDates.Count -gt 0) {
        # pick the newest
        $result.MostRecentBackupUtc = ($parsedDates | Sort-Object)[-1].ToString("u")
    }

    # If no backupTargets found, attempt to detect lines with UNC like \\server\share
    if ($result.BackupTargets.Count -eq 0) {
        $uncs = $Lines | Where-Object { $_ -match '\\\\[^\s\\]+' }
        foreach ($u in $uncs) {
            if ($u -match '(\\\\[^\\\s]+\\[^\s\\]+)') { $result.BackupTargets += $matches[1] }
        }
    }

    # dedupe
    $result.BackupTargets = ($result.BackupTargets | Where-Object { $_ -and $_.Trim() -ne "" } | Select-Object -Unique)

    return $result
}

# For each DC, run wbadmin get versions remotely and parse
$results = @()
foreach ($dc in $DomainControllers) {
    Write-Host ("Querying DC: {0}" -f $dc) -ForegroundColor Cyan
    $entry = [ordered]@{
        DCName = $dc
        Reachable = $false
        VersionsFound = 0
        BackupTargets = ""
        MostRecentBackupUtc = ""
        RawOutput = ""
        Error = ""
    }

    # Use Invoke-Command to run wbadmin remotely; fall back to Enter-PSSession alternative if WinRM blocked
    try {
        $scriptBlock = {
            # run wbadmin get versions and capture stdout/stderr as lines
            $out = & wbadmin get versions 2>&1
            # return as object with lines
            return ,$out
        }
        $wbLines = Invoke-Command -ComputerName $dc -ScriptBlock $scriptBlock -ErrorAction Stop
        if ($wbLines -and $wbLines.Count -gt 0) {
            $entry.Reachable = $true
            $entry.RawOutput = ($wbLines -join "`n")
            $parsed = Parse-WBAdminOutput -Lines $wbLines
            $entry.VersionsFound = $parsed.VersionsFound
            $entry.BackupTargets = ($parsed.BackupTargets -join '; ')
            $entry.MostRecentBackupUtc = $parsed.MostRecentBackupUtc
        } else {
            # no output returned
            $entry.Error = "No wbadmin output (empty)."
        }
    } catch {
        $entry.Error = $_.Exception.Message
    }

    $results += New-Object PSObject -Property $entry
}

# Export results to CSV
if ($results.Count -eq 0) {
    "" | Select-Object DCName,Reachable,VersionsFound,BackupTargets,MostRecentBackupUtc,RawOutput,Error |
        Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Force
    Write-Host "No results collected; header-only CSV created: $outCsv" -ForegroundColor Yellow
} else {
    $results | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Force
    Write-Host ("Export complete: {0} rows -> {1}" -f $results.Count, $outCsv) -ForegroundColor Green
}

Write-Host "Done."