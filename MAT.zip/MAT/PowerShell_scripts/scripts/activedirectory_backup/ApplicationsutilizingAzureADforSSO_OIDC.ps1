﻿$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutFolder = "Z:\AD_ApplicationsutilizingAzureADforSSO"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

# Define output file
$outputFile = "EnterpriseApplications_NonSAML_SSOConfig-Graph_$timeStamp.csv"

# Initialize an array for storing SSO configurations
$ssoConfigs = @()

# Fetch all Enterprise Applications (Service Principals)
Write-Host "Fetching Enterprise Applications..."
$enterpriseApplications = Get-MgServicePrincipal -All

foreach ($app in $enterpriseApplications) {
    Write-Host "Processing Enterprise Application: $($app.DisplayName)" -ForegroundColor Yellow

    try {
        # Check if the application is NOT SAML-based
        if ($app.PreferredSingleSignOnMode -ne "saml") {
            # Extract EntityId (ServicePrincipalName excluding AppId)
            $entityId = if ($app.ServicePrincipalNames) {
                $filteredServicePrincipalNames = $app.ServicePrincipalNames | Where-Object { $_ -ne $app.AppId }
                $filteredServicePrincipalNames -join ";"  # Join remaining values
            } else {
                "Not Available"
            }

            # Extract ReplyUrls (ACS URLs)
            $replyUrls = if ($app.ReplyUrls) {
                $app.ReplyUrls -join ";"
            } else {
                "Not Available"
            }

            # Extract SignOnUrl, LogoutUrl, and AppRoleAssignmentRequired
            $signOnUrl = $app.LoginUrl
            $logoutUrl = $app.LogoutUrl
            $AssignmentRequired = $app.AppRoleAssignmentRequired
            $PreferredSingleSignOnMode = $app.PreferredSingleSignOnMode
            $SignInAudience = $app.SignInAudience
            $PreferredTokenSigningKeyThumbprint = $app.PreferredTokenSigningKeyThumbprint

            # Extract Certificate Expiration Date
            $certificateExpirationDate = "Not Available"
            if ($app.KeyCredentials) {
                try {
                    $utcExpirationDate = $app.KeyCredentials | Where-Object { $_.Type -eq "AsymmetricX509Cert" } | Sort-Object EndDateTime -Descending | Select-Object -First 1 -ExpandProperty EndDateTime
                    if ($utcExpirationDate) {
                        $certificateExpirationDate = (Get-Date $utcExpirationDate).ToLocalTime()
                    }
                } catch {
                    Write-Host "Could not fetch certificate expiration for: $($app.DisplayName)" -ForegroundColor Gray
                }
            }

            # Fetch User Assignments
            $userAssignments = "Not Available"
            try {
                $assignedUsers = Get-MgServicePrincipalAppRoleAssignedTo -ServicePrincipalId $app.Id -All | Where-Object { $_.PrincipalType -eq "User" }
                if ($assignedUsers) {
                    $userAssignments = ($assignedUsers | ForEach-Object { $_.PrincipalDisplayName }) -join ";"
                } else {
                    $userAssignments = "No Users Assigned"
                }
            } catch {
                Write-Host "Error fetching user assignments for: $($app.DisplayName)" -ForegroundColor Gray
            }

            # Fetch Group Assignments
            $groupAssignments = "Not Available"
            try {
                $assignedGroups = Get-MgServicePrincipalAppRoleAssignedTo -ServicePrincipalId $app.Id -All | Where-Object { $_.PrincipalType -eq "Group" }
                if ($assignedGroups) {
                    $groupAssignments = ($assignedGroups | ForEach-Object { $_.PrincipalDisplayName }) -join ";"
                } else {
                    $groupAssignments = "No Groups Assigned"
                }
            } catch {
                Write-Host "Error fetching group assignments for: $($app.DisplayName)" -ForegroundColor Gray
            }

            # Append the results to the array
            $ssoConfigs += [PSCustomObject]@{
                ApplicationName       = $app.DisplayName
                ObjectId              = $app.Id
                AppId                 = $app.AppId
                ReplyUrls             = $replyUrls
                EntityId              = $entityId
                SignOnUrl             = $signOnUrl
                LogoutUrl             = $logoutUrl
                AssignmentRequired    = $AssignmentRequired
                UserAssignments       = $userAssignments
                GroupAssignments      = $groupAssignments
                PreferredSingleSignOnMode = $PreferredSingleSignOnMode
                SignInAudience        = $SignInAudience
                PreferredTokenSigningKeyThumbprint = $PreferredTokenSigningKeyThumbprint
                CertificateExpiration = $certificateExpirationDate
            }
        } else {
            Write-Host "Skipping SAML SSO configuration for: $($app.DisplayName)" -ForegroundColor Gray
        }
    } catch {
        Write-Host "Error processing application: $($app.DisplayName)" -ForegroundColor Red
    }
}

# Export the results to a CSV file
$ssoConfigs | Export-Csv -Path $OutFolder\$outputFile -NoTypeInformation -Encoding UTF8

Write-Host "Non-SAML SSO configuration export completed. File saved to $outputFile" -ForegroundColor Green
