﻿<#
.SYNOPSIS
  Gather AD authentication protocol configuration & exposure from domain controllers (on-prem).

.DESCRIPTION
  - Discovers domain controllers (Get-ADDomainController) if none provided.
  - Remotely reads NTLM / LDAP signing registry keys, checks LDAPS/LDAP/Kerberos ports, finds server certs for LDAPS, and Netlogon service state.
  - Exports CSV report (per-DC).
  - PowerShell 5.1 compatible.

.PARAMETER DomainControllers
  Optional list of domain controller hostnames/FQDNs. If omitted, script will try to discover DCs.

.PARAMETER OutFolder
  Output folder (default C:\Reports).

#>
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

param(
  [string[]]$DomainControllers,
  [string]$OutFolder = "$network_drive\AD_AuthenticationProtocolsEnabled"
)


Set-StrictMode -Version Latest
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Fatal($m){ Write-Host "FATAL: $m" -ForegroundColor Red; exit 1 }

# Ensure OutFolder
try {
  if (-not(Test-Path -Path $OutFolder)) { New-Item -Path $OutFolder -ItemType Directory -Force | Out-Null }
} catch { Fatal "Cannot create OutFolder $OutFolder : $($_.Exception.Message)" }

$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$outCsv = Join-Path $OutFolder ("AD_AuthProtocols_{0}.csv" -f $timeStamp)

# Auto-discover DCs if not supplied
if (-not $DomainControllers -or $DomainControllers.Count -eq 0) {
  if (Get-Module -ListAvailable -Name ActiveDirectory) {
    try {
      Import-Module ActiveDirectory -ErrorAction Stop
      Write-Host "Discovering domain controllers..." -ForegroundColor Cyan
      $DomainControllers = Get-ADDomainController -Filter * | Select-Object -ExpandProperty HostName
    } catch {
      Write-Host "Warning: failed to discover DCs via ActiveDirectory module: $($_.Exception.Message)" -ForegroundColor Yellow
      $DomainControllers = @()
    }
  } else {
    Write-Host "ActiveDirectory module not available and no DomainControllers passed. Please pass -DomainControllers." -ForegroundColor Yellow
    $DomainControllers = @()
  }
}

if (-not $DomainControllers -or $DomainControllers.Count -eq 0) {
  Write-Host "No domain controllers to query. Creating header-only CSV and exiting." -ForegroundColor Yellow
  "" | Select-Object DCName,Reachable,LmCompatibilityLevel,LmCompatibilityText,RestrictSendingNTLMTraffic,RestrictReceivingNTLMTraffic,ClientAllowedNTLMServers,LDAPServerIntegrity,LdapClientIntegrity,LDAPS_PortOpen,LDAP_PortOpen,Kerberos_PortOpen,NetlogonServiceState,LDAPS_CertFound,Notes |
    Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Force
  Write-Host "Header-only CSV created at: $outCsv" -ForegroundColor Green
  exit 0
}

Write-Host ("Querying {0} domain controllers..." -f $DomainControllers.Count) -ForegroundColor Cyan

# Helper: map LmCompatibilityLevel to friendly text
function LmCompatText($val) {
  switch ($val) {
    0 { return "Send LM & NTLM responses (LM & NTLMv1 allowed)" }
    1 { return "Send LM & NTLM - use NTLMv2 session security if negotiated" }
    2 { return "Send NTLM response only" }
    3 { return "Send NTLMv2 response only" }
    4 { return "Send NTLMv2 response only. Refuse LM" }
    5 { return "Send NTLMv2 response only. Refuse LM & NTLM" }
    default { return "Unknown or not set" }
  }
}

# Scriptblock to run on each DC to collect registry values, certs and service state
$collectScript = {
  param($dcFqdn)

  $result = [ordered]@{
    DCName = $env:COMPUTERNAME
    Reachable = $true
    LmCompatibilityLevel = $null
    LmCompatibilityText = $null
    RestrictSendingNTLMTraffic = $null
    RestrictReceivingNTLMTraffic = $null
    ClientAllowedNTLMServers = $null
    LDAPServerIntegrity = $null
    LdapClientIntegrity = $null
    LDAPS_PortOpen = $false
    LDAP_PortOpen = $false
    Kerberos_PortOpen = $false
    NetlogonServiceState = $null
    LDAPS_CertFound = $false
    Notes = ""
  }

  # -- Registry reads (safe) --
  try {
    # LmCompatibilityLevel
    $lck = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "LmCompatibilityLevel" -ErrorAction SilentlyContinue
    if ($lck -ne $null) { $result.LmCompatibilityLevel = $lck.LmCompatibilityLevel }

    # NTLM restrict keys (under MSV1_0)
    $msv = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0" -ErrorAction SilentlyContinue
    if ($msv -ne $null) {
      if ($msv.PSObject.Properties.Name -contains "RestrictSendingNTLMTraffic") { $result.RestrictSendingNTLMTraffic = $msv.RestrictSendingNTLMTraffic }
      if ($msv.PSObject.Properties.Name -contains "RestrictReceivingNTLMTraffic") { $result.RestrictReceivingNTLMTraffic = $msv.RestrictReceivingNTLMTraffic }
      if ($msv.PSObject.Properties.Name -contains "ClientAllowedNTLMServers") { $result.ClientAllowedNTLMServers = ($msv.ClientAllowedNTLMServers -join ";") }
    }

    # LDAP signing keys
    $ntdsParams = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NTDS\Parameters" -ErrorAction SilentlyContinue
    if ($ntdsParams -ne $null -and $ntdsParams.PSObject.Properties.Name -contains "LDAPServerIntegrity") { $result.LDAPServerIntegrity = $ntdsParams.LDAPServerIntegrity }
    # Ldap client integrity is often under Services\LDAP
    $ldapSvc = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LDAP" -ErrorAction SilentlyContinue
    if ($ldapSvc -ne $null -and $ldapSvc.PSObject.Properties.Name -contains "LdapClientIntegrity") { $result.LdapClientIntegrity = $ldapSvc.LdapClientIntegrity }
  } catch {
    $result.Notes += "RegistryReadError: $($_.Exception.Message); "
  }

  # Friendly LM text
  try {
    if ($null -ne $result.LmCompatibilityLevel) {
      switch ($result.LmCompatibilityLevel) {
        0 { $result.LmCompatibilityText = "Send LM & NTLM responses (LM & NTLMv1 allowed)" }
        1 { $result.LmCompatibilityText = "Send LM & NTLM - use NTLMv2 session security if negotiated" }
        2 { $result.LmCompatibilityText = "Send NTLM response only" }
        3 { $result.LmCompatibilityText = "Send NTLMv2 response only" }
        4 { $result.LmCompatibilityText = "Send NTLMv2 response only. Refuse LM" }
        5 { $result.LmCompatibilityText = "Send NTLMv2 response only. Refuse LM & NTLM" }
        default { $result.LmCompatibilityText = "Unknown or custom" }
      }
    }
  } catch {}

  # -- Check listening ports (TCP) --
  try {
    # LDAP (389)
    $ldap = Test-NetConnection -ComputerName $dcFqdn -Port 389 -WarningAction SilentlyContinue
    if ($ldap -and $ldap.TcpTestSucceeded) { $result.LDAP_PortOpen = $true }
  } catch { $result.Notes += "LDAPPortTestError: $($_.Exception.Message); " }

  try {
    # LDAPS (636)
    $ldaps = Test-NetConnection -ComputerName $dcFqdn -Port 636 -WarningAction SilentlyContinue
    if ($ldaps -and $ldaps.TcpTestSucceeded) { $result.LDAPS_PortOpen = $true }
  } catch { $result.Notes += "LDAPSPortTestError: $($_.Exception.Message); " }

  try {
    # Kerberos (88)
    $k88 = Test-NetConnection -ComputerName $dcFqdn -Port 88 -WarningAction SilentlyContinue
    if ($k88 -and $k88.TcpTestSucceeded) { $result.Kerberos_PortOpen = $true }
  } catch { $result.Notes += "KerbPortTestError: $($_.Exception.Message); " }

  # -- Netlogon service state --
  try {
    $svc = Get-Service -Name Netlogon -ErrorAction SilentlyContinue
    if ($svc -ne $null) { $result.NetlogonServiceState = $svc.Status } else { $result.NetlogonServiceState = "NotFound" }
  } catch { $result.NetlogonServiceState = "SvcQueryError" }

  # -- LDAPS certificate presence (LocalMachine\My with Server Auth EKU) --
  try {
    $found = $false
    $now = Get-Date
    $certs = Get-ChildItem -Path Cert:\LocalMachine\My -ErrorAction SilentlyContinue
    if ($certs) {
      foreach ($c in $certs) {
        # check EKU contains Server Authentication OID 1.3.6.1.5.5.7.3.1
        $eku = $c.Extensions | Where-Object { $_ -is [System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension] }
        $hasServerAuth = $false
        if ($eku) {
          foreach ($ext in $eku) {
            foreach ($oid in $ext.EnhancedKeyUsages) {
              if ($oid.Value -eq "1.3.6.1.5.5.7.3.1") { $hasServerAuth = $true; break }
            }
            if ($hasServerAuth) { break }
          }
        }
        if ($hasServerAuth -and $c.NotAfter -gt $now -and $c.NotBefore -lt $now) { $found = $true; break }
      }
    }
    $result.LDAPS_CertFound = $found
  } catch {
    $result.Notes += "CertCheckError: $($_.Exception.Message); "
  }

  return $result
}

# Collect results
$results = @()
foreach ($dc in $DomainControllers) {
  Write-Host ("Collecting from: {0}" -f $dc) -ForegroundColor Gray
  $entry = [ordered]@{ DCName=$dc; Reachable=$false; LmCompatibilityLevel=$null; LmCompatibilityText=""; RestrictSendingNTLMTraffic=$null; RestrictReceivingNTLMTraffic=$null; ClientAllowedNTLMServers=""; LDAPServerIntegrity=$null; LdapClientIntegrity=$null; LDAPS_PortOpen=$false; LDAP_PortOpen=$false; Kerberos_PortOpen=$false; NetlogonServiceState=""; LDAPS_CertFound=$false; Notes="" }

  try {
    # Use Invoke-Command to run the collectScript on the remote DC. Pass fqdn as parameter to use for Test-NetConnection
    $remoteResult = Invoke-Command -ComputerName $dc -ScriptBlock $collectScript -ArgumentList $dc -ErrorAction Stop
    if ($remoteResult -ne $null) {
      $entry.Reachable = $true
      $entry.LmCompatibilityLevel = $remoteResult.LmCompatibilityLevel
      $entry.LmCompatibilityText = $remoteResult.LmCompatibilityText
      $entry.RestrictSendingNTLMTraffic = $remoteResult.RestrictSendingNTLMTraffic
      $entry.RestrictReceivingNTLMTraffic = $remoteResult.RestrictReceivingNTLMTraffic
      $entry.ClientAllowedNTLMServers = $remoteResult.ClientAllowedNTLMServers
      $entry.LDAPServerIntegrity = $remoteResult.LDAPServerIntegrity
      $entry.LdapClientIntegrity = $remoteResult.LdapClientIntegrity
      $entry.LDAPS_PortOpen = $remoteResult.LDAPS_PortOpen
      $entry.LDAP_PortOpen = $remoteResult.LDAP_PortOpen
      $entry.Kerberos_PortOpen = $remoteResult.Kerberos_PortOpen
      $entry.NetlogonServiceState = $remoteResult.NetlogonServiceState
      $entry.LDAPS_CertFound = $remoteResult.LDAPS_CertFound
      $entry.Notes = $remoteResult.Notes
    } else {
      $entry.Notes = "NoResultFromInvokeCommand"
    }
  } catch {
    $entry.Notes = $_.Exception.Message
  }

  $results += New-Object PSObject -Property $entry
}

# Export to CSV
try {
  $results | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Force
  Write-Host ("Export complete: {0} rows -> {1}" -f $results.Count, $outCsv) -ForegroundColor Green
} catch {
  Fatal "Failed to write CSV: $($_.Exception.Message)"
}

Write-Host "Done." -ForegroundColor Cyan