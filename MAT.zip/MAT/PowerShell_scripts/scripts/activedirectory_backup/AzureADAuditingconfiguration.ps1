﻿<#
.SYNOPSIS
  Azure AD auditing configuration & usage report (PowerShell 5.1, CSV outputs).

.DESCRIPTION
  - PowerShell 5.1 compatible (no inline-if in hashtables).
  - Uses Microsoft Graph (Connect-MgGraph + Invoke-MgGraphRequest).
  - Exports CSV files to OutFolder:
      SignInsSample.csv, SignInsSummary.csv,
      DirectoryAuditsSample.csv, DirectoryAuditsSummary.csv,
      DirectoryRolesMembers.csv

.PARAMETER TenantId
  Tenant ID or tenant domain (e.g. contoso.onmicrosoft.com)

.PARAMETER ClientId
  App (client) id used to authenticate.

.PARAMETER ClientSecret
  Client secret for the app.

.PARAMETER OutFolder
  Output folder for CSV reports.

.PARAMETER Days
  Number of days to look back for sign-in/audit counts (default 30).

.PARAMETER SampleSize
  Number of sample log entries to export for sign-ins / directory audits (default 200).

.NOTES
  - Requires application permissions: AuditLog.Read.All, Directory.Read.All (admin consent)
  - Ensure Microsoft.Graph module is installed and importable: Import-Module Microsoft.Graph
#>

param(
  [Parameter(Mandatory=$false)][int]$Days = 30,
  [Parameter(Mandatory=$false)][int]$SampleSize = 200
)

$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutFolder = "$network_drive\AD_AzureADAuditingconfiguration"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "NOTE: Ensure Microsoft.Graph module is available in this session (Import-Module Microsoft.Graph)."
Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."
Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null
# Helper: ISO timestamp for $Days ago
$startDateTime = (Get-Date).ToUniversalTime().AddDays(-1 * [int]$Days).ToString("o")
$nowDateTime = (Get-Date).ToUniversalTime().ToString("o")

# -----------------------
# 1) Sign-in logs summary & sample
# -----------------------
Write-Host "Fetching sign-in logs sample for last $Days days..."
$signinsSample = @()
try {
  $top = [int]$SampleSize
  $uri = "https://graph.microsoft.com/v1.0/auditLogs/signIns?`$filter=createdDateTime ge $startDateTime&`$orderby=createdDateTime desc&`$top=$top"
  $res = Invoke-MgGraphRequest -Method GET -Uri $uri -ErrorAction SilentlyContinue
  if ($res -and $res.value) { $signinsSample = $res.value }
} catch {
  Write-Warning "Failed to fetch sign-in logs sample: $_"
}

# Build sign-ins CSV rows (precompute fields to avoid inline-if)
$signinsRows = @()
foreach ($s in $signinsSample) {
  $sid = $null; try { $sid = $s.id } catch {}
  $created = $null; try { $created = $s.createdDateTime } catch {}
  $userDisplayName = ""; try { if ($s.userDisplayName) { $userDisplayName = ($s.userDisplayName -replace "`r|`n"," ") } } catch {}
  $userPrincipalName = ""; try { $userPrincipalName = $s.userPrincipalName } catch {}
  $userId = ""; try { $userId = $s.userId } catch {}
  $appDisplayName = ""; try { $appDisplayName = $s.appDisplayName } catch {}
  $resourceDisplayName = ""; try { $resourceDisplayName = $s.resourceDisplayName } catch {}
  $ipAddress = ""; try { $ipAddress = $s.ipAddress } catch {}
  $clientAppUsed = ""; try { $clientAppUsed = $s.clientAppUsed } catch {}
  $conditionalAccessStatus = ""; try { $conditionalAccessStatus = $s.conditionalAccessStatus } catch {}
  $statusText = ""
  try {
    if ($s.status -and ($s.status.errorCode -ne $null)) {
      $statusText = $s.status.errorCode
    } else {
      # status might be an object/array — try serialize a readable form
      $tmp = ""
      try { $tmp = ($s.status | ConvertTo-Json -Depth 2) } catch { $tmp = "" }
      $statusText = $tmp
    }
  } catch {}

  $signinsRows += [PSCustomObject]@{
    Id = $sid
    CreatedDateTime = $created
    UserDisplayName = $userDisplayName
    UserPrincipalName = $userPrincipalName
    UserId = $userId
    AppDisplayName = $appDisplayName
    ResourceDisplayName = $resourceDisplayName
    IpAddress = $ipAddress
    ClientAppUsed = $clientAppUsed
    ConditionalAccessStatus = $conditionalAccessStatus
    Status = $statusText
  }
}

# Export sign-ins sample CSV (header-only if no rows)
$signinsSampleCsv = Join-Path $OutFolder "SignInsSample_$timeStamp.csv"
if ($signinsRows.Count -gt 0) {
  $signinsRows | Export-Csv -Path $signinsSampleCsv -NoTypeInformation -Encoding UTF8
  Write-Host "Wrote sign-ins sample: $signinsSampleCsv (rows: $($signinsRows.Count))"
} else {
  "" | Select-Object Id,CreatedDateTime,UserDisplayName,UserPrincipalName,UserId,AppDisplayName,ResourceDisplayName,IpAddress,ClientAppUsed,ConditionalAccessStatus,Status |
    Export-Csv -Path $signinsSampleCsv -NoTypeInformation -Encoding UTF8
  Write-Host "No sign-in entries found; created header-only CSV: $signinsSampleCsv"
}

# Sign-ins summary CSV (single row)
$signinsSummaryCsv = Join-Path $OutFolder "SignInsSummary_$timeStamp.csv"
$signinsSampleCount = ($signinsRows | Measure-Object).Count
# attempt approximate count: set -1 if can't determine easily
$signinsApproxCount = -1
try {
  # Try a count query (may not return full count for large tenants)
  $cntUri = "https://graph.microsoft.com/v1.0/auditLogs/signIns?`$filter=createdDateTime ge $startDateTime&`$top=1"
  $tmpRes = Invoke-MgGraphRequest -Method GET -Uri $cntUri -ErrorAction SilentlyContinue
  if ($tmpRes -and -not $tmpRes.'@odata.nextLink') {
    $signinsApproxCount = $tmpRes.value.Count
  } else {
    $signinsApproxCount = -1
  }
} catch { $signinsApproxCount = -1 }

$signinsSummaryObj = [PSCustomObject]@{
  StartDate = $startDateTime
  EndDate = $nowDateTime
  SampleFetched = $signinsSampleCount
  ApproxTotalCount = $signinsApproxCount
  Notes = "ApproxTotalCount may be -1 if full count not retrievable via simple query (paging or permissions)."
}
$signinsSummaryObj | Export-Csv -Path $signinsSummaryCsv -NoTypeInformation -Encoding UTF8
Write-Host "Wrote sign-ins summary: $signinsSummaryCsv"

# -----------------------
# 2) Directory audit logs summary & sample
# -----------------------
Write-Host "Fetching directory audit logs sample for last $Days days..."
$auditsSample = @()
try {
  $top = [int]$SampleSize
  $uri = "https://graph.microsoft.com/v1.0/auditLogs/directoryAudits?`$filter=activityDateTime ge $startDateTime&`$orderby=activityDateTime desc&`$top=$top"
  $res = Invoke-MgGraphRequest -Method GET -Uri $uri -ErrorAction SilentlyContinue
  if ($res -and $res.value) { $auditsSample = $res.value }
} catch {
  Write-Warning "Failed to fetch directory audit logs sample: $_"
}

# Build audits CSV rows (precompute InitiatedBy and TargetResources)
$auditsRows = @()
foreach ($a in $auditsSample) {
  $aid = $null; try { $aid = $a.id } catch {}
  $activityDateTime = $null; try { $activityDateTime = $a.activityDateTime } catch {}
  $activityDisplayName = ""; try { if ($a.activityDisplayName) { $activityDisplayName = ($a.activityDisplayName -replace "`r|`n"," ") } } catch {}
  $loggedByService = ""; try { $loggedByService = $a.loggedByService } catch {}

  # InitiatedBy logic (user vs app)
  $initiatedBy = ""
  try {
    if ($a.initiatedBy -and $a.initiatedBy.user -and $a.initiatedBy.user.displayName) {
      $initiatedBy = $a.initiatedBy.user.displayName
    } elseif ($a.initiatedBy -and $a.initiatedBy.app -and $a.initiatedBy.app.displayName) {
      $initiatedBy = $a.initiatedBy.app.displayName
    } else {
      $initiatedBy = ""
    }
  } catch { $initiatedBy = "" }

  # TargetResources: join displayName of each target resource if present
  $targetResources = ""
  try {
    if ($a.targetResources) {
      $names = @()
      foreach ($t in $a.targetResources) {
        try {
          if ($t.displayName) { $names += $t.displayName }
        } catch {}
      }
      if ($names.Count -gt 0) { $targetResources = ($names -join ";") }
    }
  } catch { $targetResources = "" }

  $resultText = ""; try { $resultText = $a.result } catch {}
  $resultReason = ""; try { $resultReason = $a.resultReason } catch {}

  $auditsRows += [PSCustomObject]@{
    Id = $aid
    ActivityDateTime = $activityDateTime
    ActivityDisplayName = $activityDisplayName
    LoggedByService = $loggedByService
    InitiatedBy = $initiatedBy
    TargetResources = $targetResources
    Result = $resultText
    ResultReason = $resultReason
  }
}

# Export directory audits sample CSV
$auditsSampleCsv = Join-Path $OutFolder "DirectoryAuditsSample_$timeStamp.csv"
if ($auditsRows.Count -gt 0) {
  $auditsRows | Export-Csv -Path $auditsSampleCsv -NoTypeInformation -Encoding UTF8
  Write-Host "Wrote directory audit sample: $auditsSampleCsv (rows: $($auditsRows.Count))"
} else {
  "" | Select-Object Id,ActivityDateTime,ActivityDisplayName,LoggedByService,InitiatedBy,TargetResources,Result,ResultReason |
    Export-Csv -Path $auditsSampleCsv -NoTypeInformation -Encoding UTF8
  Write-Host "No directory audit entries found; created header-only CSV: $auditsSampleCsv"
}

# Audits summary CSV
$auditsSummaryCsv = Join-Path $OutFolder "DirectoryAuditsSummary_$timeStamp.csv"
$auditsSampleCount = ($auditsRows | Measure-Object).Count
$auditsApproxCount = -1
try {
  $cntUri = "https://graph.microsoft.com/v1.0/auditLogs/directoryAudits?`$filter=activityDateTime ge $startDateTime&`$top=1"
  $tmpRes = Invoke-MgGraphRequest -Method GET -Uri $cntUri -ErrorAction SilentlyContinue
  if ($tmpRes -and -not $tmpRes.'@odata.nextLink') {
    $auditsApproxCount = $tmpRes.value.Count
  } else {
    $auditsApproxCount = -1
  }
} catch { $auditsApproxCount = -1 }

$auditsSummaryObj = [PSCustomObject]@{
  StartDate = $startDateTime
  EndDate = $nowDateTime
  SampleFetched = $auditsSampleCount
  ApproxTotalCount = $auditsApproxCount
}
$auditsSummaryObj | Export-Csv -Path $auditsSummaryCsv -NoTypeInformation -Encoding UTF8
Write-Host "Wrote directory audits summary: $auditsSummaryCsv"

# -----------------------
# 3) Directory roles and members
# -----------------------
Write-Host "Fetching directory roles and members..."
$rolesMembers = @()
try {
  $rolesRes = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/directoryRoles" -ErrorAction SilentlyContinue
  if ($rolesRes -and $rolesRes.value) {
    foreach ($r in $rolesRes.value) {
      $roleId = $null; try { $roleId = $r.id } catch {}
      $roleName = $null; try { $roleName = $r.displayName } catch {}

      $members = @()
      try {
        $memRes = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/directoryRoles/$roleId/members" -ErrorAction SilentlyContinue
        if ($memRes -and $memRes.value) { $members = $memRes.value }
      } catch {}

      if ($members.Count -eq 0) {
        $rolesMembers += [PSCustomObject]@{
          RoleName = $roleName
          RoleId = $roleId
          MemberType = ""
          MemberDisplayName = ""
          MemberUserPrincipalName = ""
          MemberId = ""
        }
      } else {
        foreach ($m in $members) {
          $memberType = ""; try { $memberType = ($m.'@odata.type' -replace "#microsoft.graph.","") } catch {}
          $display = ""; try { $display = $m.displayName } catch {}
          $upn = ""; try { $upn = $m.userPrincipalName } catch {}
          $mid = ""; try { $mid = $m.id } catch {}
          $rolesMembers += [PSCustomObject]@{
            RoleName = $roleName
            RoleId = $roleId
            MemberType = $memberType
            MemberDisplayName = $display
            MemberUserPrincipalName = $upn
            MemberId = $mid
          }
        }
      }
    }
  }
} catch {
  Write-Warning "Failed to fetch directory roles/members: $_"
}

$rolesMembersCsv = Join-Path $OutFolder "DirectoryRolesMembers_$timeStamp.csv"
if ($rolesMembers.Count -gt 0) {
  $rolesMembers | Export-Csv -Path $rolesMembersCsv -NoTypeInformation -Encoding UTF8
  Write-Host "Wrote directory roles & members: $rolesMembersCsv (rows: $($rolesMembers.Count))"
} else {
  "" | Select-Object RoleName,RoleId,MemberType,MemberDisplayName,MemberUserPrincipalName,MemberId |
    Export-Csv -Path $rolesMembersCsv -NoTypeInformation -Encoding UTF8
  Write-Host "No directory role data found; created header-only CSV: $rolesMembersCsv"
}

# -----------------------
# Done & disconnect
# -----------------------
Write-Host "All reports written to folder: $OutFolder"
try { Disconnect-MgGraph -ErrorAction SilentlyContinue } catch {}

# End of script