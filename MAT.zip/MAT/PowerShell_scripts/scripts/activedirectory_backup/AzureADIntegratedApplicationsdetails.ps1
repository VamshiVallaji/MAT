﻿<#
.SYNOPSIS
  Inventory Azure AD integrated applications (App Registrations + Service Principals) for PowerShell 5.1.
  CSV only output.

.DESCRIPTION
  - Non-interactive (app-only) auth using client secret.
  - Exports AppRegistrations.csv and ServicePrincipals.csv.
  - Compatible with PowerShell 5.1 (explicit null checks, no ?. operators).
  - Requires Microsoft.Graph module already installed/imported.

.PARAMETER TenantId
  Tenant ID or tenant domain (e.g. contoso.onmicrosoft.com)

.PARAMETER ClientId
  App (client) id used to authenticate.

.PARAMETER ClientSecret
  Client secret for the app (or change to certificate auth manually).

.PARAMETER OutFolder
  Output folder to store CSV reports.

.EXAMPLE
  .\Get-AADIntegratedApps-PS5-CSVOnly.ps1 -TenantId 'contoso.onmicrosoft.com' -ClientId 'xxxx' -ClientSecret 'secret' -OutFolder 'C:\Reports\AADApps'
#>

$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutDir = "$network_drive\AD_AzureADIntegratedApplicationsddetails"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")


# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."
#$secureSecret = ConvertTo-SecureString $ClientSecret -AsPlainText -Force

  Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null


# ---------------------------
# Fetch App Registrations
# ---------------------------
Write-Host "Fetching App Registrations..."
try {
  $apps = Get-MgApplication -All -ErrorAction Stop
} catch {
  Write-Warning "Get-MgApplication failed: $_"
  $apps = @()
}

$appsOut = @()
foreach ($app in $apps) {
  # owners
  $ownersList = @()
  try {
    $owners = Get-MgApplicationOwner -ApplicationId $app.Id -ErrorAction SilentlyContinue
    if ($owners) {
      foreach ($o in $owners) {
        $display = $null
        if ($o.AdditionalProperties -and $o.AdditionalProperties.ContainsKey("displayName")) {
          $display = $o.AdditionalProperties["displayName"]
        } elseif ($o.PSObject.Properties.Match("DisplayName")) {
          $display = $o.DisplayName
        }
        $ownersList += $display
      }
    }
  } catch {}

  # Reply URLs
  $replyUrls = ""
  if ($app -and $app.Web -and $app.Web.RedirectUris) {
    try { $replyUrls = ($app.Web.RedirectUris -join ";") } catch { $replyUrls = "" }
  }

  $appsOut += [PSCustomObject]@{
    AppId = $app.AppId
    DisplayName = $app.DisplayName
    Id = $app.Id
    PublisherDomain = $app.PublisherDomain
    SignInAudience = $app.SignInAudience
    CreatedDateTime = $app.CreatedDateTime
    ReplyUrls = $replyUrls
    Owners = ($ownersList -join ";")
  }
}

# Export App Registrations to CSV
$appsOut | Export-Csv -Path (Join-Path $OutDir "AppRegistrations_$timeStamp.csv") -NoTypeInformation -Encoding UTF8
Write-Host "App Registrations exported to $OutDir\AppRegistrations.csv"

# ---------------------------
# Fetch Service Principals
# ---------------------------
Write-Host "Fetching Service Principals..."
try {
  $sps = Get-MgServicePrincipal -All -ErrorAction Stop
} catch {
  Write-Warning "Get-MgServicePrincipal failed: $_"
  $sps = @()
}

$spsOut = @()
foreach ($sp in $sps) {
  # owners
  $ownersList = @()
  try {
    $owners = Get-MgServicePrincipalOwner -ServicePrincipalId $sp.Id -ErrorAction SilentlyContinue
    if ($owners) {
      foreach ($o in $owners) {
        $display = $null
        if ($o.AdditionalProperties -and $o.AdditionalProperties.ContainsKey("displayName")) {
          $display = $o.AdditionalProperties["displayName"]
        } elseif ($o.PSObject.Properties.Match("DisplayName")) {
          $display = $o.DisplayName
        }
        $ownersList += $display
      }
    }
  } catch {}

  $tags = ""
  if ($sp -and $sp.Tags) {
    try { $tags = ($sp.Tags -join ";") } catch { $tags = "" }
  }

  $spsOut += [PSCustomObject]@{
    DisplayName = $sp.DisplayName
    AppId = $sp.AppId
    Id = $sp.Id
    AppOwnerOrganization = $sp.AppOwnerOrganizationId
    Tags = $tags
    ServicePrincipalType = $sp.ServicePrincipalType
    AccountEnabled = $sp.AccountEnabled
    Owners = ($ownersList -join ";")
  }
}

# Export Service Principals to CSV
$spsOut | Export-Csv -Path (Join-Path $OutDir "ServicePrincipals_$timeStamp.csv") -NoTypeInformation -Encoding UTF8
Write-Host "Service Principals exported to $OutDir\ServicePrincipals.csv"

Write-Host "Summary: CSV reports saved under $OutDir"

try { Disconnect-MgGraph -ErrorAction SilentlyContinue } catch {}
