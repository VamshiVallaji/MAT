﻿<#
.SYNOPSIS
  Collects on-prem Active Directory RBAC configuration details (privileged groups and their members).
  Exports to CSV.

.DESCRIPTION
  - Enumerates well-known privileged groups in AD.
  - Lists members (direct) with SamAccountName, DisplayName, and DistinguishedName.
  - Useful for auditing RBAC configuration in on-prem AD DS.

.PARAMETER OutFolder
  Output folder for CSV reports.

.EXAMPLE
  .\Get-ADRBACConfigReport.ps1 -OutFolder "C:\Reports\AD_RBAC"
#>
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

  $OutFolder = "$network_drive\AD_AzureADRBAC"
  $timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")


# Ensure output folder
if (-not (Test-Path -Path $OutFolder)) {
  New-Item -ItemType Directory -Path $OutFolder | Out-Null
}

# List of privileged groups to audit
$PrivilegedGroups = @(
  "Enterprise Admins",
  "Domain Admins",
  "Schema Admins",
  "Administrators",
  "Account Operators",
  "Server Operators",
  "Backup Operators",
  "Print Operators",
  "Cert Publishers",
  "DnsAdmins",
  "Group Policy Creator Owners"
)

$results = @()

foreach ($groupName in $PrivilegedGroups) {
  try {
    $group = Get-ADGroup -Identity $groupName -ErrorAction Stop
    $members = Get-ADGroupMember -Identity $groupName -Recursive | ForEach-Object {
      $user = $_
      $display = $null
      try { $display = (Get-ADUser -Identity $user -Properties DisplayName -ErrorAction SilentlyContinue).DisplayName } catch {}
      [PSCustomObject]@{
        GroupName = $groupName
        GroupSID = $group.SID.Value
        MemberSamAccount = $user.SamAccountName
        MemberName = $display
        MemberType = $user.objectClass
        DistinguishedName= $user.DistinguishedName
      }
    }
    if ($members) { $results += $members }
  } catch {
    Write-Warning "Group $groupName not found in this domain."
  }
}

# Export to CSV
$outFile = Join-Path $OutFolder "AD_RBAC_Config_$timeStamp.csv"
$results | Export-Csv -Path $outFile -NoTypeInformation -Encoding UTF8

Write-Host "Report exported to $outFile"