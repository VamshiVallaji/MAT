﻿<#
.SYNOPSIS
  Simple Azure AD / Entra tenant summary (one CSV).

.DESCRIPTION
  - PowerShell 5.1 compatible.
  - Connects app-only to Microsoft Graph using client secret.
  - Exports one CSV with a few key counts and sample sizes.
  - Minimal, easy-to-read code.

.PARAMETER TenantId
  Tenant id or domain (eg contoso.onmicrosoft.com)

.PARAMETER ClientId
  App (client) id.

.PARAMETER ClientSecret
  Client secret.

.PARAMETER OutFolder
  Output folder (default: .\AAD_TenantSummary_YYYYMMDD_HHMMSS)
#>

$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutFolder = "$network_drive\AD_AzureTenantdetails"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

# Initialize variables with safe try/catch assignments
$tenantDisplayName = ""; $tenantGuid = ""; $domainCount = 0
$userSampleCount = 0; $approxTotalUsers = -1
$appRegsSampleCount = 0; $spSampleCount = 0
$caPolicyCount = -1

# 1) Organization (tenant) info
try {
  $org = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/organization" -ErrorAction SilentlyContinue
  if ($org -and $org.value -and $org.value.Count -gt 0) {
    $t = $org.value[0]
    try { if ($t.displayName) { $tenantDisplayName = $t.displayName } } catch {}
    try { if ($t.id) { $tenantGuid = $t.id } } catch {}
  }
} catch {}

# 2) Domains count
try {
  $domains = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/domains" -ErrorAction SilentlyContinue
  if ($domains -and $domains.value) { $domainCount = $domains.value.Count } else { $domainCount = 0 }
} catch { $domainCount = 0 }

# 3) Users sample and approximate count (simple)
try {
  $uRes = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/users?`$top=5&`$select=id" -ErrorAction SilentlyContinue
  if ($uRes -and $uRes.value) { $userSampleCount = $uRes.value.Count } else { $userSampleCount = 0 }
} catch { $userSampleCount = 0 }

# approximate total users (best-effort)
try {
  $cntRes = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/users?`$top=1" -ErrorAction SilentlyContinue
  if ($cntRes -and $cntRes.'@odata.nextLink') { $approxTotalUsers = -1 } elseif ($cntRes -and $cntRes.value) { $approxTotalUsers = $cntRes.value.Count } else { $approxTotalUsers = $userSampleCount }
} catch { $approxTotalUsers = -1 }

# 4) Application registrations sample count
try {
  $aRes = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/applications?`$top=5&`$select=id" -ErrorAction SilentlyContinue
  if ($aRes -and $aRes.value) { $appRegsSampleCount = $aRes.value.Count } else { $appRegsSampleCount = 0 }
} catch { $appRegsSampleCount = 0 }

# 5) Service principals (enterprise apps) sample count
try {
  $spRes = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/servicePrincipals?`$top=5&`$select=id" -ErrorAction SilentlyContinue
  if ($spRes -and $spRes.value) { $spSampleCount = $spRes.value.Count } else { $spSampleCount = 0 }
} catch { $spSampleCount = 0 }

# 6) Conditional Access policies count (requires Policy.Read.All)
try {
  $caRes = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/identity/conditionalAccess/policies" -ErrorAction SilentlyContinue
  if ($caRes -and $caRes.value) { $caPolicyCount = $caRes.value.Count } else { $caPolicyCount = 0 }
} catch { $caPolicyCount = -1 } # -1 means permission/other error

# Build one-row summary object
$summary = [PSCustomObject]@{
  TenantDisplayName = $tenantDisplayName
  TenantId = $tenantGuid
  DomainCount = $domainCount
  UserSampleSize = $userSampleCount
  ApproxTotalUsers = $approxTotalUsers
  AppRegistrationsSample = $appRegsSampleCount
  ServicePrincipalsSample = $spSampleCount
  ConditionalAccessPoliciesCount = $caPolicyCount
  CollectedOn = (Get-Date).ToUniversalTime().ToString("o")
}

# Export single CSV (header-only behavior handled by Export-Csv automatically for one object)
$outCsv = Join-Path $OutFolder "TenantSummary_$timeStamp.csv"
$summary | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8

Write-Host "Tenant summary exported to: $outCsv" -ForegroundColor Green

# Disconnect
try { Disconnect-MgGraph -ErrorAction SilentlyContinue } catch {}

# End
