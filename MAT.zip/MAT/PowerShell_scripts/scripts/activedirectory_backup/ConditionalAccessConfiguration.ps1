﻿<#
.SYNOPSIS
  Export Azure AD Conditional Access policies to CSV (cloud-only).

.DESCRIPTION
  - Queries Microsoft Graph /identity/conditionalAccess/policies.
  - Collects details: ID, Name, State, Conditions, Grant Controls, Session Controls.
  - Exports CSV to $OutFolder.
  - PowerShell 5.1 compatible.

.PARAMETER TenantId
  Tenant ID or tenant domain (e.g. contoso.onmicrosoft.com)

.PARAMETER ClientId
  App (client) id used to authenticate.

.PARAMETER ClientSecret
  Client secret for the app.

.PARAMETER OutFolder
  Output folder for CSV report.

.EXAMPLE
  .\Get-AAD-CAPolicies-Report.ps1 -TenantId 'contoso.onmicrosoft.com' -ClientId 'xxxx' -ClientSecret 'secret' -OutFolder 'C:\Reports\CA'
#>

$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutFolder = "$network_drive\AD_ConditionalAccessConfiguration"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

# ------------------------------------
# Collect Conditional Access policies
# ------------------------------------
Write-Host "Fetching Conditional Access policies..."
$policies = @()
$uri = "https://graph.microsoft.com/v1.0/identity/conditionalAccess/policies"

do {
  try {
    $res = Invoke-MgGraphRequest -Method GET -Uri $uri -ErrorAction Stop
    if ($res.value) { $policies += $res.value }
    $uri = $null
    try { $uri = $res.'@odata.nextLink' } catch {}
  } catch {
    Write-Warning "Failed to fetch policies: $_"
    $uri = $null
  }
} while ($uri)

Write-Host "Collected $($policies.Count) policies."

# ------------------------------------
# Build report
# ------------------------------------
$report = @()
foreach ($p in $policies) {
  $policyId = $p.id
  $name = $p.displayName
  $state = $p.state

  # Conditions
  $users = ""
  try {
    if ($p.conditions.users) {
      $incl = ""
      if ($p.conditions.users.includeUsers) { $incl = "Include: " + ($p.conditions.users.includeUsers -join ";") }
      $excl = ""
      if ($p.conditions.users.excludeUsers) { $excl = "Exclude: " + ($p.conditions.users.excludeUsers -join ";") }
      $users = "$incl $excl"
    }
  } catch {}

  $apps = ""
  try {
    if ($p.conditions.applications) {
      $incl = ""
      if ($p.conditions.applications.includeApplications) { $incl = "Include: " + ($p.conditions.applications.includeApplications -join ";") }
      $excl = ""
      if ($p.conditions.applications.excludeApplications) { $excl = "Exclude: " + ($p.conditions.applications.excludeApplications -join ";") }
      $apps = "$incl $excl"
    }
  } catch {}

  $platforms = ""
  try {
    if ($p.conditions.platforms) {
      $incl = ""
      if ($p.conditions.platforms.includePlatforms) { $incl = "Include: " + ($p.conditions.platforms.includePlatforms -join ";") }
      $excl = ""
      if ($p.conditions.platforms.excludePlatforms) { $excl = "Exclude: " + ($p.conditions.platforms.excludePlatforms -join ";") }
      $platforms = "$incl $excl"
    }
  } catch {}

  $locations = ""
  try {
    if ($p.conditions.locations) {
      $incl = ""
      if ($p.conditions.locations.includeLocations) { $incl = "Include: " + ($p.conditions.locations.includeLocations -join ";") }
      $excl = ""
      if ($p.conditions.locations.excludeLocations) { $excl = "Exclude: " + ($p.conditions.locations.excludeLocations -join ";") }
      $locations = "$incl $excl"
    }
  } catch {}

  $clientApps = ""
  try {
    if ($p.conditions.clientAppTypes) { $clientApps = ($p.conditions.clientAppTypes -join ";") }
  } catch {}

  # Controls
  $grantControls = ""
  try {
    if ($p.grantControls) {
      $grantControls = (($p.grantControls.builtInControls + $p.grantControls.customAuthenticationFactors) -join ";")
    }
  } catch {}

  $sessionControls = ""
  try {
    if ($p.sessionControls) {
      $sessionControls = ($p.sessionControls | ConvertTo-Json -Depth 3 -Compress)
    }
  } catch {}

  $report += [PSCustomObject]@{
    PolicyId = $policyId
    DisplayName = $name
    State = $state
    Users = $users
    Applications = $apps
    Platforms = $platforms
    Locations = $locations
    ClientApps = $clientApps
    GrantControls = $grantControls
    SessionControls = $sessionControls
  }
}

# ------------------------------------
# Export report
# ------------------------------------
$outCsv = Join-Path $OutFolder "ConditionalAccessPolicies_$timeStamp.csv"

if ($report.Count -gt 0) {
  $report | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
  Write-Host "Exported Conditional Access policies to $outCsv"
} else {
  "" | Select-Object PolicyId,DisplayName,State,Users,Applications,Platforms,Locations,ClientApps,GrantControls,SessionControls |
    Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
  Write-Host "No Conditional Access policies found; created header-only CSV: $outCsv"
}

# Disconnect
try { Disconnect-MgGraph -ErrorAction SilentlyContinue } catch {}