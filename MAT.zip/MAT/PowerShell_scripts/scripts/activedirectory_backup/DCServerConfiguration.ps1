﻿#Domain Controllers
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$JsonPath = "$network_drive\Config.json"

$Timestamp = Get-Date -Format "yyyyMMdd-HHmm"

$ReportPath = "$network_drive/AD_DCServerconfiguration"

$Dom = (Get-ADDomain).DNSRoot

$FileName = "DomainControllers_{0}_{1}.csv" -f $Dom, $Timestamp

$FullPath = Join-Path $ReportPath $FileName

$Forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
$Forest.Sites | ForEach-Object { $_.Servers } -ErrorAction SilentlyContinue | Select-Object Domain, Name, IPAddress, OSVersion, SiteName | Export-Csv -Path $FullPath -NoTypeInformation -Encoding UTF8

Write-Host "Saved Domain controller report to $FullPath"