$AllDCs = Get-ADDomainController -Filter * | Select-Object -ExpandProperty HostName
$DomainFQDN = (Get-ADDomain).DNSRoot
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$outputFile = "$network_drive\AD_DNSForwarders\DNSForwarders_$timeStamp.csv"

# Create header first (overwrite old file)
"" | Select-Object DCName, UserRootHint, Timeout, EnableReordering, IPAddress, ReorderedIPAddress |
    Export-Csv $outputFile -NoTypeInformation

foreach ($DC in $AllDCs) {
    if ($DC -like "*.$DomainFQDN") {
        $fqdn = $DC
    } else {
        $fqdn = "$DC.$DomainFQDN"
    }

    Write-Host "Querying $fqdn ..." -ForegroundColor Cyan

    try {
        $fb = Get-DnsServerForwarder -ComputerName $fqdn -ErrorAction Stop | ForEach-Object {
            [PSCustomObject]@{
                DCName = $fqdn
                UserRootHint = $_.UseRootHint
                Timeout = $_.Timeout
                EnableReordering = $_.EnableReordering
                IPAddress = ($_.IPAddress -join ";")
                ReorderedIPAddress = ($_.ReorderedIPAddress -join ";")
            }
        }

        $fb | Export-Csv $outputFile -Append -NoTypeInformation
        Write-Host "Successfully queried $fqdn" -ForegroundColor Green
    }
    catch {
        Write-Host "Warning: Failed to query DNS forwarders on $fqdn" -ForegroundColor Yellow
    }
}
