﻿<#.
SYNOPSIS  On-prem DNS collection (auto-detect domain) - produces two CSVs even when no data:    
- DC_DNS_IP_Report_<timestamp>.csv (NIC + forwarders + conditional forwarders)    
- DNS_Zones_<timestamp>.csv (zone list + aging/scavenge settings)
.DESCRIPTION  - Auto-detects current domain (uses AD module when available, falls back to WMI/CIM).  
- Attempts DNSServer cmdlets first; falls back to WMI/CIM when module unavailable.  
- Ensures CSV files always contain well-formed headers (and a single blank row) if no data collected.  
- Designed to run elevated on a domain-joined machine. If DNSServer cmdlets are required, run on a DNS server    
or install RSAT DNS tools on the machine running the script.
.NOTES  - Save as Export-DNS-Reports_AutoDomain_Full.ps1 and run from an elevated PowerShell session.  
- Optional: Uncomment Connect-MgGraph line at top if you still need Graph connectivity elsewhere.#>
# ---------------- Auto-detect domain ----------------
function Get-CurrentDomainDnsRoot {    
    # Try AD module first    
    if (Get-Module -ListAvailable ActiveDirectory) {        
        try {            
            Import-Module ActiveDirectory -ErrorAction Stop            
            $dnsRoot = (Get-ADDomain -ErrorAction Stop).DNSRoot            
            if ($dnsRoot) { return $dnsRoot.Trim() }        
        } 
        catch {
            # fall back below        
}    }
            # Try using CIM (Win32_ComputerSystem)    
            try {        
                $root = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop        
                if ($root.Domain -and ($root.Domain -ne $env:COMPUTERNAME)) {            
                    return $root.Domain        
                }    
            }
            catch {}
            # Last resort: environment variable (NetBIOS only)    
            if ($env:USERDOMAIN) { return $env:USERDOMAIN }
            throw "Unable to auto-detect domain. Install RSAT/ActiveDirectory or run on a domain-joined machine."
        }
        try {    
            $detectedDomain = Get-CurrentDomainDnsRoot    Write-Host "Detected domain: $detectedDomain"
        } 
        catch { Write-Error "Domain detection failed: $($_.Exception.Message)"    return }
        # ---------------- common config & outputs ----------------
        # Optional: keep your Graph connect line if needed elsewhere; uncomment to enable.
        # Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null
        # Output directory (mapped drive). If absent, fallback to C:\Temp
	$network_drive1 = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

        $network_drive = "$network_drive1\AD_ConditionalFrwdrs_Aging_Scaving"
        $timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
        $DnsIpCsv = Join-Path $network_drive "DC_DNS_IP_Report_$timeStamp.csv"
        $DnsZoneCsv = Join-Path $network_drive "DNS_Zones_$timeStamp.csv"
        $PreferADCmdlets = $false
        $ThrottleMs = 120
        $VerbosePreference = 'Continue'
        $Domains = @($detectedDomain)
        # ---------------- helpers ----------------
        function Get-DomainControllersForDomain {
            param([string]$DomainName)
            # Try netdom first    
            try {        
                $ndRaw = netdom query /domain:$DomainName dc 2>$null        
                if ($ndRaw) {            
                    $nd = $ndRaw -split "`r?`n" | Where-Object { $_ -and ($_ -notmatch 'accounts|completed') } | ForEach-Object { $_.Trim() }            
                    if ($nd -and $nd.Count -gt 0) { return $nd }        
                }    
            } 
            catch {}
            # Optional AD cmdlet fallback    
            if ($PreferADCmdlets -and (Get-Module -ListAvailable ActiveDirectory)) {        
                try {            
                    Import-Module ActiveDirectory -ErrorAction SilentlyContinue            
                    $dcs = Get-ADDomainController -Filter * -Server $DomainName | Select-Object -ExpandProperty HostName            
                    if ($dcs) { return $dcs }        
                } 
                catch {}    
            }
            # DNS SRV fallback    
            try {        
                $rr = Resolve-DnsName -Name "_ldap._tcp.dc._msdcs.$DomainName" -Type SRV -ErrorAction SilentlyContinue        
                if ($rr) {            
                    $hosts = $rr | ForEach-Object { ($_.NameTarget -replace '\.$', '') } | Select-Object -Unique            
                    if ($hosts) { return $hosts }        
                }    
            } 
            catch {}
            return @()
        }
        function Try-GetDnsServerForwardersAndConditional {
            param([string]$Fqdn)    $out = [PSCustomObject]@{ ComputerName = $Fqdn; Forwarders = $null; ConditionalForwarders = $null }
            # Prefer DNSServer module cmdlets    
            if (Get-Module -ListAvailable DnsServer) {        
                try {            
                    $fw = Get-DnsServerForwarder -ComputerName $Fqdn -ErrorAction Stop            
                    if ($fw) { 
                        $out.Forwarders = ($fw.IPAddress -join ',') 
                    }        
                } 
                catch {}        
                try {            
                    $cfs = Get-DnsServerConditionalForwarderZone -ComputerName $Fqdn -ErrorAction Stop            
                    if ($cfs) { $out.ConditionalForwarders = ($cfs | ForEach-Object { "$($_.ZoneName) -> $($_.MasterServers -join ',')" } ) -join ' ; ' }        
                } 
                catch {}    
            }
            # Fallback to WMI/CIM for forwarders when cmdlets not available    
            if (-not $out.Forwarders) {        
                try {
                    $w = Get-WmiObject -Namespace root\MicrosoftDNS -Class MicrosoftDNS_Server -ComputerName $Fqdn -ErrorAction SilentlyContinue            
                    if ($w) {
                        if ($w.Forwarders) { $out.Forwarders = ($w.Forwarders -join ',') }                
                        elseif ($w.ServerAddresses) { $out.Forwarders = ($w.ServerAddresses -join ',') }            
                    }        
                } 
                catch {}    
            }
            return $out
        }
        function Try-GetDnsServerZonesWithAging {
            param([string]$Fqdn)    $zones = @()
            # Prefer DNSServer module    
            if (Get-Module -ListAvailable DnsServer) {        
                try {            
                    $zones = Get-DnsServerZone -ComputerName $Fqdn -ErrorAction Stop |                
                    Select-Object @{Name = 'Server'; Expression = { $Fqdn } }, ZoneName, ZoneType, DynamicUpdate, IsAutoCreated, IsDsIntegrated, IsReverseLookupZone, ReplicationScope, DirectoryPartitionName, MasterServers, NotifyServers, SecondaryServers
                    foreach ($z in $zones) {
                        if ($z.ZoneType -eq 'Primary') { 
                            try {
                                $za = Get-DnsServerZoneAging -ComputerName $Fqdn -ZoneName $z.ZoneName -ErrorAction Stop                        
                                $z | Add-Member -MemberType NoteProperty -Name AgingEnabled -Value $za.AgingEnabled -Force                        
                                $z | Add-Member -MemberType NoteProperty -Name NoRefreshInterval -Value $za.NoRefreshInterval -Force                        
                                $z | Add-Member -MemberType NoteProperty -Name RefreshInterval -Value $za.RefreshInterval -Force                        
                                $z | Add-Member -MemberType NoteProperty -Name ScavengeServers -Value $za.ScavengeServers -Force 
                            } 
                            catch {
                                $z | Add-Member -MemberType NoteProperty -Name AgingEnabled -Value $null -Force                        
                                $z | Add-Member -MemberType NoteProperty -Name NoRefreshInterval -Value $null -Force                        
                                $z | Add-Member -MemberType NoteProperty -Name RefreshInterval -Value $null -Force                        
                                $z | Add-Member -MemberType NoteProperty -Name ScavengeServers -Value $null -Force 
                            } 
                        } 
                        else {
                            $z | Add-Member -MemberType NoteProperty -Name AgingEnabled -Value $null -Force                    
                            $z | Add-Member -MemberType NoteProperty -Name NoRefreshInterval -Value $null -Force                    
                            $z | Add-Member -MemberType NoteProperty -Name RefreshInterval -Value $null -Force                    
                            $z | Add-Member -MemberType NoteProperty -Name ScavengeServers -Value $null -Force 
                        } 
                    }            
                    return $zones        
                }
                catch {
                    # fall through to WMI if module cmdlets fail        
                }    
            }
            # WMI/CIM fallback: attempt to read zones via WMI class (less detailed)    
            try {        
                $wzones = Get-WmiObject -Namespace root\MicrosoftDNS -Class MicrosoftDNS_Zone -ComputerName $Fqdn -ErrorAction SilentlyContinue        
                foreach ($wz in $wzones) {            
                    $obj = [PSCustomObject]@{                
                        Server                 = $Fqdn                
                        ZoneName               = $wz.Name                
                        ZoneType               = $wz.ZoneType                
                        DynamicUpdate          = $null                
                        IsAutoCreated          = $null                
                        IsDsIntegrated         = $null                
                        IsReverseLookupZone    = $null                
                        ReplicationScope       = $null                
                        DirectoryPartitionName = $null                
                        MasterServers          = $null                
                        NotifyServers          = $null                
                        SecondaryServers       = $null                
                        AgingEnabled           = $null                
                        NoRefreshInterval      = $null                
                        RefreshInterval        = $null                
                        ScavengeServers        = $null            
                    }            
                    $zones += $obj        
                }    
            } 
            catch {}
            return $zones 
        }
        # ---------------- Export-DNSServerIPConfiguration ----------------
        function Export-DNSServerIPConfiguration {    
            param([string[]]$DomainList)
            $dnsReportRows = @()
            foreach ($domain in $DomainList) {        
                Write-Host "Enumerating DCs for domain: $domain"        
                $dcs = Get-DomainControllersForDomain -DomainName $domain        
                if (-not $dcs -or $dcs.Count -eq 0) {            
                    Write-Warning "No domain controllers found for $domain. Skipping."            
                    continue        
                }
                foreach ($dc in $dcs) {            
                    $fqdn = $(if ($dc -match '\.') { $dc } else { "$dc.$domain" })            
                    Write-Host "Processing DNS server: $fqdn"
                    # NIC config - try CIM first            
                    $nic = $null            
                    try {                
                        $nic = Get-CimInstance -ComputerName $fqdn -ClassName Win32_NetworkAdapterConfiguration -Filter "IPEnabled=TRUE" -ErrorAction Stop            
                    } 
                    catch {                
                        try { 
                            $nic = Get-WmiObject -ComputerName $fqdn -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=TRUE" -ErrorAction SilentlyContinue 
                        } 
                        catch {}            
                    }
                    # forwarder + conditional forwarder info (cmdlet or WMI fallback)            
                    $fwdObj = Try-GetDnsServerForwardersAndConditional -Fqdn $fqdn
                    # Prepare safe strings (use $() inside hashtable assignments)            
                    $dnsRow = [PSCustomObject]@{                
                        Domain                = $domain                
                        DC                    = $fqdn                
                        DNSHostName           = $(if ($nic) { if ($nic.DNSHostName -is [System.Array]) { ($nic.DNSHostName -join ',') } else { $nic.DNSHostName } } else { $null })                
                        IPAddress             = $(if ($nic) { if ($nic.IPAddress -is [System.Array]) { ($nic.IPAddress -join ',') } else { $nic.IPAddress } } else { $null })                
                        DNSServerSearchOrder  = $(if ($nic) { if ($nic.DNSServerSearchOrder -is [System.Array]) { ($nic.DNSServerSearchOrder -join ',') } else { $nic.DNSServerSearchOrder } } else { $null })                
                        ServerForwarders      = $($fwdObj.Forwarders)                
                        ConditionalForwarders = $($fwdObj.ConditionalForwarders)            
                    }
                    $dnsReportRows += $dnsRow            
                    Start-Sleep -Milliseconds $ThrottleMs        
                }    
            }
            # Ensure consistent columns even if empty    
            $expectedDnsIpCols = @(        'Domain', 'DC', 'DNSHostName', 'IPAddress', 'DNSServerSearchOrder', 'ServerForwarders', 'ConditionalForwarders'    )
            if (-not $dnsReportRows -or $dnsReportRows.Count -eq 0) {        
                $emptyRow = [PSCustomObject]@{}        
                foreach ($c in $expectedDnsIpCols) { 
                    $emptyRow | Add-Member -NotePropertyName $c -NotePropertyValue '' 
                }        
                $dnsReportRows = @($emptyRow)    
            }
            # Enforce property order and export    
            Write-Host "Rows to export (DNS IP): $($dnsReportRows.Count)"    
            $dnsReportRows | Select-Object $expectedDnsIpCols | Export-Csv -Path $DnsIpCsv -NoTypeInformation -Encoding UTF8 -Force    
            Write-Host "Saved: $DnsIpCsv (rows: $($dnsReportRows.Count))"
        }
        # ---------------- Export-DNSServerZoneReport ----------------
        function Export-DNSServerZoneReport {    
            param([string[]]$DomainList)
            $zoneRows = @()
            foreach ($domain in $DomainList) {        
                Write-Host "Enumerating DCs for domain: $domain"        
                $dcs = Get-DomainControllersForDomain -DomainName $domain        
                if (-not $dcs -or $dcs.Count -eq 0) {            
                    Write-Warning "No domain controllers found for $domain. Skipping."            
                    continue        
                }
                foreach ($dc in $dcs) {            
                    $fqdn = if ($dc -match '\.') { $dc } else { "$dc.$domain" }            
                    Write-Host "Collecting zones from $fqdn"
                    $zones = Try-GetDnsServerZonesWithAging -Fqdn $fqdn            
                    if ($zones -and $zones.Count -gt 0) {                
                        foreach ($z in $zones) {                    
                            $masterServers = $($(if ($z.MasterServers) { 
                                        if ($z.MasterServers -is [System.Array]) { $z.MasterServers -join ',' } else { $z.MasterServers } 
                                    }
                                    else { $null }))                    
                            $notifyServers = $($(if ($z.NotifyServers) { if ($z.NotifyServers -is [System.Array]) { $z.NotifyServers -join ',' } else { $z.NotifyServers } } else { $null }))                    
                            $secondaryServers = $($(if ($z.SecondaryServers) { if ($z.SecondaryServers -is [System.Array]) { $z.SecondaryServers -join ',' } else { $z.SecondaryServers } } else { $null }))                    
                            $scavengeServers = $($(if ($z.ScavengeServers) { if ($z.ScavengeServers -is [System.Array]) { $z.ScavengeServers -join ',' } else { $z.ScavengeServers } } else { $null }))
                            $zoneRows += [PSCustomObject]@{                        
                                Domain                 = $domain                        
                                Server                 = $fqdn                        
                                ZoneName               = $z.ZoneName                        
                                ZoneType               = $z.ZoneType                        
                                DynamicUpdate          = $z.DynamicUpdate                        
                                IsAutoCreated          = $z.IsAutoCreated                        
                                IsDsIntegrated         = $z.IsDsIntegrated                        
                                IsReverseLookupZone    = $z.IsReverseLookupZone                        
                                ReplicationScope       = $z.ReplicationScope                        
                                DirectoryPartitionName = $z.DirectoryPartitionName                        
                                MasterServers          = $masterServers                        
                                NotifyServers          = $notifyServers                        
                                SecondaryServers       = $secondaryServers                        
                                AgingEnabled           = $z.AgingEnabled                        
                                NoRefreshInterval      = $z.NoRefreshInterval                        
                                RefreshInterval        = $z.RefreshInterval                        
                                ScavengeServers        = $scavengeServers                    
                            }                
                        }            
                    } 
                    else { Write-Verbose "No zones returned from $fqdn or retrieval failed." }
                    Start-Sleep -Milliseconds $ThrottleMs        
                }    
            }
            # Ensure consistent columns even if empty    
            $expectedZoneCols = @(        
                'Domain', 'Server', 'ZoneName', 'ZoneType', 'DynamicUpdate', 'IsAutoCreated', 'IsDsIntegrated', 'IsReverseLookupZone', 'ReplicationScope', 'DirectoryPartitionName', 'MasterServers', 'NotifyServers', 'SecondaryServers', 'AgingEnabled', 'NoRefreshInterval', 'RefreshInterval', 'ScavengeServers'    )
            if (-not $zoneRows -or $zoneRows.Count -eq 0) {        
                $emptyZone = [PSCustomObject]@{}        
                foreach ($c in $expectedZoneCols) { 
                    $emptyZone | Add-Member -NotePropertyName $c -NotePropertyValue '' 
                }        
                $zoneRows = @($emptyZone)    
            }
            # Enforce property order and export    
            Write-Host "Rows to export (Zones): $($zoneRows.Count)"    
            $zoneRows | Select-Object $expectedZoneCols | Export-Csv -Path $DnsZoneCsv -NoTypeInformation -Encoding UTF8 -Force    
            Write-Host "Saved: $DnsZoneCsv (rows: $($zoneRows.Count))"
        }
        # ---------------- Run collectors ----------------
        try { Export-DNSServerIPConfiguration -DomainList $Domains } 
        catch { Write-Warning "Export-DNSServerIPConfiguration failed: $($_.Exception.Message)" }
        try { Export-DNSServerZoneReport -DomainList $Domains } 
        catch { Write-Warning "Export-DNSServerZoneReport failed: $($_.Exception.Message)" }
        Write-Host "Done. Reports created (or blank templates) at:"Write-Host " - $DnsIpCsv"Write-Host " - $DnsZoneCsv"