<#
.SYNOPSIS
    Gathers the list of child domains in the AD forest.
.DESCRIPTION
    Connects to the AD forest, enumerates domains and child domains,
    and exports the details to a CSV file.
.NOTES
    Run with appropriate permissions on a domain-joined machine.
#>

# ---------- CONFIGURATION ----------
$OutputFile = "Z:\AD_Frst_ChildDmn_DC_FSMO_SitesSubnetsSitelnk_Trust_OU_DNS_AcntLockut_DFS_AllUsr_SrcAcnt\AD_Child_Domains_Inventory_$(Get-Date -Format 'yyyyMMdd_HHmm').csv"
#$Username = "MAT\azureuser"
$Username = "matpowershell2\azureuser"
$Password = "Mat@2025" | ConvertTo-SecureString -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential ($Username, $Password)

# ---------- SCRIPT START ----------
Write-Host "Connecting to AD forest and gathering child domain details..." -ForegroundColor Cyan

$Results = @()
$DomainControllers = @("mataddc2.mat.com","mataddc3.mat.com")

foreach ($DC in $DomainControllers) {
    try {
        Write-Host "`nProcessing domain controller: $DC" -ForegroundColor Yellow

        # Get forest information from current DC
        $Forest = Get-ADForest -Server $DC -Credential $Credential
        Write-Host "Connected to forest: $($Forest.Name)" -ForegroundColor Green
	Write-Host "Forest_domain $Forest.Domains"

        # Loop through each domain in the forest
        foreach ($Domain in $Forest.Domains) {
            Write-Host "Gathering information for domain: $DC" -ForegroundColor Cyan
            $DomainObj = Get-ADDomain -Server $DC -Credential $Credential

            $Results += [PSCustomObject]@{
                ForestName = $Forest.Name
                ParentDomain = $DomainObj.ParentDomain
                ChildDomain = $DomainObj.DNSRoot
                DomainSID = $DomainObj.DomainSID
                DomainMode = $DomainObj.DomainMode
                InfrastructureMaster = $DomainObj.InfrastructureMaster
                PDCEmulator = $DomainObj.PDCEmulator
                RIDMaster = $DomainObj.RIDMaster
            }
        }
    }
    catch {
        Write-Host "Failed to retrieve child domain details from $DC $_" -ForegroundColor Red
    }
}

# ---------- EXPORT RESULTS ----------
if ($Results.Count -gt 0) {
    $Results | Export-Csv -Path $OutputFile -NoTypeInformation
    Write-Host "`nChild domain details exported to $OutputFile" -ForegroundColor Green
} else {
    Write-Host "`nNo child domain details were retrieved." -ForegroundColor Red
}