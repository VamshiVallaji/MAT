﻿cls
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
Get-GPO -All | select DisplayName -ExpandProperty DisplayName > $network_drive\AD_GPO_List_in_Domain_Config_ADAudit\gpo_$timeStamp.txt
$gp = get-content $network_drive\AD_GPO_List_in_Domain_Config_ADAudit\gpo_$timeStamp.txt
"DisplayName`tOwner`tGpoStatus`tADComputerVersion`tSysVolComputerVersion`tADUserVersion`tSysvolUserVersion`tWmiFilter" > $network_drive\AD_GPO_List_in_Domain_Config_ADAudit\ListOfGPO_$timeStamp.csv
foreach($grppolicy in $gp)
{
Write-Host "Gathering details of $grppolicy policy"
#$gpos=Get-GPO -Name $grppolicy -Domain MAT.com  | select Displayname,Owner,GpoStatus,@{Label="ADComputerVersion";Expression={$_.computer.dsversion}},@{Label="SysVolComputerVersion";Expression={$_.computer.SysvolVersion}},@{Label="ADUserVersion";Expression={$_.user.dsversion}},@{Label="SysvolUserVersion";Expression={$_.user.SysvolVersion}},WmiFilter
$gpos=Get-GPO -Name $grppolicy | select Displayname,Owner,GpoStatus,@{Label="ADComputerVersion";Expression={$_.computer.dsversion}},@{Label="SysVolComputerVersion";Expression={$_.computer.SysvolVersion}},@{Label="ADUserVersion";Expression={$_.user.dsversion}},@{Label="SysvolUserVersion";Expression={$_.user.SysvolVersion}},WmiFilter
$gpos.DisplayName+"`t"+$gpos.Owner+"`t"+$gpos.GpoStatus+"`t"+$gpos.ADComputerVersion+"`t"+$gpos.SysVolComputerVersion+"`t"+$gpos.ADUserVersion+"`t"+$gpos.SysvolUserVersion+"`t"+$gpos.WmiFilter >> $network_drive\AD_GPO_List_in_Domain_Config_ADAudit\ListOfGPO_$timeStamp.csv
}