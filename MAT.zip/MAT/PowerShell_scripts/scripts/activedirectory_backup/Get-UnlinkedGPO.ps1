$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
Get-GPO -All | Sort-Object displayname | Where-Object { If ( $_ | Get-GPOReport -ReportType XML | Select-String -NotMatch "LinksTo" )
{
$_.DisplayName | Out-File "$network_drive\AD_GPO_List_in_Domain_Config_ADAudit\UnLinkedGPOS_$timeStamp.CSV" -Append
}}