﻿<# ========= Group-Based Licensing (GBL) inventory — non-interactive (cert auth) =========
    Outputs (CSV, UTF-8):
      1) GroupLicensing_Summary.csv -> one row per licensed group
      2) GroupLicensing_Details.csv -> one row per (group, SKU)
      3) GroupLicensing_Members.csv -> users that are members of licensed groups
    Requirements:
      - Microsoft.Graph PowerShell (Connect-MgGraph, Get-MgGroup, Get-MgSubscribedSku, Get-MgGroupMember)
      - App registration with app-only Graph permissions: 
          Organization.Read.All, Group.Read.All, User.Read.All (Application)
      - A certificate in CurrentUser\My (thumbprint below)
#>

# ====== INPUTS ======
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint


$OutDir = "C:\Reports\GBL"
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$csv1 = Join-Path $OutDir "GroupLicensing_Summary.csv"
$csv2 = Join-Path $OutDir "GroupLicensing_Details.csv"
$csv3 = Join-Path $OutDir "GroupLicensing_Members.csv"

# ====== Connect (non-interactive, certificate) ======
Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

# Build SKU map (SkuId -> SkuPartNumber)
$skuMap = @{}
try {
    $subSkus = Get-MgSubscribedSku -ErrorAction Stop
    foreach ($s in $subSkus) { $skuMap[$s.SkuId] = $s.SkuPartNumber }
} catch {
    Write-Warning "Could not retrieve tenant subscribed SKUs. ($($_.Exception.Message))"
}

# ====== Get groups with assignedLicenses ======
# Need AssignedLicenses in the projection; consistency level enables $count and reliable filtering.
$allGroups = Get-MgGroup -All -Property "Id,DisplayName,AssignedLicenses" `
              -ConsistencyLevel eventual -CountVariable _ | Where-Object {
                  $_.AssignedLicenses -and $_.AssignedLicenses.Count -gt 0
              }

if (-not $allGroups -or $allGroups.Count -eq 0) {
    Write-Warning "No groups with assignedLicenses found. (Your tenant may not use Group-Based Licensing or has no SKUs.)"
    # write empty CSVs with headers so files aren’t blank
    [pscustomobject]@{GroupName='';GroupId='';SkuPartNumbers='';SkuIds='';SkuCount=0} |
        Export-Csv -Path $csv1 -NoTypeInformation -Encoding UTF8
    [pscustomobject]@{GroupName='';GroupId='';SkuId='';SkuPartNumber=''} |
        Export-Csv -Path $csv2 -NoTypeInformation -Encoding UTF8
    [pscustomobject]@{GroupName='';GroupId='';UserDisplayName='';UserUPN='';UserId=''} |
        Export-Csv -Path $csv3 -NoTypeInformation -Encoding UTF8
    Disconnect-MgGraph | Out-Null
    return
}

# ----- Summaries -----
$summary = foreach ($g in $allGroups) {
    $skuIds = $g.AssignedLicenses | ForEach-Object { $_.SkuId } | Where-Object { $_ } | Select-Object -Unique
    $skuNames = $skuIds | ForEach-Object { if ($skuMap.ContainsKey($_)) { $skuMap[$_] } else { $_ } }
    [pscustomobject]@{
        GroupName = $g.DisplayName
        GroupId = $g.Id
        SkuPartNumbers = ($skuNames -join ',')
        SkuIds = ($skuIds -join ',')
        SkuCount = $skuIds.Count
    }
}

$details = foreach ($g in $allGroups) {
    foreach ($lic in $g.AssignedLicenses) {
        $skuId = $lic.SkuId
        $name = if ($skuMap.ContainsKey($skuId)) { $skuMap[$skuId] } else { $skuId }
        [pscustomobject]@{
            GroupName = $g.DisplayName
            GroupId = $g.Id
            SkuId = $skuId
            SkuPartNumber = $name
        }
    }
}

# ----- Members of licensed groups (users only) -----
$members = foreach ($g in $allGroups) {
    try {
        # Returns directoryObjects; we only keep users
        $objs = Get-MgGroupMember -GroupId $g.Id -All -ErrorAction Stop
        foreach ($o in $objs) {
            if ($o.AdditionalProperties.'@odata.type' -eq '#microsoft.graph.user') {
                [pscustomobject]@{
                    GroupName = $g.DisplayName
                    GroupId = $g.Id
                    UserDisplayName = $o.AdditionalProperties.displayName
                    UserUPN = $o.AdditionalProperties.userPrincipalName
                    UserId = $o.Id
                }
            }
        }
    } catch {
        Write-Warning "Could not list members for group '$($g.DisplayName)': $($_.Exception.Message)"
    }
}

# ====== Export ======
$summary | Sort-Object GroupName | Export-Csv -Path $csv1 -NoTypeInformation -Encoding UTF8
$details | Sort-Object GroupName, SkuPartNumber | Export-Csv -Path $csv2 -NoTypeInformation -Encoding UTF8
$members | Sort-Object GroupName, UserUPN | Export-Csv -Path $csv3 -NoTypeInformation -Encoding UTF8

Write-Host "Group licensing summary : $csv1" -ForegroundColor Green
Write-Host "Group licensing details : $csv2" -ForegroundColor Green
Write-Host "Licensed group members : $csv3" -ForegroundColor Green

Disconnect-MgGraph | Out-Null