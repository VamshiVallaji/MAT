#Domain Controllers
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$Forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
$Forest.Sites | % { $_.Servers } -ErrorAction SilentlyContinue | Select Domain, Name, IPAddress, OSVersion, SiteName | export-csv Z:\AD_PasswordPolicy\DomainControllers_$timeStamp.csv -notypeinfo