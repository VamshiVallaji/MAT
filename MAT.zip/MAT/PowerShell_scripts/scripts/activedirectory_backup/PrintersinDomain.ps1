﻿<#
.SYNOPSIS
  Export printers for on-prem AD environment (AD printQueue or discover print servers).

.DESCRIPTION
  1) Try AD Configuration partition for objectClass=printQueue.
  2) If none, enumerate domain computers and test remote 'Spooler' service; only query hosts with spooler.
  3) Query Win32_Printer on print hosts and export to CSV.
  4) PowerShell 5.1 compatible. Requires ActiveDirectory module for AD path but will continue if module unavailable.

.NOTES
  - Running the host-discovery step in large domains may take a long time.
  - Run under account with domain read and remote WMI access.

#>

param(
    [int]$MaxComputerChecks = 50, # throttle: how many computers to attempt (0 = no limit)
    [int]$WmiTimeoutSeconds = 10 # WMI call timeout per host
)

Set-StrictMode -Version Latest
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$OutFolder = "$network_drive\AD_PrintersinDomain"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$outCsv = Join-Path $OutFolder "Printers_$timeStamp.csv"

function SafeGet($obj, $name) {
    if ($null -eq $obj) { return $null }
    $p = $obj.PSObject.Properties[$name]
    if ($p -ne $null) { return $p.Value }
    try {
        if ($obj -is [System.Collections.IDictionary] -and $obj.Contains($name)) { return $obj[$name] }
    } catch {}
    return $null
}

$rows = @()

# === 1) Try AD printQueue objects ===
$adSucceeded = $false
try {
    Import-Module ActiveDirectory -ErrorAction Stop
    Write-Host "ActiveDirectory module available. Querying Configuration partition for printQueue objects..." -ForegroundColor Cyan

    $root = Get-ADRootDSE -ErrorAction Stop
    $configNC = $root.ConfigurationNamingContext

    # Attempt to query the print queues container; if not present, search the whole config for objectClass=printQueue
    try {
        $searchBase = "CN=Print Queues,CN=Services,$configNC"
        $pq = Get-ADObject -SearchBase $searchBase -LDAPFilter '(objectClass=printQueue)' -Properties name,printShareName,serverName,location,description,whenCreated,whenChanged,distinguishedName -ErrorAction Stop
    } catch {
        $pq = Get-ADObject -SearchBase $configNC -LDAPFilter '(objectClass=printQueue)' -Properties name,printShareName,serverName,location,description,whenCreated,whenChanged,distinguishedName -ErrorAction Stop
    }

    if ($pq -and $pq.Count -gt 0) {
        Write-Host ("Found {0} AD printQueue objects." -f $pq.Count) -ForegroundColor Green
        foreach ($p in $pq) {
            $rows += [PSCustomObject]@{
                Source = 'AD-printQueue'
                PrinterName = SafeGet $p 'name'
                PrintShareName = SafeGet $p 'printShareName'
                ServerName = SafeGet $p 'serverName'
                Location = SafeGet $p 'location'
                Description = SafeGet $p 'description'
                WhenCreated = SafeGet $p 'whenCreated'
                WhenChanged = SafeGet $p 'whenChanged'
                DistinguishedName = SafeGet $p 'distinguishedName'
                ComputerQueried = $null
                PortName = $null
                DriverName = $null
                Shared = $null
                Default = $null
            }
        }
        $adSucceeded = $true
    } else {
        Write-Host "No AD printQueue objects found." -ForegroundColor Yellow
    }
} catch {
    Write-Host "AD module/query failed or not available: $($_.Exception.Message)" -ForegroundColor Yellow
}

# If AD gave results, we can still optionally proceed to enumerate print servers if you want; currently we stop here.
if ($adSucceeded -and $rows.Count -gt 0) {
    Write-Host "AD printQueue results collected. Exporting CSV..." -ForegroundColor Green
    $rows | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Force
    Write-Host ("Export complete: {0} rows -> {1}" -f $rows.Count, $outCsv) -ForegroundColor Green
    exit 0
}

# === 2) Discover candidate print servers by enumerating domain computers and checking for Spooler ===
Write-Host "Falling back to discovery: enumerating domain computers and checking for Print Spooler service..." -ForegroundColor Cyan

try {
    # Need ActiveDirectory to enumerate computers; if not available, attempt Net/LDAP fallback (but AD module is assumed in on-prem management).
    Import-Module ActiveDirectory -ErrorAction Stop
    Write-Host "Fetching computer list from AD..." -ForegroundColor Gray
    $computers = Get-ADComputer -Filter * -Properties Name,OperatingSystem | Select-Object -ExpandProperty Name
} catch {
    Write-Host "Unable to use ActiveDirectory module to list computers: $($_.Exception.Message)" -ForegroundColor Red
    # fallback: try DNS/NetBIOS approach? We'll exit with header-only CSV to avoid blind wide scan.
    Write-Host "Cannot discover domain computers. Creating header-only CSV at $outCsv" -ForegroundColor Yellow
    "" | Select-Object Source,PrinterName,PrintShareName,ServerName,Location,Description,WhenCreated,WhenChanged,DistinguishedName,ComputerQueried,PortName,DriverName,Shared,Default |
        Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Force
    Write-Host "Header-only CSV created: $outCsv" -ForegroundColor Green
    exit 0
}

# Option: limit amount if MaxComputerChecks > 0
if ($MaxComputerChecks -gt 0 -and $computers.Count -gt $MaxComputerChecks) {
    Write-Host ("Domain computer list is large ({0}). Limiting to first {1} hosts for spooler checks. Adjust -MaxComputerChecks to increase." -f $computers.Count, $MaxComputerChecks) -ForegroundColor Yellow
    $computers = $computers[0..($MaxComputerChecks-1)]
}

$printHosts = @()
foreach ($c in $computers) {
    try {
        # check remote spooler service via WMI quick call (may be blocked by firewall). Use a short timeout by running a job with timeout.
        $svc = $null
        try {
            $svc = Get-WmiObject -Class Win32_Service -ComputerName $c -Filter "Name='Spooler'" -ErrorAction Stop
        } catch {
            # unreachable or access denied
            $svc = $null
        }
        if ($svc -and $svc.State -ne $null) {
            # spooler exists - consider this a candidate print host
            Write-Host ("Spooler found on {0} (state={1})" -f $c, $svc.State) -ForegroundColor DarkGreen
            $printHosts += $c
        } else {
            # no spooler or access denied - skip
            # Write-Host ("No Spooler or inaccessible on $c") -ForegroundColor DarkGray
        }
    } catch {
        # swallow and continue
    }
}

if (-not $printHosts -or $printHosts.Count -eq 0) {
    Write-Host "No print hosts discovered (Spooler) among checked computers. Creating header-only CSV." -ForegroundColor Yellow
    "" | Select-Object Source,PrinterName,PrintShareName,ServerName,Location,Description,WhenCreated,WhenChanged,DistinguishedName,ComputerQueried,PortName,DriverName,Shared,Default |
        Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Force
    Write-Host "Header-only CSV created: $outCsv" -ForegroundColor Green
    exit 0
}

Write-Host ("Discovered {0} candidate print hosts. Querying printers (Win32_Printer)..." -f $printHosts.Count) -ForegroundColor Cyan

foreach ($sv in $printHosts) {
    try {
        $printers = Get-WmiObject -Class Win32_Printer -ComputerName $sv -ErrorAction Stop
        foreach ($pp in $printers) {
            $rows += [PSCustomObject]@{
                Source = 'WMI-Win32_Printer'
                PrinterName = SafeGet $pp 'Name'
                PrintShareName = SafeGet $pp 'ShareName'
                ServerName = $sv
                Location = SafeGet $pp 'Location'
                Description = SafeGet $pp 'Comment'
                WhenCreated = $null
                WhenChanged = $null
                DistinguishedName = $null
                ComputerQueried = $sv
                PortName = SafeGet $pp 'PortName'
                DriverName = SafeGet $pp 'DriverName'
                Shared = SafeGet $pp 'Shared'
                Default = SafeGet $pp 'Default'
            }
        }
    } catch {
        Write-Host ("Failed to query printers on {0}: {1}" -f $sv, $_.Exception.Message) -ForegroundColor Yellow
    }
}

# Export results
if ($rows -and $rows.Count -gt 0) {
    try {
        $rows | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Force
        Write-Host ("Export complete: {0} rows -> {1}" -f $rows.Count, $outCsv) -ForegroundColor Green
    } catch {
        Write-Host "Failed to write CSV: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "No printers collected. Creating header-only CSV at $outCsv" -ForegroundColor Yellow
    "" | Select-Object Source,PrinterName,PrintShareName,ServerName,Location,Description,WhenCreated,WhenChanged,DistinguishedName,ComputerQueried,PortName,DriverName,Shared,Default |
        Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Force
    Write-Host "Header-only CSV created: $outCsv" -ForegroundColor Green
}

Write-Host "Done." -ForegroundColor Cyan