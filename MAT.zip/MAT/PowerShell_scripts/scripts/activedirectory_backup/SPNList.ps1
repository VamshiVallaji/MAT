﻿<#
.SYNOPSIS
  Inventory of SPNs (Service Principal Names) in on-prem Active Directory.
  Infrastructure: On-prem AD

.DESCRIPTION
  - Uses ActiveDirectory module.
  - Enumerates all objects with SPNs set.
  - Exports to CSV with clean headers.

.NOTES
  Requires RSAT / AD DS PowerShell module installed.
  Run with domain account that can read AD.
#>
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$OutFolder = "$network_drive\AD_SPNList"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$FileName = "SPN_Report_$timeStamp.csv"


# Ensure AD module
try {
    Import-Module ActiveDirectory -ErrorAction Stop
} catch {
    Write-Error "ActiveDirectory module not found. Install RSAT or AD DS tools."
    throw
}

# Create folder if missing
if (-not (Test-Path -Path $OutFolder)) {
    New-Item -ItemType Directory -Path $OutFolder | Out-Null
}

$outCsv = Join-Path $OutFolder $FileName

Write-Host "Fetching objects with SPNs from Active Directory..." -ForegroundColor Cyan

# Get all objects that have SPNs
$objects = Get-ADObject -LDAPFilter "(servicePrincipalName=*)" -Properties servicePrincipalName,samAccountName,objectClass,distinguishedName

$report = @()

foreach ($obj in $objects) {
    foreach ($spn in $obj.servicePrincipalName) {
        $report += [PSCustomObject]@{
            SamAccountName = $obj.samAccountName
            ObjectClass = $obj.objectClass
            DistinguishedName = $obj.distinguishedName
            SPN = $spn
        }
    }
}

# Export with header only if empty
$headers = "SamAccountName","ObjectClass","DistinguishedName","SPN"

if ($report.Count -eq 0) {
    Write-Host "No SPNs found. Creating header-only CSV at: $outCsv" -ForegroundColor Yellow
    "" | Select-Object $headers | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
} else {
    $report | Select-Object $headers | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
    Write-Host "Exported $($report.Count) SPN entries to $outCsv" -ForegroundColor Green
}