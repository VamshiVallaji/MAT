﻿<#
.SYNOPSIS
  Export AD user RDS (Terminal Services) and HomeDrive/HomeDirectory info to CSV (PowerShell 5.1).

.DESCRIPTION
  - Requires ActiveDirectory module (RSAT or on a Domain Controller).
  - Collects msTSHomeDirectory, msTSProfilePath, msTSAllowLogon, homeDirectory, homeDrive, sAMAccountName, userPrincipalName, enabled, distinguishedName, whenCreated.
  - Writes CSV to specified folder; header-only CSV created if no rows.

.PARAMETER OutFolder Destination folder (default .\AD_User_RDS_HomeDrive_<timestamp>)
.PARAMETER Filter Optional AD filter (default 'enabled -eq $true' to list enabled users). Use LDAP filter if you prefer.

.EXAMPLE
  .\Export-AD-User-RDS-HomeDrive.ps1 -OutFolder C:\Reports\AD
#>

param(
  [string]$Filter = 'enabled -eq $true' # a PowerShell filter expression string for Get-ADUser -Filter
)

$OutFolder = "Z:\AD_UserswithHomeDrive_RDS"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
Set-StrictMode -Version Latest
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Ensure ActiveDirectory module is available
if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) {
  Write-Host "ActiveDirectory module not found. You must run this on a machine with RSAT (Active Directory) installed or on a Domain Controller." -ForegroundColor Yellow
  Write-Host "On Windows 10/11 install RSAT > 'Active Directory Domain Services and Lightweight Directory Services Tools' or run script on a DC." -ForegroundColor Cyan
  Exit 1
}
Import-Module ActiveDirectory -ErrorAction Stop

# Create output folder
try {
  if (-not (Test-Path -Path $OutFolder)) {
    New-Item -ItemType Directory -Path $OutFolder -Force | Out-Null
  }
} catch {
  ErrorAndExit "Failed to create/access OutFolder '$OutFolder' : $($_.Exception.Message)"
}

$outCsv = Join-Path $OutFolder "AD_Users_RDS_HomeDrive_$timeStamp.csv"

# Attributes to request
$props = @(
  'sAMAccountName',
  'userPrincipalName',
  'displayName',
  'enabled',
  'distinguishedName',
  'whenCreated',
  'msTSHomeDirectory',
  'msTSProfilePath',
  'msTSHomeDrive',
  'msTSAllowLogon',
  'homeDirectory',
  'homeDrive'
)

Write-Host "Querying AD users (this may take a while)..." -ForegroundColor Cyan

# Query users - use Filter as expression string. If user wants LDAP style, change accordingly.
try {
  # Validate filter: attempt one quick call
  $test = Get-ADUser -Filter $Filter -ResultSetSize 1 -Properties $props -ErrorAction Stop
} catch {
  ErrorAndExit "Get-ADUser test failed with filter '$Filter' : $($_.Exception.Message). Adjust filter or run with default filter 'enabled -eq \$true'."
}

# Retrieve all matching users in pages
try {
  $users = Get-ADUser -Filter $Filter -Properties $props -ResultSetSize $null -ErrorAction Stop
} catch {
  ErrorAndExit "Failed to query AD users: $($_.Exception.Message)"
}

# Build output list
$rows = @()
if ($users -and $users.Count -gt 0) {
  foreach ($u in $users) {
    $rows += [PSCustomObject]@{
      sAMAccountName = ($u.sAMAccountName -as [string])
      UserPrincipalName = ($u.userPrincipalName -as [string])
      DisplayName = ($u.displayName -as [string])
      Enabled = $u.Enabled
      DistinguishedName = ($u.DistinguishedName -as [string])
      WhenCreated = ($u.whenCreated -as [string])
      msTSHomeDirectory = ($u.msTSHomeDirectory -as [string]) # RDS home directory (rare)
      msTSProfilePath = ($u.msTSProfilePath -as [string]) # RDS profile path
      msTSHomeDrive = ($u.msTSHomeDrive -as [string]) # RDS home drive letter
      msTSAllowLogon = ($u.msTSAllowLogon -as [string]) # RDS allow logon flag
      HomeDirectory = ($u.homeDirectory -as [string]) # AD home directory UNC
      HomeDrive = ($u.homeDrive -as [string]) # Home drive letter
    }
  }
}

# Export (header-only when no rows)
if ($rows.Count -eq 0) {
  "" | Select-Object sAMAccountName,UserPrincipalName,DisplayName,Enabled,DistinguishedName,WhenCreated,msTSHomeDirectory,msTSProfilePath,msTSHomeDrive,msTSAllowLogon,HomeDirectory,HomeDrive |
    Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
  Write-Host "No users returned by filter. Header-only CSV created at $outCsv" -ForegroundColor Yellow
} else {
  $rows | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
  Write-Host ("Export complete: {0} users -> {1}" -f $rows.Count, $outCsv) -ForegroundColor Green
}

# End