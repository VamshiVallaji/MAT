﻿<#
.SYNOPSIS Query w32tm /query /status on all DCs.
.PSVersion 5.1
#>
$OutFolder = "Z:\AD_WindowsTimeConfiguration"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$outCsv = Join-Path $OutFolder "DCs_TimeStatus_$timeStamp.csv"

Import-Module ActiveDirectory -ErrorAction Stop
$dcs = Get-ADDomainController -Filter * -ErrorAction Stop

"" | Select-Object DC,StatusText | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8

foreach ($dc in $dcs) {
  try {
    $txt = Invoke-Command -ComputerName $dc.HostName -ScriptBlock { w32tm /query /status 2>&1 } -ErrorAction Stop
    $row = [PSCustomObject]@{ DC = $dc.HostName; StatusText = ($txt -join "`n") }
    $row | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Append
  } catch {
    $row = [PSCustomObject]@{ DC = $dc.HostName; StatusText = "ERROR: " + $_.Exception.Message }
    $row | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8 -Append
  }
}
Write-Host ("DC time status written to: " + $outCsv) -ForegroundColor Green
