﻿<#
.SYNOPSIS Query PDC Emulator time configuration.
.PSVersion 5.1
#>
$OutFolder = "Z:\AD_WindowsTimeConfiguration"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$outCsv = Join-Path $OutFolder "PDC_TimeConfig_$timeStamp.csv"

if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) { Write-Host "ActiveDirectory module not found." -ForegroundColor Red; return }
Import-Module ActiveDirectory -ErrorAction Stop

try { $pdc = (Get-ADDomain).PDCEmulator } catch { Write-Host "Failed to find PDC: " + $_.Exception.Message -ForegroundColor Red; $pdc = $null }

if ($pdc) {
  try {
    $res = Invoke-Command -ComputerName $pdc -ScriptBlock {
      $s1 = w32tm /query /status 2>&1
      $s2 = w32tm /query /configuration 2>&1
      @{ Status = $s1 -join "`n"; Config = $s2 -join "`n" }
    } -ErrorAction Stop
    $row = [PSCustomObject]@{ PDC = $pdc; Status = $res.Status; Configuration = $res.Config }
    $row | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
    Write-Host ("PDC time config saved to: " + $outCsv) -ForegroundColor Green
  } catch {
    Write-Host ("Failed to query PDC: " + $_.Exception.Message) -ForegroundColor Yellow
    "" | Select-Object PDC,Status,Configuration | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
  }
} else {
  "" | Select-Object PDC,Status,Configuration | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
  Write-Host "PDC not found; header-only CSV created." -ForegroundColor Yellow
}
