$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name
Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization -ShowBanner:$false



# Connect to Exchange Online

$reportPath = "$network_drive\Exchange\CalendarConfig\CalendarConfiguration_Report_$timestamp.csv"
$Result = @()

# Get all resource mailboxes (Room and Equipment)
$resourceMailboxes = Get-Mailbox -RecipientTypeDetails RoomMailbox, EquipmentMailbox -ResultSize Unlimited

foreach ($mailbox in $resourceMailboxes) {
    try {
        $calendarConfig = Get-CalendarProcessing -Identity $mailbox.Identity

        $Result += [PSCustomObject]@{
            AutomateProcessing              = $calendarConfig.AutomateProcessing
            AllowConflicts                  = $calendarConfig.AllowConflicts
            BookingWindowInDays             = $calendarConfig.BookingWindowInDays
            EnforceCapacity                 = $calendarConfig.EnforceCapacity
            MaximumDurationInMinutes        = $calendarConfig.MaximumDurationInMinutes
            AllowRecurringMeetings          = $calendarConfig.AllowRecurringMeetings
            ScheduleOnlyDuringWorkHours     = $calendarConfig.ScheduleOnlyDuringWorkHours
            ConflictPercentageAllowed       = $calendarConfig.ConflictPercentageAllowed
            MaximumConflictInstances        = $calendarConfig.MaximumConflictInstances
            AllRequestOutOfPolicy           = $calendarConfig.AllRequestOutOfPolicy
            AllBookInPolicy                 = ($calendarConfig.AllBookInPolicy -join "; ")
            AllRequestInPolicy              = ($calendarConfig.AllRequestInPolicy -join "; ")
            BookInPolicy                    = ($calendarConfig.BookInPolicy -join "; ")
            RequestInPolicy                 = ($calendarConfig.RequestInPolicy -join "; ")
            RequestOutOfPolicy              = ($calendarConfig.RequestOutOfPolicy -join "; ")
            ResourceDelegates               = ($calendarConfig.ResourceDelegates -join "; ")
            DeleteSubject                   = $calendarConfig.DeleteSubject
            AddOrganizerToSubject           = $calendarConfig.AddOrganizerToSubject
            DeleteComments                  = $calendarConfig.DeleteComments
            RemovePrivateProperty           = $calendarConfig.RemovePrivateProperty
            AddAdditionalResponse           = $calendarConfig.AddAdditionalResponse
            AdditionalResponse              = $calendarConfig.AdditionalResponse
            OrganizerInfo                   = $calendarConfig.OrganizerInfo
            AllowTentativeBookings          = $calendarConfig.AllowTentativeBookings
            EnableResponseDetails           = $calendarConfig.EnableResponseDetails
            ForwardRequestsToDelegates      = $calendarConfig.ForwardRequestsToDelegates
            TentativePendingApproval        = $calendarConfig.TentativePendingApproval
            ProcessExternalMeetingMessages  = $calendarConfig.ProcessExternalMeetingMessages
        }
    } catch {
        Write-Warning "Failed to process calendar config for: $($mailbox.DisplayName). Error: $_"
    }
}

# Export to CSV
$Result | Export-Csv -Path $reportPath -NoTypeInformation




