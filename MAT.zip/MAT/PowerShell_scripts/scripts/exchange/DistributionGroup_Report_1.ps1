# DG_Report_AppOnly.ps1
# -------------------------------------------------
# Export detailed Distribution Group report (Non-Interactive App-Only)
# Includes MemberOf column showing transitive parent DLs
# -------------------------------------------------

# ------------------- CONFIG -------------------

$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$OutputCSV = "Z:\Exchange\DistributionGroup\DistributionGroup_$timeStamp.csv"

# optional: enable caching of parent map to avoid repeated expensive calls
$UseParentMapCache = $false
$ParentMapCachePath = "Z:\Exchange\DistributionGroup\ParentMapCache.json"

# read config from network drive
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json

$TenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint

# ------------------- CONNECT -------------------

# Import Exchange Online module
#Import-Module ExchangeOnlineManagement -Force

# Connect to MS Graph to get tenant's initial domain for Exchange connection param
Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

# Connect to Exchange Online using app-only (certificate)
Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization -ShowBanner:$false

# ------------------- FETCH DISTRIBUTION GROUPS -------------------

Write-Host "Fetching all distribution groups..."
$DGs = Get-DistributionGroup -ResultSize Unlimited

# fast lookup map by Identity string
$dgByIdentity = @{}
foreach ($d in $DGs) { $dgByIdentity[$d.Identity.ToString()] = $d }

# ------------------- BUILD PARENT MAP (child -> direct parents) -------------------

if ($UseParentMapCache -and (Test-Path $ParentMapCachePath)) {
    Write-Host "Loading parent map from cache: $ParentMapCachePath"
    $parentMap = Get-Content $ParentMapCachePath | ConvertFrom-Json
    # convert to hashtable keyed by childKey -> array
    $tmp = @{}
    foreach ($k in $parentMap.PSObject.Properties.Name) {
        $tmp[$k] = @($parentMap.$k)
    }
    $parentMap = $tmp
} else {
    Write-Host "Building parent membership map for distribution groups (this may take time in large tenants)..."
    $parentMap = @{} # key = child identity string, value = list of parent display names

    foreach ($parent in $DGs) {
        try {
            $members = Get-DistributionGroupMember -Identity $parent.Identity -ResultSize Unlimited -ErrorAction Stop
        } catch {
            Write-Verbose "Failed to enumerate members of $($parent.Identity): $($_.Exception.Message)"
            # throttle a bit on failures
            Start-Sleep -Milliseconds 150
            continue
        }

        foreach ($m in $members) {
            # Only record if the member is itself a group (distribution/security group)
            if ($m.RecipientType -like "*Group*" -or $m.RecipientTypeDetails -like "*Group*") {
                $childKey = $m.Identity.ToString()
                if (-not $parentMap.ContainsKey($childKey)) { $parentMap[$childKey] = @() }
                $parentMap[$childKey] += $parent.DisplayName
            }
        }

        # small throttle to reduce throttling risk on very large tenants
        Start-Sleep -Milliseconds 100
    }

    # Remove duplicates in each parent's list
    #foreach ($k in $parentMap.Keys) { $parentMap[$k] = $parentMap[$k] | Select-Object -Unique }
$keysSnapshot = $parentMap.Keys | ForEach-Object {$_} 
foreach ($k in $keysSnapshot) { $parentMap[$k] = ($parentMap[$k] | Select-Object -Unique) }

    if ($UseParentMapCache) {
        # Save cache (serialize)
        $json = $parentMap | ConvertTo-Json -Depth 5
        $json | Out-File -FilePath $ParentMapCachePath -Encoding UTF8
        Write-Host "Parent map cached to $ParentMapCachePath"
    }

    Write-Host "Parent map built. Found $($parentMap.Keys.Count) child group entries with parents."
}

# ------------------- HELPER: TRANSITIVE PARENT COLLECTION -------------------

function Get-AllParentDLs {
    param(
        [Parameter(Mandatory)][string]$childKey,
        [Parameter(Mandatory)][hashtable]$parentMap,
        [Parameter(Mandatory)][hashtable]$dgByIdentity
    )

$seenHash = @{}
$result = @()
$stack = New-Object System.Collections.Stack

    if ($parentMap.ContainsKey($childKey)) {
        foreach ($p in $parentMap[$childKey]) { $stack.Push($p) }
    }

    while ($stack.Count -gt 0) {
        $cur = $stack.Pop()
        if (-not $seenHash.ContainsKey($cur)) {
$seenHash[$cur] = $true
$result += $cur
            # find identity keys for this parent display name (rare duplicates may exist)
            $parentObjs = $dgByIdentity.Values | Where-Object { $_.DisplayName -eq $cur }
            foreach ($po in $parentObjs) {
                $poKey = $po.Identity.ToString()
                if ($parentMap.ContainsKey($poKey)) {
                    foreach ($pp in $parentMap[$poKey]) { $stack.Push($pp) }
                }
            }
        }
    }

    return $result
}

# ------------------- BUILD REPORT -------------------

Write-Host "Building report rows for $($DGs.Count) distribution groups..."
$Report = @()

foreach ($DG in $DGs) {

    # Members
    try {
        $Members = Get-DistributionGroupMember -Identity $DG.Identity -ResultSize Unlimited -ErrorAction Stop
    } catch {
        $Members = @()
    }
    $MemberCount = $Members.Count
    $MemberNames = ($Members | ForEach-Object {
        # prefer readable address if present
        if ($_.PrimarySmtpAddress) { $_.PrimarySmtpAddress.ToString() } else { $_.Name }
    }) -join "; "

    # Nested group info (direct child groups contained in this DG)
    $NestedGroups = $Members | Where-Object {$_.RecipientTypeDetails -match "MailUniversalDistributionGroup|MailUniversalSecurityGroup"}
    $NestedStatus = if ($NestedGroups.Count -gt 0) {"Yes"} else {"No"}
    $NestingType = if ($NestedGroups.Count -gt 0) {"Contains Nested DG"} else {"None"}

    # ManagedBy
    $ManagedByUsers = ($DG.ManagedBy | ForEach-Object {
        if ($_.Name) { $_.Name } else { $_.ToString() }
    }) -join "; "

    # AcceptMessagesOnlyFrom
    $OnlyFrom = ($DG.AcceptMessagesOnlyFrom | ForEach-Object { if ($_.Name) { $_.Name } else { $_.ToString() } }) -join "; "

    # AcceptMessagesOnlyFromDLMembers
    $OnlyFromDL = ($DG.AcceptMessagesOnlyFromDLMembers | ForEach-Object { if ($_.Name) { $_.Name } else { $_.ToString() } }) -join "; "

    # MemberOf (transitive parent DLs)
    $dgKey = $DG.Identity.ToString()
    $ParentGroupsDirect = if ($parentMap.ContainsKey($dgKey)) { $parentMap[$dgKey] } else { @() }
    $allParents = @()
    if ($ParentGroupsDirect.Count -gt 0) {
        $allParents = Get-AllParentDLs -childKey $dgKey -parentMap $parentMap -dgByIdentity $dgByIdentity
        # include direct parents as well (Get-AllParentDLs returns ancestry found via parentMap; ensure direct parents included)
        $allParents = ($allParents + $ParentGroupsDirect) | Sort-Object -Unique
    }
#    $ParentGroups = if ($allParents.Count -gt 0) { $allParents -join '; ' } elseif ($ParentGroupsDirect.Count -gt 0) { $ParentGroupsDirect -join '; ' } else { '' }
$ParentGroups = if ($allParents.Count -gt 0) { $allParents -join '; ' } else {' '}
    # Assemble row
    $Report += [PSCustomObject]@{
        Identity = $DG.Identity
        Group = $DG.DisplayName
        PrimarySmtpAddress = $DG.PrimarySmtpAddress
        SamAccountName = $DG.SamAccountName
        RequireSenderAuthenticationEnabled= $DG.RequireSenderAuthenticationEnabled
        ManagedBy = $ManagedByUsers
        MemberOf = $ParentGroups
        HiddenFromAddressListsEnabled = $DG.HiddenFromAddressListsEnabled
        WhenCreated = $DG.WhenCreated
        WhenChanged = $DG.WhenChanged
        OrganizationalUnit = $DG.OrganizationalUnit
        RecipientType = $DG.RecipientType
        RecipientTypeDetails = $DG.RecipientTypeDetails
        AcceptMessagesOnlyFrom = $OnlyFrom
        AcceptMessagesOnlyFromDLMembers = $OnlyFromDL
        MemberOfCount = ($DG.MemberOf).Count
        "Copy of MemberOf" = $ParentGroups
        GroupType = $DG.GroupType
        "IF Nested?" = $NestedStatus
        "Nesting Type" = $NestingType
        "Is ParentGroup Child?" = "N/A"
        "Migration Status" = "N/A"
        "Reason" = "N/A"
    }

} # foreach DG

# ------------------- EXPORT -------------------

Write-Host "Exporting CSV to $OutputCSV ..."
$Report | Export-Csv -Path $OutputCSV -NoTypeInformation -Encoding UTF8 -Force
Write-Host "Distribution Group report exported to $OutputCSV"

# ------------------- CLEANUP -------------------

try { Disconnect-MgGraph -ErrorAction SilentlyContinue } catch {}
