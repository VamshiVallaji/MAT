$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")

$OutputPath = "Z:\Exchange\Mailbox_details\ExchangeMailboxInventory_$timeStamp.csv"

$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" |
                 Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json

$TenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint

# --- Connect (NON-INTERACTIVE / CERT) ---
Write-Host "Connecting to Microsoft Graph (app-only) ..." -ForegroundColor Cyan
Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

Write-Host "Connecting to Exchange Online (app-only) ..." -ForegroundColor Cyan

Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization -ShowBanner:$false
#Connect-ExchangeOnline -AppId $ClientId -CertificateThumbprint $Thumbprint -Organization $Organization -ShowBanner:$false

try {
  # Property list requested (exact column order):
  $Columns = @(
    'PSComputerName','RunspaceId','PSShowComputerName','Database','MailboxProvisioningConstraint','MessageCopyForSentAsEnabled','MessageCopyForSendOnBehalfEnabled','MailboxProvisioningPreferences','UseDatabaseRetentionDefaults','RetainDeletedItemsUntilBackup','DeliverToMailboxAndForward','IsExcludedFromServingHierarchy','IsHierarchyReady','LitigationHoldEnabled','SingleItemRecoveryEnabled','RetentionHoldEnabled','EndDateForRetentionHold','StartDateForRetentionHold','RetentionComment','RetentionUrl','LitigationHoldDate','LitigationHoldOwner','LitigationHoldDuration','ManagedFolderMailboxPolicy','RetentionPolicy','AddressBookPolicy','CalendarRepairDisabled','ExchangeGuid','MailboxContainerGuid','UnifiedMailbox','MailboxLocations','AggregatedMailboxGuids','ExchangeSecurityDescriptor','ExchangeUserAccountControl','AdminDisplayVersion','MessageTrackingReadStatusEnabled','ExternalOofOptions','ForwardingAddress','ForwardingSmtpAddress','RetainDeletedItemsFor','IsMailboxEnabled','Languages','OfflineAddressBook','ProhibitSendQuota','ProhibitSendReceiveQuota','RecoverableItemsQuota','RecoverableItemsWarningQuota','CalendarLoggingQuota','DowngradeHighPriorityMessagesEnabled','ProtocolSettings','RecipientLimits','ImListMigrationCompleted','IsResource','IsLinked','IsShared','IsRootPublicFolderMailbox','LinkedMasterAccount','ResetPasswordOnNextLogon','ResourceCapacity','ResourceCustom','ResourceType','RoomMailboxAccountEnabled','SamAccountName','SCLDeleteThreshold','SCLDeleteEnabled','SCLRejectThreshold','SCLRejectEnabled','SCLQuarantineThreshold','SCLQuarantineEnabled','SCLJunkThreshold','SCLJunkEnabled','AntispamBypassEnabled','ServerLegacyDN','ServerName','UseDatabaseQuotaDefaults','IssueWarningQuota','RulesQuota','Office','UserPrincipalName','UMEnabled','MaxSafeSenders','MaxBlockedSenders','NetID','ReconciliationId','WindowsLiveID','MicrosoftOnlineServicesID','ThrottlingPolicy','RoleAssignmentPolicy','DefaultPublicFolderMailbox','SharingPolicy','RemoteAccountPolicy','MailboxPlan','ArchiveDatabase','ArchiveGuid','ArchiveName','JournalArchiveAddress','ArchiveQuota','ArchiveWarningQuota','ArchiveDomain','ArchiveStatus','ArchiveState','IsAuxMailbox','AuxMailboxParentObjectId','ChildAuxMailboxObjectIds','MailboxRelationType','RemoteRecipientType','DisabledArchiveDatabase','DisabledArchiveGuid','QueryBaseDN','QueryBaseDNRestrictionEnabled','MailboxMoveTargetMDB','MailboxMoveSourceMDB','MailboxMoveFlags','MailboxMoveRemoteHostName','MailboxMoveBatchName','MailboxMoveStatus','MailboxRelease','ArchiveRelease','IsPersonToPersonTextMessagingEnabled','IsMachineToPersonTextMessagingEnabled','UserSMimeCertificate','UserCertificate','CalendarVersionStoreDisabled','ImmutableId','PersistedCapabilities','SKUAssigned','AuditEnabled','AuditLogAgeLimit','AuditAdmin','AuditDelegate','AuditOwner','WhenMailboxCreated','SourceAnchor','UsageLocation','IsSoftDeletedByRemove','IsSoftDeletedByDisable','IsInactiveMailbox','IncludeInGarbageCollection','WhenSoftDeleted','InPlaceHolds','GeneratedOfflineAddressBooks','Extensions','HasPicture','HasSpokenName','AcceptMessagesOnlyFrom','AcceptMessagesOnlyFromDLMembers','AcceptMessagesOnlyFromSendersOrMembers','AddressListMembership','Alias','ArbitrationMailbox','BypassModerationFromSendersOrMembers','OrganizationalUnit','CustomAttribute1','CustomAttribute10','CustomAttribute11','CustomAttribute12','CustomAttribute13','CustomAttribute14','CustomAttribute15','CustomAttribute2','CustomAttribute3','CustomAttribute4','CustomAttribute5','CustomAttribute6','CustomAttribute7','CustomAttribute8','CustomAttribute9','ExtensionCustomAttribute1','ExtensionCustomAttribute2','ExtensionCustomAttribute3','ExtensionCustomAttribute4','ExtensionCustomAttribute5','DisplayName','EmailAddresses','GrantSendOnBehalfTo','ExternalDirectoryObjectId','HiddenFromAddressListsEnabled','LastExchangeChangedTime','LegacyExchangeDN','MaxSendSize','MaxReceiveSize','ModeratedBy','ModerationEnabled','PoliciesIncluded','PoliciesExcluded','EmailAddressPolicyEnabled','PrimarySmtpAddress','RecipientType','RecipientTypeDetails','RejectMessagesFrom','RejectMessagesFromDLMembers','RejectMessagesFromSendersOrMembers','RequireSenderAuthenticationEnabled','SimpleDisplayName','SendModerationNotifications','UMDtmfMap','WindowsEmailAddress','MailTip','MailTipTranslations','Identity','IsValid','ExchangeVersion','Name','DistinguishedName','Guid','ObjectCategory','ObjectClass','WhenChanged','WhenCreated','WhenChangedUTC','WhenCreatedUTC','OrganizationId','Id','OriginatingServer','ObjectState'
  )

  Write-Host "Fetching Exchange Online mailboxes ..." -ForegroundColor Cyan
  $mailboxes = Get-EXOMailbox -ResultSize Unlimited -PropertySets All

  $results = New-Object System.Collections.Generic.List[object]

  foreach ($mbx in $mailboxes) {
    # Get related Graph user (for UsageLocation, SKUAssigned as backup, etc.)
    $guser = $null
    try {
      if ($mbx.ExternalDirectoryObjectId) {
        $guser = Get-MgUser -UserId $mbx.ExternalDirectoryObjectId -Property id,userPrincipalName,usageLocation,assignedLicenses -ErrorAction Stop
      } elseif ($mbx.UserPrincipalName) {
        $guser = Get-MgUser -UserId $mbx.UserPrincipalName -Property id,userPrincipalName,usageLocation,assignedLicenses -ErrorAction Stop
      }
    } catch { }

    # Build a row preserving the exact column order; use values from mailbox first, Graph as fallback
    $row = [ordered]@{}

    foreach ($col in $Columns) {
      switch ($col) {
        'PSComputerName' { $row[$col] = $null; break }
        'RunspaceId' { $row[$col] = $([guid]::Empty); break }
        'PSShowComputerName' { $row[$col] = $false; break }
        'SKUAssigned' {
          $row[$col] = if ($mbx.PSObject.Properties[$col]) { $mbx.$col } elseif ($guser) { ($guser.AssignedLicenses.SkuId | ForEach-Object { $_.ToString() }) -join ';' } else { $null }
          break
        }
        'UsageLocation' {
          $row[$col] = if ($mbx.PSObject.Properties[$col]) { $mbx.$col } elseif ($guser) { $guser.UsageLocation } else { $null }
          break
        }
        'ExternalDirectoryObjectId' {
          $row[$col] = if ($mbx.PSObject.Properties[$col]) { $mbx.$col } elseif ($guser) { $guser.Id } else { $null }
          break
        }
        'EmailAddresses' {
          $row[$col] = if ($mbx.PSObject.Properties[$col]) { ($mbx.$col | Sort-Object) -join ';' } else { $null }
          break
        }
        'Languages' {
          $row[$col] = if ($mbx.PSObject.Properties[$col]) { ($mbx.$col | ForEach-Object { $_.ToString() }) -join ';' } else { $null }
          break
        }
        'UserCertificate' {
          $row[$col] = if ($mbx.PSObject.Properties[$col]) { ($mbx.$col | ForEach-Object { [System.Convert]::ToBase64String($_) }) -join ';' } else { $null }
          break
        }
        'UserSMimeCertificate' {
          $row[$col] = if ($mbx.PSObject.Properties[$col]) { ($mbx.$col | ForEach-Object { [System.Convert]::ToBase64String($_) }) -join ';' } else { $null }
          break
        }
        default {
          if ($mbx.PSObject.Properties[$col]) {
            $val = $mbx.$col
            # Flatten arrays / complex types into strings for CSV
            if ($val -is [System.Collections.IEnumerable] -and -not ($val -is [string])) {
              $row[$col] = ($val | ForEach-Object { $_.ToString() }) -join ';'
            } else {
              $row[$col] = $val
            }
          } else {
            $row[$col] = $null
          }
        }
      }
    }

    $results.Add([pscustomobject]$row)
  }

  Write-Host "Exporting $($results.Count) rows to $OutputPath ..." -ForegroundColor Cyan
  $results | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $OutputPath
  Write-Host "Done." -ForegroundColor Green
}
finally {
  Disconnect-MgGraph | Out-Null
}
