# Exchange_Mailbox_Stats_Full.ps1
# Non-interactive app-only Exchange Online mailbox statistics report
# Requires: PowerShell 7+, ExchangeOnlineManagement module (latest)

$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# Import Exchange Online module
#Import-Module ExchangeOnlineManagement -Force

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome

$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization -ShowBanner:$false

$OutputCsvPath = "Z:\Exchange\Mailbox_Stats\MailboxReport_$timeStamp.csv"

# Import ExchangeOnlineManagement module
#Import-Module ExchangeOnlineManagement -Force

# Connect to Exchange Online (app-only)
Write-Host "Connecting to Exchange Online (app-only)..."


# Fetch all mailboxes
Write-Host "Fetching mailbox list..."
$mailboxes = Get-EXOMailbox -ResultSize Unlimited -PropertySets All

# Fetch mailbox statistics
Write-Host "Fetching mailbox statistics..."
	$report = foreach ($mbx in Get-Mailbox -ResultSize Unlimited) {
		$upn = $mbx.UserPrincipalName
		$primaryStats = Get-EXOMailboxStatistics -Identity $upn -ErrorAction SilentlyContinue
		$archivestats = $null
		try
		{
			$archivestats = Get-EXOMailboxStatistics -Identity $upn -Archive -ErrorAction Stop
		} catch {
			$archivestats = $null }
		$ArchiveMailUsage = if ($archivestats) { try { $archivestats.TotalItemSize.ToString()} catch {"$($archivestats.TotalItemSize)" } } else {"No Archive"}
	}
$mailboxStats = $mailboxes | ForEach-Object {
    $stats = Get-EXOMailboxStatistics -Identity $_.UserPrincipalName

    # Create ordered object for export
    [PSCustomObject]@{
        #AssociatedItemCount = $stats.AssociatedItemCount
	ArchiveMailboxUsage=$ArchiveMailUsage
        DeletedItemCount = $stats.DeletedItemCount
        ItemCount = $stats.ItemCount
        TotalDeletedItemSize = $stats.TotalDeletedItemSize
        TotalItemSize = $stats.TotalItemSize
        MessageTableTotalSize = $stats.MessageTableTotalSize
        MessageTableAvailableSize = $stats.MessageTableAvailableSize
        AttachmentTableTotalSize = $stats.AttachmentTableTotalSize
        AttachmentTableAvailableSize = $stats.AttachmentTableAvailableSize
        OtherTablesTotalSize = $stats.OtherTablesTotalSize
        OtherTablesAvailableSize = $stats.OtherTablesAvailableSize
        TablesTotalSize = $stats.TablesTotalSize
        TablesTotalAvailableSize = $stats.TablesTotalAvailableSize
        IsEncrypted = $stats.IsEncrypted
        DataEncryptionPolicyId = $stats.DataEncryptionPolicyId
        PersistableTenantPartition = $stats.PersistableTenantPartition
        MailboxMiscFlag = $stats.MailboxMiscFlag
        KeyVersionIDs = $stats.KeyVersionIDs
        AdvancedDataEncryptionDetails = $stats.AdvancedDataEncryptionDetails
        MailboxFeatureStorageProperty = $stats.MailboxFeatureStorageProperty
        ItemAssistantCrawlVersionBlob = $stats.ItemAssistantCrawlVersionBlob
        DynamicCrawlersTasksBlob = $stats.DynamicCrawlersTasksBlob
        CurrentSchemaVersion = $stats.CurrentSchemaVersion
        ContainerBehaviorTypeId = $stats.ContainerBehaviorTypeId
        DisconnectDate = $stats.DisconnectDate
        DisconnectReason = $stats.DisconnectReason
        DisplayName = $stats.DisplayName
        LastInteractionTime = $stats.LastInteractionTime
        LastLoggedOnUserAccount = $stats.LastLoggedOnUserAccount
        LastLogoffTime = $stats.LastLogoffTime
        LastLogonTime = $stats.LastLogonTime
        LastTableSizeStatisticsUpdate = $stats.LastTableSizeStatisticsUpdate
        LastUserAccessTime = $stats.LastUserAccessTime
        LastUserActionTime = $stats.LastUserActionTime
        LegacyDN = $stats.LegacyDN
        MailboxGuid = $stats.MailboxGuid
        OwnerADGuid = $stats.OwnerADGuid
        MailboxType = $stats.MailboxType
        MailboxTypeDetail = $stats.MailboxTypeDetail
        ObjectClass = $stats.ObjectClass
        StorageLimitStatus = $stats.StorageLimitStatus
        MailboxTableIdentifier = $stats.MailboxTableIdentifier
        Database = $stats.Database
        ServerName = $stats.ServerName
        DatabaseName = $stats.DatabaseName
        IsDatabaseCopyActive = $stats.IsDatabaseCopyActive
        IsQuarantined = $stats.IsQuarantined
        QuarantineClients = $stats.QuarantineClients
        IsAbandonedMoveDestination = $stats.IsAbandonedMoveDestination
        ExternalDirectoryOrganizationId = $stats.ExternalDirectoryOrganizationId
        IsArchiveMailbox = $stats.IsArchiveMailbox
        IsMoveDestination = $stats.IsMoveDestination
        MailboxMessagesPerFolderCountWarningQuota = $stats.MailboxMessagesPerFolderCountWarningQuota
        MailboxMessagesPerFolderCountReceiveQuota = $stats.MailboxMessagesPerFolderCountReceiveQuota
        DumpsterMessagesPerFolderCountWarningQuota = $stats.DumpsterMessagesPerFolderCountWarningQuota
        DumpsterMessagesPerFolderCountReceiveQuota = $stats.DumpsterMessagesPerFolderCountReceiveQuota
        FolderHierarchyChildrenCountWarningQuota = $stats.FolderHierarchyChildrenCountWarningQuota
        FolderHierarchyChildrenCountReceiveQuota = $stats.FolderHierarchyChildrenCountReceiveQuota
        FolderHierarchyDepthWarningQuota = $stats.FolderHierarchyDepthWarningQuota
        FolderHierarchyDepthReceiveQuota = $stats.FolderHierarchyDepthReceiveQuota
        FoldersCountWarningQuota = $stats.FoldersCountWarningQuota
        FoldersCountReceiveQuota = $stats.FoldersCountReceiveQuota
        NamedPropertiesCountQuota = $stats.NamedPropertiesCountQuota
        SystemMessageSize = $stats.SystemMessageSize
        SystemMessageCount = $stats.SystemMessageCount
        SystemMessageSizeWarningQuota = $stats.SystemMessageSizeWarningQuota
        SystemMessageSizeShutoffQuota = $stats.SystemMessageSizeShutoffQuota
        BackupMessageSize = $stats.BackupMessageSize
        BackupMessageCount = $stats.BackupMessageCount
        BackupMessageSizeWarningQuota = $stats.BackupMessageSizeWarningQuota
        BackupMessageSizeShutoffQuota = $stats.BackupMessageSizeShutoffQuota
        BigFunnelIsEnabled = $stats.BigFunnelIsEnabled
	BigFunnelSemanticSearchEnabled = $stats.BigFunnelSemanticSearchEnabled
	TenantCopilotLicenseStatus = $stats.TenantCopilotLicenseStatus
SemanticSearchNeedLastSyncTime = $stats.SemanticSearchNeedLastSyncTime
SemanticSearchDisableTransitionEndTime = $stats.SemanticSearchDisableTransitionEndTime

	TenantCopilotLicenseDisableTransitionEndTime = $stats.TenantCopilotLicenseDisableTransitionEndTime
	BigFunnelSemanticIndexMinorVersion = $stats.BigFunnelSemanticIndexMinorVersion
	SemanticSearchEstimatedMcdbSpaceDemand	 = $stats.SemanticSearchEstimatedMcdbSpaceDemand
BigFunnelUpgradeInProgress = $stats.BigFunnelUpgradeInProgress
	BigFunnelWbSetVersionMessageCount = $stats.BigFunnelWbSetVersionMessageCount
	BigFunnelMaintainRefiners = $stats.BigFunnelMaintainRefiners
	BigFunnelFiltersCount = $stats.BigFunnelFiltersCount
	BigFunnelLargePOIsCount = $stats.BigFunnelLargePOIsCount
	BigFunnelLargePOIsSize = $stats.BigFunnelLargePOIsSize
	BigFunnelIsCurrentlyDeferring = $stats.BigFunnelIsCurrentlyDeferring
	BigFunnelDeferralStartTime = $stats.BigFunnelDeferralStartTime
	BigFunnelDeferralEndTime = $stats.BigFunnelDeferralEndTime
	BigFunnelPostingListLatestChangeId = $stats.BigFunnelPostingListLatestChangeId
	BigFunnelPostingListTableBuckets = $stats.BigFunnelPostingListTableBuckets
	BigFunnelPostingListTableAdvancedBuckets = $stats.BigFunnelPostingListTableAdvancedBuckets
	BigFunnelPartitionLevelIngestion = $stats.BigFunnelPartitionLevelIngestion
	BigFunnelPartitionLevelQuery = $stats.BigFunnelPartitionLevelQuery
	BigFunnelFilterTableTotalSize = $stats.BigFunnelFilterTableTotalSize
	BigFunnelFilterTableAvailableSize = $stats.BigFunnelFilterTableAvailableSize
	BigFunnelPostingListTableTotalSize = $stats.BigFunnelPostingListTableTotalSize
	BigFunnelPostingListTableAvailableSize = $stats.BigFunnelPostingListTableAvailableSize
	BigFunnelLargePOITableTotalSize = $stats.BigFunnelLargePOITableTotalSize
	BigFunnelLargePOITableAvailableSize = $stats.BigFunnelLargePOITableAvailableSize
	BigFunnelTotalPOISize = $stats.BigFunnelTotalPOISize
	VectorTableTotalSize = $stats.VectorTableTotalSize
	VectorTableAvailableSize = $stats.VectorTableAvailableSize
	MCDBVectorTableTotalSize = $stats.MCDBVectorTableTotalSize
	MCDBVectorTableAvailableSize = $stats.MCDBVectorTableAvailableSize
	MCDBVectorTablePercentReplicated = $stats.MCDBVectorTablePercentReplicated
	MCDBVectorTableNotScavengeableSize = $stats.MCDBVectorTableNotScavengeableSize
	BigFunnelMessageCount = $stats.BigFunnelMessageCount
	BigFunnelIndexedSize = $stats.BigFunnelIndexedSize
	BigFunnelPartiallyIndexedSize = $stats.BigFunnelPartiallyIndexedSize
	BigFunnelNotIndexedSize = $stats.BigFunnelNotIndexedSize
	BigFunnelCorruptedSize = $stats.BigFunnelCorruptedSize
	BigFunnelStaleSize = $stats.BigFunnelStaleSize
	BigFunnelShouldNotBeIndexedSize = $stats.BigFunnelShouldNotBeIndexedSize
	BigFunnelIndexedCount = $stats.BigFunnelIndexedCount
	BigFunnelPartiallyIndexedCount = $stats.BigFunnelPartiallyIndexedCount
	BigFunnelNotIndexedCount = $stats.BigFunnelNotIndexedCount
	BigFunnelCorruptedCount = $stats.BigFunnelCorruptedCount
	BigFunnelStaleCount = $stats.BigFunnelStaleCount
	BigFunnelMinimumPOICount = $stats.BigFunnelMinimumPOICount
	BigFunnelMinimumPOISize = $stats.BigFunnelMinimumPOISize
	BigFunnelShouldNotBeIndexedCount = $stats.BigFunnelShouldNotBeIndexedCount
	BigFunnelSemanticVectorsIndexedCount = $stats.BigFunnelSemanticVectorsIndexedCount
	BigFunnelSemanticVectorsPartiallyIndexedCount = $stats.BigFunnelSemanticVectorsPartiallyIndexedCount
	BigFunnelSemanticVectorsNotIndexedCount = $stats.BigFunnelSemanticVectorsNotIndexedCount
	BigFunnelSemanticVectorsShouldNotBeIndexedCount = $stats.BigFunnelSemanticVectorsShouldNotBeIndexedCount
	BigFunnelSemanticVectorsInvalidStateCount = $stats.BigFunnelSemanticVectorsInvalidStateCount
	BigFunnelSemanticVectorsStaleCount = $stats.BigFunnelSemanticVectorsStaleCount
	BigFunnelSemanticVectorsSize = $stats.BigFunnelSemanticVectorsSize
	BigFunnelRankingVectorsSize = $stats.BigFunnelRankingVectorsSize
	BigFunnelSemanticVectorsNewVersionIndexedCount = $stats.BigFunnelSemanticVectorsNewVersionIndexedCount
	BigFunnelSemanticVersion = $stats.BigFunnelSemanticVersion
	BigFunnelSemanticCrawlIteration = $stats.BigFunnelSemanticCrawlIteration
	BigFunnelSemanticUpgradeInProgress = $stats.BigFunnelSemanticUpgradeInProgress
	BigFunnelSemanticUpgraderVersion = $stats.BigFunnelSemanticUpgraderVersion
	BigFunnelMailboxCreationVersion = $stats.BigFunnelMailboxCreationVersion
	DatabaseIssueWarningQuota = $stats.DatabaseIssueWarningQuota
	DatabaseProhibitSendQuota = $stats.DatabaseProhibitSendQuota
	DatabaseProhibitSendReceiveQuota = $stats.DatabaseProhibitSendReceiveQuota
	ResourceUsageRollingAvgRop = $stats.ResourceUsageRollingAvgRop
	ResourceUsageRollingAvgDatabaseReads = $stats.ResourceUsageRollingAvgDatabaseReads
	ResourceUsageRollingAvgPagesDirtied = $stats.ResourceUsageRollingAvgPagesDirtied
	ResourceUsageRollingAvgPredictedCpu = $stats.ResourceUsageRollingAvgPredictedCpu
	ResourceUsageExponentialMovingAveragePredictedCpu = $stats.ResourceUsageExponentialMovingAveragePredictedCpu
	ResourceUsageExponentialMovingAveragePagesDirtied = $stats.ResourceUsageExponentialMovingAveragePagesDirtied
	ResourceUsageExponentialMovingAveragePeakPredictedCpu = $stats.ResourceUsageExponentialMovingAveragePeakPredictedCpu
	ResourceUsageExponentialMovingAveragePeakDatabaseReads = $stats.ResourceUsageExponentialMovingAveragePeakDatabaseReads
	ResourceUsageExponentialMovingAveragePeakPagesDirtied = $stats.ResourceUsageExponentialMovingAveragePeakPagesDirtied
	ResourceUsageExponentialMovingAverageDatabaseReads = $stats.ResourceUsageExponentialMovingAverageDatabaseReads
	ResourceUsageExponentialMovingAveragePassiveDatabaseReads = $stats.ResourceUsageExponentialMovingAveragePassiveDatabaseReads
	ResourceUsageExponentialMovingAveragePredictedCpuInOffPeakHour = $stats.ResourceUsageExponentialMovingAveragePredictedCpuInOffPeakHour
	ResourceUsageExponentialMovingAveragePagesDirtiedInOffPeakHour = $stats.ResourceUsageExponentialMovingAveragePagesDirtiedInOffPeakHour
	ResourceUsageExponentialMovingAverageDatabaseReadsInOffPeakHour = $stats.ResourceUsageExponentialMovingAverageDatabaseReadsInOffPeakHour
	ResourceUsageExponentialMovingAverageOffPeakPassiveDatabaseReads = $stats.ResourceUsageExponentialMovingAverageOffPeakPassiveDatabaseReads
	ResourceUsageExponentialMovingAveragePeakPassiveDatabaseReads = $stats.ResourceUsageExponentialMovingAveragePeakPassiveDatabaseReads
	ResourceUsageExponentialMovingAveragePassivePredictedCpu = $stats.ResourceUsageExponentialMovingAveragePassivePredictedCpu
	ResourceUsageExponentialMovingAverageOffPeakPassivePredictedCpu	= $stats.ResourceUsageExponentialMovingAverageOffPeakPassivePredictedCpu
ResourceUsageExponentialMovingAveragePeakPassivePredictedCpu = $stats.ResourceUsageExponentialMovingAveragePeakPassivePredictedCpu
	ResourceUsageExponentialMovingAveragePassivePredictedCpuV2 = $stats.ResourceUsageExponentialMovingAveragePassivePredictedCpuV2
	ResourceUsageExponentialMovingAveragePeakPassivePredictedCpuV2 = $stats.ResourceUsageExponentialMovingAveragePeakPassivePredictedCpuV2
	ResourceUsageExponentialMovingAverageOffPeakPassivePredictedCpuV2 = $stats.ResourceUsageExponentialMovingAverageOffPeakPassivePredictedCpuV2
	ResourceUsageExponentialMovingAveragePredictedCpuV2 = $stats.ResourceUsageExponentialMovingAveragePredictedCpuV2
	ResourceUsageExponentialMovingAveragePeakPredictedCpuV2 = $stats.ResourceUsageExponentialMovingAveragePeakPredictedCpuV2
	ResourceUsageExponentialMovingAverageOffPeakPredictedCpuV2 = $stats.ResourceUsageExponentialMovingAverageOffPeakPredictedCpuV2
	ResourceUsageRollingClientTypes = $stats.ResourceUsageRollingClientTypes
	ResourceUsageMinDateTime = $stats.ResourceUsageMinDateTime
	ResourceUsageMaxDateTime = $stats.ResourceUsageMaxDateTime
	ResourceUsageLastInteractiveClientTime = $stats.ResourceUsageLastInteractiveClientTime
	ResourceUsageTopEdgeEnvironments = $stats.ResourceUsageTopEdgeEnvironments
	ResourceUsageExponentialMovingAveragePeakNonCoalescablePagesDirtied = $stats.ResourceUsageExponentialMovingAveragePeakNonCoalescablePagesDirtied
	IsHighDensityShard = $stats.IsHighDensityShard
	SsdDbPreference = $stats.SsdDbPreference
	SsdDbRequired = $stats.SsdDbRequired
	NeedsToMove = $stats.NeedsToMove
	MCDBMessageTableTotalSize = $stats.MCDBMessageTableTotalSize
	MCDBMessageTableAvailableSize = $stats.MCDBMessageTableAvailableSize
	MCDBMessageTablePercentReplicated = $stats.MCDBMessageTablePercentReplicated
	MCDBOtherTablesTotalSize = $stats.MCDBOtherTablesTotalSize
	MCDBOtherTablesAvailableSize = $stats.MCDBOtherTablesAvailableSize
	MCDBTablesTotalSize = $stats.MCDBTablesTotalSize
	MCDBTablesTotalAvailableSize = $stats.MCDBTablesTotalAvailableSize
	MCDBBigFunnelFilterTableTotalSize = $stats.MCDBBigFunnelFilterTableTotalSize
	MCDBBigFunnelFilterTableAvailableSize = $stats.MCDBBigFunnelFilterTableAvailableSize
	MCDBBigFunnelFilterTablePercentReplicated = $stats.MCDBBigFunnelFilterTablePercentReplicated
	MCDBBigFunnelLargePOITableTotalSize = $stats.MCDBBigFunnelLargePOITableTotalSize
	MCDBBigFunnelLargePOITableAvailableSize = $stats.MCDBBigFunnelLargePOITableAvailableSize
	MCDBBigFunnelLargePOITablePercentReplicated = $stats.MCDBBigFunnelLargePOITablePercentReplicated
	MCDBBigFunnelPostingListTableTotalSize = $stats.MCDBBigFunnelPostingListTableTotalSize
	MCDBBigFunnelPostingListTableAvailableSize = $stats.MCDBBigFunnelPostingListTableAvailableSize
	MCDBBigFunnelPostingListTablePercentReplicated = $stats.MCDBBigFunnelPostingListTablePercentReplicated
	MCDBLogonScenarioTotalSize = $stats.MCDBLogonScenarioTotalSize
	MCDBLogonScenarioAvailableSize = $stats.MCDBLogonScenarioAvailableSize
	MCDBTablesTotalNotScavengeableSize = $stats.MCDBTablesTotalNotScavengeableSize
	MCDBMessageTableNotScavengeableSize = $stats.MCDBMessageTableNotScavengeableSize
	MCDBLogonScenarioNotScavengeableSize = $stats.MCDBLogonScenarioNotScavengeableSize
	MCDBBigFunnelFilterTableNotScavengeableSize = $stats.MCDBBigFunnelFilterTableNotScavengeableSize
	MCDBBigFunnelPostingListTableNotScavengeableSize = $stats.MCDBBigFunnelPostingListTableNotScavengeableSize
	MCDBBigFunnelLargePOITableNotScavengeableSize = $stats.MCDBBigFunnelLargePOITableNotScavengeableSize
	MCDBOtherTablesNotScavengeableSize = $stats.MCDBOtherTablesNotScavengeableSize
	EDBTablesTotalSize = $stats.EDBTablesTotalSize
	EDBTablesTotalAvailableSize = $stats.EDBTablesTotalAvailableSize
	EDBMessageTableTotalSize = $stats.EDBMessageTableTotalSize
	EDBMessageTableAvailableSize = $stats.EDBMessageTableAvailableSize
	EDBBigFunnelLargePOITableTotalSize = $stats.EDBBigFunnelLargePOITableTotalSize
	EDBBigFunnelLargePOITableAvailableSize = $stats.EDBBigFunnelLargePOITableAvailableSize
	EDBBigFunnelFilterTableTotalSize = $stats.EDBBigFunnelFilterTableTotalSize
	EDBBigFunnelFilterTableAvailableSize = $stats.EDBBigFunnelFilterTableAvailableSize
	EDBBigFunnelPostingListTableTotalSize = $stats.EDBBigFunnelPostingListTableTotalSize
	EDBBigFunnelPostingListTableAvailableSize = $stats.EDBBigFunnelPostingListTableAvailableSize
	LowLatencyContainerId = $stats.LowLatencyContainerId
	LowLatencyContainerFlags = $stats.LowLatencyContainerFlags
	BlobStorageTableTotalSize = $stats.BlobStorageTableTotalSize
	BlobStorageTableAvailableSize = $stats.BlobStorageTableAvailableSize
	ExternalBlobStorageSize = $stats.ExternalBlobStorageSize
	MailboxExperiments = $stats.MailboxExperiments
	DelayedDeletionFirstEntryTime = $stats.DelayedDeletionFirstEntryTime
	DelayedDeletionMessageCount = $stats.DelayedDeletionMessageCount
	MailboxBigStorageTotalSize = $stats.MailboxBigStorageTotalSize
	Identity = $_.UserPrincipalName
	MapiIdentity = $stats.MapiIdentity
	OriginatingServer = $stats.OriginatingServer
	IsValid = $stats.IsValid
	ObjectState = $stats.ObjectState

        #Identity = $_.UserPrincipalName
    }
}

# Export to CSV
Write-Host "Exporting report to CSV..."
$mailboxStats | Export-Csv -Path $OutputCsvPath -NoTypeInformation -Encoding UTF8

Write-Host "Report generated successfully at $OutputCsvPath"

# Disconnect
