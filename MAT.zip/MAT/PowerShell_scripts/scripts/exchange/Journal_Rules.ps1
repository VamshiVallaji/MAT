$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name
Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization -ShowBanner:$false



# Connect to Exchange Online


# Get journaling rules and select required columns
$report = Get-JournalRule | Select-Object `
    @{Name="JournalRule_Attributes";Expression={"Journaling Rule"}},
    Identity,
    Name,
    @{Name="RuleIdentity";Expression={$_.Identity}},
    JournalEmailAddress,
    Recipient,
    Scope,
    Enabled,
    OrganizationId,
    WhenCreated,
    WhenChanged,
    Description,
    ObjectState

$reportPath = "$network_drive\Exchange\Journal_Rules\Journal_Rules_Report_$timestamp.csv"

$report | Export-Csv -Path $reportPath -NoTypeInformation

# Disconnect session




