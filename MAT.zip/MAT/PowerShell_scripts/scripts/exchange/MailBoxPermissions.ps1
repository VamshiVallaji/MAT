$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name
Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization -ShowBanner:$false



# Connect to Exchange Online


$reportPath = "$network_drive\Exchange\MailBoxPermissions\MailBox_permissions_Report_$timestamp.csv"

$Result = @()

$mailboxes = Get-Mailbox -ResultSize Unlimited

foreach ($mailbox in $mailboxes) {
    try {
        $permissions = Get-MailboxPermission -Identity $mailbox.Identity | Where-Object {
            $_.User.ToString() -notlike "NT AUTHORITY\SELF" -and
            $_.AccessRights -ne $null -and
            $_.IsInherited -eq $false
        }

        foreach ($perm in $permissions) {
            try {
                $delegate = Get-Recipient $perm.User -ErrorAction Stop
                $delegateEmail = $delegate.PrimarySmtpAddress
                $delegateName = $delegate.DisplayName
            } catch {
                # If Get-Recipient fails, fallback to raw user identity
                $delegateEmail = "N/A"
                $delegateName = $perm.User
            }

            $match = if ($delegateEmail -eq $mailbox.PrimarySmtpAddress) { "Yes" } else { "No" }

            $Result += [PSCustomObject]@{
                MailboxName     = $mailbox.DisplayName
                MailboxEmail    = $mailbox.PrimarySmtpAddress
                DelegateName    = $delegateName
                DelegateEmail   = $delegateEmail
                DelegateAccess  = ($perm.AccessRights -join ", ")
                Match           = $match
            }
        }
    } catch {
        Write-Warning "Failed to process mailbox: $($mailbox.DisplayName). Error: $_"
    }
}

# Export to CSV
$Result | Export-Csv -Path $reportPath -NoTypeInformation




