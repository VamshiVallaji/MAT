$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name
Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization -ShowBanner:$false



# Connect to Exchange Online


$reportPath = "$network_drive\Exchange\PublicFolders\PublicFolders_Report_$timestamp.csv"

# Initialize empty report
$report = @()

try {
    # Try to get public folders
    $publicFolders = Get-PublicFolder -Recurse -ResultSize Unlimited -ErrorAction Stop
}
catch {
    Write-Host "No public folders found in the tenant." -ForegroundColor Yellow
    $publicFolders = @()
}

foreach ($pf in $publicFolders) {
    try {
        $stats = Get-PublicFolderStatistics -Identity $pf.Identity -ErrorAction Stop
    }
    catch {
        $stats = $null
    }

    $report += [PSCustomObject]@{
        Name = $pf.Name
        MailEnabled = $pf.MailEnabled
        CreationTime = $pf.WhenCreated
        Identity = $pf.Identity
        LastModificationTime = $pf.WhenChanged
        TotalItemSizeInMB = if ($stats.TotalItemSize) { [math]::Round(($stats.TotalItemSize.Value.ToMB()),2) } else { 0 }
        'In GB' = if ($stats.TotalItemSize) { [math]::Round(($stats.TotalItemSize.Value.ToGB()),2) } else { 0 }
        ContentMailboxName = $pf.ContentMailboxName
    }
}

# If nothing found, still export headers
if (-not $report) {
    $report = [PSCustomObject]@{
        Name = $null
        MailEnabled = $null
        CreationTime = $null
        Identity = $null
        LastModificationTime = $null
        TotalItemSizeInMB = $null
        'In GB' = $null
        ContentMailboxName = $null
    }
}

# Export CSV
$report | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "Report exported to $reportPath" -ForegroundColor Green
 






