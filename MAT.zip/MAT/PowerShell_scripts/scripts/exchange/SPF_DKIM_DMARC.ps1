$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name
Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization -ShowBanner:$false



# Connect to Exchange Online



#Add-RoleGroupMember "View-Only Configuration" -Member $ClientId

$domains = (Get-AcceptedDomain).DomainName | Where-Object { $_ -notlike "*.onmicrosoft.com" }
$report = @()

foreach ($domain in $domains) {

    # --- SPF ---
    try {
        $spfRecord = (Resolve-DnsName -Name $domain -Type TXT | Where-Object { $_.Strings -match "^v=spf1" }).Strings -join " "
        if ($spfRecord) {
            $spfParts = $spfRecord -split "\s+"
            $spfVersion = ($spfParts | Where-Object { $_ -like "v=spf1*" })
            $spfIncludes = ($spfParts | Where-Object { $_ -like "include:*" }) -join ","
            $spfIp4     = ($spfParts | Where-Object { $_ -like "ip4:*" }) -join ","
            $spfIp6     = ($spfParts | Where-Object { $_ -like "ip6:*" }) -join ","
            $spfPolicy  = ($spfParts | Where-Object { $_ -match "[-~?+]all" })
        } else {
            $spfVersion = $spfIncludes = $spfIp4 = $spfIp6 = $spfPolicy = "Not found"
        }
    } catch { $spfVersion = $spfIncludes = $spfIp4 = $spfIp6 = $spfPolicy = "Error" }

    # --- DMARC ---
    try {
        $dmarcRecord = (Resolve-DnsName -Name ("_dmarc." + $domain) -Type TXT).Strings -join " "
        if ($dmarcRecord) {
            $dmarcParts = ($dmarcRecord -split ";") | ForEach-Object { $_.Trim() }
            $dmarcTable = @{}
            foreach ($part in $dmarcParts) {
                if ($part -match "=") {
                    $k,$v = $part -split "=",2
                    $dmarcTable[$k] = $v
                }
            }
            $dmarcVersion = $dmarcTable["v"]
            $dmarcPolicy  = $dmarcTable["p"]
            $dmarcSubPol  = $dmarcTable["sp"]
            $dmarcRua     = $dmarcTable["rua"]
            $dmarcRuf     = $dmarcTable["ruf"]
            $dmarcAdkim   = $dmarcTable["adkim"]
            $dmarcAspf    = $dmarcTable["aspf"]
            $dmarcPct     = $dmarcTable["pct"]
            $dmarcFo      = $dmarcTable["fo"]
        }
    } catch { $dmarcVersion = $dmarcPolicy = $dmarcSubPol = $dmarcRua = $dmarcRuf = $dmarcAdkim = $dmarcAspf = $dmarcPct = $dmarcFo = "Not found" }

    # --- DKIM ---
    try {
        $dkim = Get-DkimSigningConfig -Identity $domain -ErrorAction SilentlyContinue
        if ($dkim) {
            $dkimEnabled  = $dkim.Enabled
            $dkimSelector1 = $dkim.Selector1CNAME
            $dkimSelector2 = $dkim.Selector2CNAME
            $dkimKeySize   = $dkim.KeySize
            $dkimRotation  = $dkim.KeyRotationEnabled
            $dkimLastUpd   = $dkim.LastKeyUpdate
        } else {
            $dkimEnabled = $dkimSelector1 = $dkimSelector2 = $dkimKeySize = $dkimRotation = $dkimLastUpd = "Not configured"
        }
    } catch { $dkimEnabled = $dkimSelector1 = $dkimSelector2 = $dkimKeySize = $dkimRotation = $dkimLastUpd = "Error" }

    # --- Consolidated Object ---
    $report += [PSCustomObject]@{
        Domain          = $domain

        # SPF
        SPF_Version     = $spfVersion
        SPF_Includes    = $spfIncludes
        SPF_IPv4        = $spfIp4
        SPF_IPv6        = $spfIp6
        SPF_Policy      = $spfPolicy

        # DMARC
        DMARC_Version   = $dmarcVersion
        DMARC_Policy    = $dmarcPolicy
        DMARC_SubPolicy = $dmarcSubPol
        DMARC_RUA       = $dmarcRua
        DMARC_RUF       = $dmarcRuf
        DMARC_ADKIM     = $dmarcAdkim
        DMARC_ASPF      = $dmarcAspf
        DMARC_PCT       = $dmarcPct
        DMARC_FO        = $dmarcFo

        # DKIM
        DKIM_Enabled    = $dkimEnabled
        DKIM_Selector1  = $dkimSelector1
        DKIM_Selector2  = $dkimSelector2
        DKIM_KeySize    = $dkimKeySize
        DKIM_Rotation   = $dkimRotation
        DKIM_LastUpdate = $dkimLastUpd
    }
}

# Export
$report | Export-Csv "$network_drive\Exchange\SPF_DKIM_DMARC\SPF_DKIM_DMARC_Full_Report_$timestamp.csv" -NoTypeInformation -Encoding UTF8




