﻿<#
Export-AAD_MailEnabledSecurityGroups.ps1
PowerShell 5.1 - Export all mail-enabled security groups (Azure AD / Microsoft Graph)
Infrastructure: cloud

Notes:
- This script expects Microsoft.Graph module installed (Install-Module Microsoft.Graph).
- The script uses your exact connection block (unchanged) to read config from the network drive and call Connect-MgGraph.
- Output CSV will be written to C:\Reports\PasswordWriteback (creates folder if missing).
- Mail-enabled security groups = mailEnabled eq true AND securityEnabled eq true.
#>

# --- Ensure Microsoft.Graph is available (import modules so cmdlets are present) ---
#Import-Module Microsoft.Graph -ErrorAction Stop
# Importing submodules that provide owners/members cmdlets
Import-Module Microsoft.Graph.Groups -ErrorAction SilentlyContinue
Import-Module Microsoft.Graph.Users -ErrorAction SilentlyContinue

# --- Your exact connection block (kept as you requested) ---
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$JsonPath = "$network_drive\Config.json"

$config = Get-Content $JsonPath | ConvertFrom-Json

$TenantId = $config. TenantId

$ClientId = $config.AppId

$Thumbprint = $config. Thumbprint

#=== Output ===

$OutFolder = "$network_drive\Identity\AD_ADMail-enabledsecuritygroup"

# Ensure TLS 1.2

[Net.ServicePointManager]:: SecurityProtocol = [Net.SecurityProtocolType]:: Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null
# --- end of exact block ---

# Create output folder if needed
if (-not (Test-Path -Path $OutFolder)) {
    New-Item -Path $OutFolder -ItemType Directory -Force | Out-Null
}

$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$OutCsv = Join-Path $OutFolder "AAD_MailEnabledSecurityGroups_$timeStamp.csv"

Write-Host "Querying Microsoft Graph for mail-enabled security groups..." -ForegroundColor Cyan

# Filter: mailEnabled eq true and securityEnabled eq true
$filter = "mailEnabled eq true and securityEnabled eq true"
$select = "id,displayName,mail,mailNickname,groupTypes,securityEnabled,mailEnabled,onPremisesSyncEnabled,createdDateTime,proxyAddresses,onPremisesSamAccountName"

# Retrieve groups (paged by SDK)
$groups = Get-MgGroup -Filter $filter -Property $select -All -ErrorAction Stop

if (-not $groups -or $groups.Count -eq 0) {
    Write-Host "No mail-enabled security groups found. Creating header-only CSV at $OutCsv" -ForegroundColor Yellow
    "" | Select-Object Id,DisplayName,Mail,MailNickname,GroupTypes,SecurityEnabled,MailEnabled,OnPremisesSyncEnabled,OnPremisesSamAccountName,ProxyAddresses,CreatedDateTime,OwnersCount,MembersCount |
        Export-Csv -Path $OutCsv -NoTypeInformation -Encoding UTF8 -Force
    Write-Host "Done." -ForegroundColor Cyan
    return
}

$rows = @()
Write-Host ("Total mail-enabled security groups retrieved: {0}" -f $groups.Count) -ForegroundColor Green

foreach ($g in $groups) {
    $id = $g.Id
    $displayName = ($g.DisplayName -as [string])
    $mail = ($g.Mail -as [string])
    $mailNick = ($g.MailNickname -as [string])
    $groupTypes = if ($g.GroupTypes) { ($g.GroupTypes -join ";") } else { "" }
    $securityEnabled = $g.SecurityEnabled
    $mailEnabled = $g.MailEnabled
    $onPremSync = $g.OnPremisesSyncEnabled
    $created = $g.CreatedDateTime
    $proxy = ""
    if ($g.ProxyAddresses) { $proxy = ($g.ProxyAddresses -join ";") }
    $onPremSam = ($g.OnPremisesSamAccountName -as [string])

    # Owners count (use -All paging). If enumeration fails due to permissions, set -1
    $ownerCount = -1
    try {
        $owners = Get-MgGroupOwner -GroupId $id -All -ErrorAction Stop
        if ($owners) { $ownerCount = $owners.Count } else { $ownerCount = 0 }
    } catch {
        $ownerCount = -1
    }

    # Members count
    $memberCount = -1
    try {
        $members = Get-MgGroupMember -GroupId $id -All -ErrorAction Stop
        if ($members) { $memberCount = $members.Count } else { $memberCount = 0 }
    } catch {
        $memberCount = -1
    }

    $rows += [PSCustomObject]@{
        Id = $id
        DisplayName = $displayName
        Mail = $mail
        MailNickname = $mailNick
        GroupTypes = $groupTypes
        SecurityEnabled = $securityEnabled
        MailEnabled = $mailEnabled
        OnPremisesSyncEnabled = $onPremSync
        OnPremisesSamAccountName = $onPremSam
        ProxyAddresses = $proxy
        CreatedDateTime = $created
        OwnersCount = $ownerCount
        MembersCount = $memberCount
    }
}

# Export CSV
$rows | Export-Csv -Path $OutCsv -NoTypeInformation -Encoding UTF8 -Force
Write-Host ("Export complete: {0} groups -> {1}" -f $rows.Count, $OutCsv) -ForegroundColor Green
Write-Host "Done." -ForegroundColor Cyan