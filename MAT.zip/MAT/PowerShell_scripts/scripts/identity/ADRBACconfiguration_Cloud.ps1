﻿<#
.SYNOPSIS
  Export Azure AD RBAC (directory roles) assignments including direct members and group-expanded members.

.DESCRIPTION
  - Lists all Azure AD / Entra directory roles.
  - Gets direct assignments (users, service principals, groups).
  - If assignment is a group, expands group members (users).
  - Exports full flattened view to CSV.

.REQUIREMENTS
  Microsoft.Graph PowerShell module.
  App-only authentication with Directory.Read.All permission.

.PARAMETER TenantId
  Tenant id or domain.

.PARAMETER ClientId
  App (client) id.

.PARAMETER ClientSecret
  App secret.

.PARAMETER OutFolder
  Output folder for CSV report.
#>

$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutFolder = "$network_drive\Identity\AD_ADRBACconfiguration"

# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

# Ensure TLS
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$outCsv = Join-Path $OutFolder "AAD_RBAC_Assignments_$timeStamp.csv"

$results = @()

Write-Host "Fetching directory roles..." -ForegroundColor Cyan
$rolesRes = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/directoryRoles" -ErrorAction SilentlyContinue
if ($rolesRes -and $rolesRes.value) {
    foreach ($r in $rolesRes.value) {
        $roleId = $r.id
        $roleName = $r.displayName

        Write-Host "Processing role: $roleName" -ForegroundColor Yellow

        # Get role members
        $memUri = "https://graph.microsoft.com/v1.0/directoryRoles/$roleId/members"
        $memRes = Invoke-MgGraphRequest -Method GET -Uri $memUri -ErrorAction SilentlyContinue

        if ($memRes -and $memRes.value) {
            foreach ($m in $memRes.value) {
                $mType = ""
                try { $mType = ($m.'@odata.type' -replace "#microsoft.graph.","") } catch {}

                $mDisplay = ""; try { $mDisplay = $m.displayName } catch {}
                $mUpn = ""; try { $mUpn = $m.userPrincipalName } catch {}
                $mId = ""; try { $mId = $m.id } catch {}

                if ($mType -eq "group") {
                    # Record group as principal
                    $results += [PSCustomObject]@{
                        RoleName = $roleName
                        RoleId = $roleId
                        AssignmentType = "Direct"
                        PrincipalType = "Group"
                        PrincipalDisplayName = $mDisplay
                        PrincipalUPN = ""
                        GroupId = $mId
                        Source = "Direct Group Assignment"
                    }

                    # Expand group members
                    $grpUri = "https://graph.microsoft.com/v1.0/groups/$mId/members"
                    $grpRes = Invoke-MgGraphRequest -Method GET -Uri $grpUri -ErrorAction SilentlyContinue
                    if ($grpRes -and $grpRes.value) {
                        foreach ($gm in $grpRes.value) {
                            $gmType = ($gm.'@odata.type' -replace "#microsoft.graph.","")
                            $gmDisplay = ""; try { $gmDisplay = $gm.displayName } catch {}
                            $gmUpn = ""; try { $gmUpn = $gm.userPrincipalName } catch {}
                            $gmId = ""; try { $gmId = $gm.id } catch {}

                            $results += [PSCustomObject]@{
                                RoleName = $roleName
                                RoleId = $roleId
                                AssignmentType = "GroupMember"
                                PrincipalType = $gmType
                                PrincipalDisplayName = $gmDisplay
                                PrincipalUPN = $gmUpn
                                GroupId = $mId
                                Source = "Expanded from Group: $mDisplay"
                            }
                        }
                    }
                } else {
                    # Direct user or service principal
                    $results += [PSCustomObject]@{
                        RoleName = $roleName
                        RoleId = $roleId
                        AssignmentType = "Direct"
                        PrincipalType = $mType
                        PrincipalDisplayName = $mDisplay
                        PrincipalUPN = $mUpn
                        GroupId = ""
                        Source = "Direct Assignment"
                    }
                }
            }
        } else {
            # Role with no members
            $results += [PSCustomObject]@{
                RoleName = $roleName
                RoleId = $roleId
                AssignmentType = ""
                PrincipalType = ""
                PrincipalDisplayName = ""
                PrincipalUPN = ""
                GroupId = ""
                Source = "No members"
            }
        }
    }
}

# Export CSV
if ($results.Count -gt 0) {
    $results | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
    Write-Host "Exported $($results.Count) RBAC assignment entries to $outCsv" -ForegroundColor Green
} else {
    "" | Select-Object "RoleName","RoleId","AssignmentType","PrincipalType","PrincipalDisplayName","PrincipalUPN","GroupId","Source" |
    Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
    Write-Host "No RBAC assignments found. Header-only CSV created: $outCsv" -ForegroundColor Yellow
}

# Disconnect
try { Disconnect-MgGraph -ErrorAction SilentlyContinue } catch {}