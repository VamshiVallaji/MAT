﻿<#
.SYNOPSIS
  Export Azure AD security group inventory using certificate auth with Connect-MgGraph and save to a network drive (PowerShell 5.1).

.DESCRIPTION
  - Connects to Microsoft Graph using certificate credential (thumbprint).
  - Exports security-enabled groups' metadata and optionally expands group members.
  - Writes CSV output to a provided network path (UNC) or local folder.

.PARAMETER TenantId Tenant ID (GUID) or tenant domain
.PARAMETER ClientId App (client) id
.PARAMETER CertThumbprint Thumbprint of certificate in My store (CurrentUser or LocalMachine)
.PARAMETER OutFolder Destination folder (UNC or local). If not exists, created.
.PARAMETER ExpandMembers Switch; if present expand group members into GroupMembers CSV.
.PARAMETER StoreLocation Cert store location: CurrentUser or LocalMachine (default CurrentUser)

.EXAMPLE
  .\Export-AADGroups-WithCert-ConnectMgGraph.ps1 -TenantId contoso.onmicrosoft.com -ClientId <id> -CertThumbprint <thumbprint> -OutFolder "\\fileserver\Reports\AAD" -ExpandMembers
#>

param(
  [switch]$ExpandMembers  
  )

$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutFolder = "$network_drive\Identity\AD_ADSecuritygroupsinformation"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

function Write-ErrAndExit {
  param($msg)
  Write-Host $msg -ForegroundColor Red
  throw $msg
}

# Validate certificate exists in specified store

$groupsCsv = Join-Path $OutFolder "AAD_SecurityGroups\AAD_SecurityGroups_$timeStamp.csv"
$groupMembersCsv = Join-Path $OutFolder "AAD_GroupMembers\AAD_GroupMembers_$timeStamp.csv"
$rawJson = Join-Path $OutFolder "AAD_SecurityGroups\AAD_SecurityGroups_raw_$timeStamp.json"

# Fetch security-enabled groups (securityEnabled eq true)
$selectProps = "id,displayName,mail,mailEnabled,securityEnabled,groupTypes,description,createdDateTime,onPremisesSyncEnabled,proxyAddresses"
$filter = "securityEnabled eq true"

$allGroups = @()
try {
  # Use -All to page automatically
  $allGroups = Get-MgGroup -Filter $filter -Property $selectProps -All -ErrorAction Stop
} catch {
  Write-Host "Get-MgGroup failed: $($_.Exception.Message)" -ForegroundColor Red
  $allGroups = @()
}

# Save raw JSON (best-effort)
try {
  if ($allGroups -and $allGroups.Count -gt 0) {
    $allGroups | ConvertTo-Json -Depth 6 | Set-Content -Path $rawJson -Encoding UTF8
  } else {
    # header-only raw file
    "[]" | Set-Content -Path $rawJson -Encoding UTF8
  }
} catch {
  Write-Host "Warning: failed to write raw JSON: $($_.Exception.Message)" -ForegroundColor Yellow
}

# Build Groups CSV
$csvGroups = @()
if ($allGroups -and $allGroups.Count -gt 0) {
  foreach ($g in $allGroups) {
    # normalize groupTypes & proxyAddresses
    $gt = ""
    if ($null -ne $g.GroupTypes) { try { $gt = ($g.GroupTypes -join ";") } catch { $gt = "" } }
    $pa = ""
    if ($null -ne $g.ProxyAddresses) { try { $pa = ($g.ProxyAddresses -join ";") } catch { $pa = "" } }

    # owners: use Get-MgGroupOwner to list owners (safe and paged)
    $ownersList = @()
    try {
      $owners = Get-MgGroupOwner -GroupId $g.Id -All -ErrorAction SilentlyContinue
      if ($owners) {
        foreach ($o in $owners) {
          # owner object could be user/servicePrincipal/group etc.
          $ownerStr = ""
          try {
            if ($o.UserPrincipalName) { $ownerStr = $o.UserPrincipalName }
            elseif ($o.Mail) { $ownerStr = $o.Mail }
            elseif ($o.DisplayName) { $ownerStr = $o.DisplayName }
            else { $ownerStr = $o.Id }
          } catch { $ownerStr = $o.Id }
          if ($ownerStr -and $ownerStr -ne "") { $ownersList += $ownerStr }
        }
      }
    } catch {
      # ignore owner retrieval errors for this group
      $ownersList = @()
    }
    $ownerStrJoined = ""
    if ($ownersList.Count -gt 0) { $ownerStrJoined = $ownersList -join ";" }

    # member count using Get-MgGroupMember -All and Count
    $memberCount = 0
    try {
      $members = Get-MgGroupMember -GroupId $g.Id -All -ErrorAction SilentlyContinue
      if ($members) { $memberCount = $members.Count }
    } catch {
      $memberCount = 0
    }

    $csvGroups += [PSCustomObject]@{
      Id = $g.Id
      DisplayName = ($g.DisplayName -as [string])
      Mail = ($g.Mail -as [string])
      MailEnabled = $g.MailEnabled
      SecurityEnabled = $g.SecurityEnabled
      GroupTypes = $gt
      Description = ($g.Description -as [string])
      CreatedDateTime = ($g.CreatedDateTime -as [string])
      OnPremisesSyncEnabled = $g.OnPremisesSyncEnabled
      ProxyAddresses = $pa
      OwnerList = $ownerStrJoined
      MemberCount = $memberCount
    }
  }
}

# Export groups CSV (header-only if empty)
if ($csvGroups.Count -eq 0) {
  "" | Select-Object Id,DisplayName,Mail,MailEnabled,SecurityEnabled,GroupTypes,Description,CreatedDateTime,OnPremisesSyncEnabled,ProxyAddresses,OwnerList,MemberCount |
    Export-Csv -Path $groupsCsv -NoTypeInformation -Encoding UTF8
  Write-Host "No security groups found; header-only CSV created." -ForegroundColor Yellow
} else {
  $csvGroups | Export-Csv -Path $groupsCsv -NoTypeInformation -Encoding UTF8
  Write-Host ("Groups exported: {0} rows to {1}" -f $csvGroups.Count, $groupsCsv) -ForegroundColor Green
}

# Create GroupMembers CSV header
"" | Select-Object GroupId,GroupDisplayName,MemberId,MemberDisplayName,MemberUserPrincipalName,MemberMail,MemberType |
  Export-Csv -Path $groupMembersCsv -NoTypeInformation -Encoding UTF8

if ($ExpandMembers) {
  Write-Host "Expanding members for each group (this may take time)..." -ForegroundColor Cyan
  foreach ($g in $allGroups) {
    try {
      $members = Get-MgGroupMember -GroupId $g.Id -All -ErrorAction Stop
      if ($members) {
        foreach ($m in $members) {
          # Member object varies by type; try to extract userPrincipalName/mail/displayName
          $mType = ($m.'@odata.type' -as [string])
          if ($mType -and $mType.StartsWith("#")) { $mType = $mType.TrimStart("#") }
          $mUpn = ""
          $mDisplay = ""
          $mMail = ""
          try { if ($m.UserPrincipalName) { $mUpn = $m.UserPrincipalName } } catch {}
          try { if ($m.DisplayName) { $mDisplay = $m.DisplayName } } catch {}
          try { if ($m.Mail) { $mMail = $m.Mail } } catch {}
          $row = [PSCustomObject]@{
            GroupId = $g.Id
            GroupDisplayName = ($g.DisplayName -as [string])
            MemberId = $m.Id
            MemberDisplayName = $mDisplay
            MemberUserPrincipalName = $mUpn
            MemberMail = $mMail
            MemberType = $mType
          }
          $row | Export-Csv -Path $groupMembersCsv -NoTypeInformation -Encoding UTF8 -Append
        }
      }
    } catch {
      $err = [PSCustomObject]@{
        GroupId = $g.Id
        GroupDisplayName = ($g.DisplayName -as [string])
        MemberId = "ERROR: " + $_.Exception.Message
        MemberDisplayName = ""
        MemberUserPrincipalName = ""
        MemberMail = ""
        MemberType = ""
      }
      $err | Export-Csv -Path $groupMembersCsv -NoTypeInformation -Encoding UTF8 -Append
    }
  }
  Write-Host "Member expansion complete." -ForegroundColor Green
} else {
  Write-Host "Member expansion was skipped. To expand members, re-run with -ExpandMembers." -ForegroundColor Yellow
}

Write-Host "Completed. Outputs located in: $OutFolder" -ForegroundColor Magenta

# Disconnect (clean up)
try { Disconnect-MgGraph -Confirm:$false -ErrorAction SilentlyContinue } catch {}