﻿# Load configuration from network drive
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$TenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint

# Output folder and file
$OutFolder = "$network_drive\Identity\AD_ApplicationsutilizingAzureADforSSO"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$outputFile = Join-Path $OutFolder "AzureAD_SSO_Applications_$timeStamp.csv"

# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Connect to Microsoft Graph
Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

# Fetch all service principals
Write-Host "Fetching all service principals..." -ForegroundColor Cyan
$allSPs = Get-MgServicePrincipal -All

# Initialize output collection
$ssoConfigs = @()

foreach ($app in $allSPs) {
    Write-Host "Processing: $($app.DisplayName)" -ForegroundColor Yellow
    $ssoType = $app.PreferredSingleSignOnMode
    $entityId = "Not Available"
    $signOnUrl = $app.LoginUrl
    $logoutUrl = $app.LogoutUrl
    $AssignmentRequired = $app.AppRoleAssignmentRequired
    $SignInAudience = $app.SignInAudience
    $PreferredTokenSigningKeyThumbprint = $app.PreferredTokenSigningKeyThumbprint
    $certificateExpirationDate = "Not Available"

    # Certificate expiration
    if ($app.KeyCredentials) {
        try {
            $utcExpirationDate = $app.KeyCredentials | Where-Object { $_.Type -eq "AsymmetricX509Cert" } | Sort-Object EndDateTime -Descending | Select-Object -First 1 -ExpandProperty EndDateTime
            if ($utcExpirationDate) {
                $certificateExpirationDate = (Get-Date $utcExpirationDate).ToLocalTime()
            }
        } catch {}
    }

    # Reply URLs
    $replyUrls = if ($app.ReplyUrls) { $app.ReplyUrls -join ";" } else { "Not Available" }

    # EntityId (non-SAML)
    if ($ssoType -ne "saml") {
        $entityId = if ($app.ServicePrincipalNames) {
            ($app.ServicePrincipalNames | Where-Object { $_ -ne $app.AppId }) -join ";"
        } else {
            "Not Available"
        }
    }

    # SAML-specific check
    $hasSaml = $false
    try {
        $samlRes = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$($app.Id)/samlSingleSignOnSettings" -ErrorAction SilentlyContinue
        if ($samlRes -and ($samlRes.value.Count -gt 0 -or $samlRes.entityId)) {
            $hasSaml = $true
            $entityId = $samlRes.entityId
            $signOnUrl = $samlRes.singleSignOnUrl
            $logoutUrl = $samlRes.logoutUrl
            $AssignmentRequired = $samlRes.assignmentRequired
            $PreferredTokenSigningKeyThumbprint = $samlRes.preferredTokenSigningKeyThumbprint
            $certificateExpirationDate = $samlRes.certificateExpirationDateTime
        }
    } catch {}

    # Assignments
    $userAssignments = "Not Available"
    $groupAssignments = "Not Available"
    try {
        $assignedUsers = Get-MgServicePrincipalAppRoleAssignedTo -ServicePrincipalId $app.Id -All | Where-Object { $_.PrincipalType -eq "User" }
        $userAssignments = if ($assignedUsers) { ($assignedUsers | ForEach-Object { $_.PrincipalDisplayName }) -join ";" } else { "No Users Assigned" }

        $assignedGroups = Get-MgServicePrincipalAppRoleAssignedTo -ServicePrincipalId $app.Id -All | Where-Object { $_.PrincipalType -eq "Group" }
        $groupAssignments = if ($assignedGroups) { ($assignedGroups | ForEach-Object { $_.PrincipalDisplayName }) -join ";" } else { "No Groups Assigned" }
    } catch {}

    # Add to output
    $ssoConfigs += [PSCustomObject]@{
        ApplicationName = $app.DisplayName
        ObjectId = $app.Id
        AppId = $app.AppId
        PreferredSingleSignOnMode = $ssoType
        SSOType = if ($hasSaml) { "SAML" } elseif ($ssoType) { $ssoType } else { "Unknown" }
        ReplyUrls = $replyUrls
        EntityId = $entityId
        SignOnUrl = $signOnUrl
        LogoutUrl = $logoutUrl
        AssignmentRequired = $AssignmentRequired
        UserAssignments = $userAssignments
        GroupAssignments = $groupAssignments
        SignInAudience = $SignInAudience
        PreferredTokenSigningKeyThumbprint = $PreferredTokenSigningKeyThumbprint
        CertificateExpiration = $certificateExpirationDate
    }
}

# Export to CSV
$ssoConfigs | Export-Csv -Path $outputFile -NoTypeInformation -Encoding UTF8
Write-Host "SSO configuration export completed. File saved to $outputFile" -ForegroundColor Green

# Disconnect
try { Disconnect-MgGraph -ErrorAction SilentlyContinue } catch {}
