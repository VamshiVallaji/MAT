﻿<#
.SYNOPSIS
  Collect Azure AD cloud-only object details using Connect-MgGraph with certificate auth.

.DESCRIPTION
  - Uses Connect-MgGraph -ClientId -TenantId -CertificateThumbprint (app-only, certificate auth).
  - Uses Invoke-MgGraphRequest to call Graph and page results.
  - Filters: users/groups where onPremisesSyncEnabled = false, devices with deviceTrustType = 'AzureAd'.
  - Outputs JSON + CSV per object type into OutFolder.

.PARAMETER TenantId
  Tenant Id or tenant domain.

.PARAMETER ClientId
  App (client) id.

.PARAMETER CertThumbprint
  Certificate thumbprint installed on the machine (used for app-only auth).

.PARAMETER OutFolder
  Output folder path.

.EXAMPLE
  .\Get-AAD-CloudOnly-WithCert-MgGraph.ps1 -TenantId contoso.onmicrosoft.com -ClientId <appId> -CertThumbprint ABCDEF... -OutFolder C:\Reports\AADCloudOnly
#>

$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutFolder = "$network_drive\Identity\AD_AzureADCloudOnlyobjectsdetails"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "Connecting to Microsoft Graph (app-only) using client secret..."

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null

# Helper: GET with paging using Invoke-MgGraphRequest
function Invoke-GraphGetAll {
  param([Parameter(Mandatory=$true)][string]$Uri)
  $all = @()
  $next = $Uri
  while ($next) {
    try {
      $resp = Invoke-MgGraphRequest -Method GET -Uri $next -ErrorAction Stop
    } catch {
      Write-Host ("Graph request failed for {0}: {1}" -f $next, $_.Exception.Message) -ForegroundColor Red
      throw
    }
    if ($resp -eq $null) { break }
    if ($resp.value) {
      $all += $resp.value
    } else {
      # single object fallback
      $all += ,$resp
    }
    $n = $null
    try { $n = $resp.'@odata.nextLink' } catch {}
    if ($n -and $n -ne "") { $next = $n } else { $next = $null }
  }
  return $all
}

# --- USERS (cloud-only = onPremisesSyncEnabled eq false) ---
Write-Host "Fetching users (cloud-only)..." -ForegroundColor Cyan
$usersUri = "https://graph.microsoft.com/v1.0/users?`$select=id,displayName,userPrincipalName,mail,onPremisesSyncEnabled,userType,accountEnabled,createdDateTime,jobTitle,department"
$allUsers = Invoke-GraphGetAll -Uri $usersUri
$cloudUsers = @()
if ($allUsers) {
  foreach ($u in $allUsers) {
    $sync = $false
    try { if ($null -ne $u.onPremisesSyncEnabled) { $sync = [bool]$u.onPremisesSyncEnabled } } catch {}
    $cloudUsers += $u
  }
}
$csvUsers = @()
foreach ($x in $cloudUsers) {
  $obj = New-Object PSObject
  $obj | Add-Member NoteProperty Id ($x.id)
  $obj | Add-Member NoteProperty DisplayName ($x.displayName)
  $obj | Add-Member NoteProperty UserPrincipalName ($x.userPrincipalName)
  $obj | Add-Member NoteProperty Mail ($x.mail)
  $obj | Add-Member NoteProperty UserType ($x.userType)
  $obj | Add-Member NoteProperty AccountEnabled ($x.accountEnabled)
  try {
    if ($null -ne $x.onPremisesSyncEnabled) {
        $syncFlag = [bool]$x.onPremisesSyncEnabled
    } else {
        $syncFlag = 'Unknown'
    }
} catch {
    $syncFlag = 'Unknown'
}
$obj | Add-Member NoteProperty OnPremisesSyncEnabled ($syncFlag)
$syncType = if ($syncFlag -eq $true) { 'OnPrem' } elseif ($syncFlag -eq $false) { 'Cloud' } else { 'Unknown' }
$obj | Add-Member NoteProperty SyncType ($syncType)
  $obj | Add-Member NoteProperty CreatedDateTime ($x.createdDateTime)
  $obj | Add-Member NoteProperty JobTitle ($x.jobTitle)
  $obj | Add-Member NoteProperty Department ($x.department)
  $csvUsers += $obj
}
try { $csvUsers | Export-Csv -Path $usersCsv -NoTypeInformation -Encoding UTF8 } catch { Write-Host "Failed write users CSV: $($_.Exception.Message)" -ForegroundColor Yellow }
Write-Host ("Users saved: {0} CSV: {1}" -f $csvUsers.Count, $usersCsv) -ForegroundColor Green

# --- GROUPS (cloud-only = onPremisesSyncEnabled eq false) ---
Write-Host "Fetching groups (cloud-only)..." -ForegroundColor Cyan
$groupsUri = "https://graph.microsoft.com/v1.0/groups?`$select=id,displayName,mail,mailEnabled,securityEnabled,groupTypes,createdDateTime,description,onPremisesSyncEnabled"
$allGroups = Invoke-GraphGetAll -Uri $groupsUri
$cloudGroups = @()
if ($allGroups) {
  foreach ($g in $allGroups) {
    $sync = $false
    try { if ($null -ne $g.onPremisesSyncEnabled) { $sync = [bool]$g.onPremisesSyncEnabled } } catch {}
    if (-not $sync) { $cloudGroups += $g }
  }
}
$groupsCsv = Join-Path $OutFolder "Groups_CloudOnly\Groups_CloudOnly_$timeStamp.csv"
$csvGroups = @()
foreach ($g in $cloudGroups) {
  # Precompute groupTypes string for PS5
  $grpTypes = ""
  try {
    if ($g.groupTypes -and $g.groupTypes.Count -gt 0) {
      $grpTypes = $g.groupTypes -join ";"
    }
  } catch { $grpTypes = "" }

  $obj = New-Object PSObject
  $obj | Add-Member NoteProperty Id ($g.id)
  $obj | Add-Member NoteProperty DisplayName ($g.displayName)
  $obj | Add-Member NoteProperty Mail ($g.mail)
  $obj | Add-Member NoteProperty MailEnabled ($g.mailEnabled)
  $obj | Add-Member NoteProperty SecurityEnabled ($g.securityEnabled)
  $obj | Add-Member NoteProperty GroupTypes ($grpTypes)
  $obj | Add-Member NoteProperty OnPremisesSyncEnabled ($g.onPremisesSyncEnabled)
  $obj | Add-Member NoteProperty CreatedDateTime ($g.createdDateTime)
  $obj | Add-Member NoteProperty Description ($g.description)
  $csvGroups += $obj
}
try { $csvGroups | Export-Csv -Path $groupsCsv -NoTypeInformation -Encoding UTF8 } catch { Write-Host "Failed write groups CSV: $($_.Exception.Message)" -ForegroundColor Yellow }
Write-Host ("Groups saved: {0} CSV: {1}" -f $csvGroups.Count, $groupsCsv) -ForegroundColor Green

# --- DEVICES (filter by deviceTrustType = 'AzureAd') ---
Write-Host "Fetching devices (AzureAd trust)..." -ForegroundColor Cyan
$devicesUri = "https://graph.microsoft.com/v1.0/devices?`$select=id,displayName,deviceId,deviceTrustType,operatingSystem,operatingSystemVersion,accountEnabled,approximateLastSignInDateTime"
$allDevices = Invoke-GraphGetAll -Uri $devicesUri
$cloudDevices = @()
if ($allDevices) {
  foreach ($d in $allDevices) {
    $trust = ""
    try { $trust = $d.deviceTrustType } catch {}
    if ($trust -and $trust -eq "AzureAd") { $cloudDevices += $d }
  }
}
$devicesCsv = Join-Path $OutFolder "Devices_CloudOnly\Devices_CloudOnly_$timeStamp.csv"
$csvDevices = @()
foreach ($d in $cloudDevices) {
  $obj = New-Object PSObject
  $obj | Add-Member NoteProperty Id ($d.id)
  $obj | Add-Member NoteProperty DisplayName ($d.displayName)
  $obj | Add-Member NoteProperty DeviceId ($d.deviceId)
  $obj | Add-Member NoteProperty DeviceTrustType ($d.deviceTrustType)
  $obj | Add-Member NoteProperty OperatingSystem ($d.operatingSystem)
  $obj | Add-Member NoteProperty OperatingSystemVersion ($d.operatingSystemVersion)
  $obj | Add-Member NoteProperty AccountEnabled ($d.accountEnabled)
  $obj | Add-Member NoteProperty ApproximateLastSignInDateTime ($d.approximateLastSignInDateTime)
  $csvDevices += $obj
}

if ($csvDevices.Count -eq 0) {
$csvDevices = [PSCustomObject]@{
Id = ""
DisplayName = ""
DeviceId = ""
DeviceTrustType = ""
OperatingSystem = ""
OperatingSytemVersion = ""
AccountEnabled = ""
ApproximateLastSignInDateTime = ""
}
}

try { $csvDevices | Export-Csv -Path $devicesCsv -NoTypeInformation -Encoding UTF8 } catch { Write-Host "Failed write devices CSV: $($_.Exception.Message)" -ForegroundColor Yellow }
Write-Host ("Devices saved: {0} CSV: {1}" -f $csvDevices.Count, $devicesCsv) -ForegroundColor Green

# --- SERVICE PRINCIPALS ---
Write-Host "Fetching service principals..." -ForegroundColor Cyan
$spsUri = "https://graph.microsoft.com/v1.0/servicePrincipals?`$select=id,displayName,appId,servicePrincipalType,accountEnabled,description,createdDateTime"
$allSPs = Invoke-GraphGetAll -Uri $spsUri
$spsCsv = Join-Path $OutFolder "ServicePrincipals\ServicePrincipals_$timeStamp.csv"
$csvSPs = @()
foreach ($s in $allSPs) {
  $obj = New-Object PSObject
  $obj | Add-Member NoteProperty Id ($s.id)
  $obj | Add-Member NoteProperty DisplayName ($s.displayName)
  $obj | Add-Member NoteProperty AppId ($s.appId)
  $obj | Add-Member NoteProperty ServicePrincipalType ($s.servicePrincipalType)
  $obj | Add-Member NoteProperty AccountEnabled ($s.accountEnabled)
  $obj | Add-Member NoteProperty CreatedDateTime ($s.createdDateTime)
  $obj | Add-Member NoteProperty Description ($s.description)
  $csvSPs += $obj
}
try { $csvSPs | Export-Csv -Path $spsCsv -NoTypeInformation -Encoding UTF8 } catch { Write-Host "Failed write SP CSV: $($_.Exception.Message)" -ForegroundColor Yellow }
Write-Host ("Service principals saved: {0} CSV: {1}" -f $csvSPs.Count, $spsCsv) -ForegroundColor Green

# Disconnect
try { Disconnect-MgGraph -ErrorAction SilentlyContinue } catch {}

Write-Host "Completed. Outputs in: $OutFolder" -ForegroundColor Magenta
$finalCsv = Join-Path $OutFolder "AAD_Users_Combined\AAD_Users_Combined_$timeStamp.csv"
$csvUsers | Export-Csv -Path $finalCsv -NoTypeInformation -Encoding UTF8
Write-Host ("Combined user report saved: {0} CSV: {1}" -f $csvUsers.Count, $finalCsv) -ForegroundColor Green
