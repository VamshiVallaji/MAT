﻿# Load config from network drive
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json

$TenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint

# Output folder and file
$OutFolder = "$network_drive\Identity\AzureAD_PremiumLicenseConfiguration"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$OutputFile = Join-Path $OutFolder "AzureAD_License_Report\AzureAD_License_Report_$timeStamp.csv"

# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Connect to Microsoft Graph
Write-Host "Connecting to Microsoft Graph..." -ForegroundColor Cyan
Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null
if (-not (Get-MgContext)) { throw "Failed to connect to Microsoft Graph." }

# Ensure output folder exists
if (-not (Test-Path $OutFolder)) { New-Item -Path $OutFolder -ItemType Directory | Out-Null }

# SKU ID to friendly name mapping
$skuMap = @{
    '6fd2c87f-b296-42f0-b197-1e91e994b900' = 'Microsoft 365 E3'
    'c7df6f57-2b1a-4f0c-bc31-3b6e1c6e5f7b' = 'Microsoft 365 E5'
    'f30db892-07e9-47e9-837c-80727f46fd3d' = 'Microsoft 365 F3'
    'c7d2f7f3-3f3b-4f0c-bc31-3b6e1c6e5f7b' = 'Business Premium'
    '078d2b04-f1bd-4111-bbd4-b4b1b354cef4' = 'Entra ID P1'
    '84a661c4-e949-4bd2-a560-ed7766fcaf2b' = 'Entra ID P2'
}

# Get all users
Write-Host "Retrieving all users..." -ForegroundColor Cyan
$allUsers = Get-MgUser -All -Property "id,displayName,userPrincipalName,accountEnabled,userType,usageLocation,onPremisesSyncEnabled"

$usersOut = @()
foreach ($u in $allUsers) {
    $friendlySkus = @()

    try {
        $licenseDetails = Get-MgUserLicenseDetail -UserId $u.Id -ErrorAction SilentlyContinue
        foreach ($ld in $licenseDetails) {
            $skuId = $ld.SkuId.ToString()
            if ($skuMap.ContainsKey($skuId)) {
                $friendlySkus += $skuMap[$skuId]
            } elseif ($ld.SkuPartNumber) {
                $friendlySkus += $ld.SkuPartNumber
            } else {
                $friendlySkus += $skuId
            }
        }
    } catch {
        Write-Warning "License detail fetch failed for user $($u.UserPrincipalName): $_"
    }

    $usersOut += [PSCustomObject]@{
        DisplayName           = $u.DisplayName
        UserPrincipalName     = $u.UserPrincipalName
        AccountEnabled        = $u.AccountEnabled
        UserType              = $u.UserType
        UsageLocation         = $u.UsageLocation
        OnPremisesSyncEnabled = $u.OnPremisesSyncEnabled
        AssignedLicenses      = ($friendlySkus -join "; ")
    }
}

# Export single CSV file
$usersOut | Export-Csv -Path $OutputFile -NoTypeInformation -Encoding UTF8
Write-Host "License report saved to: $OutputFile" -ForegroundColor Green

# Disconnect
try { Disconnect-MgGraph -Confirm:$false } catch {}
