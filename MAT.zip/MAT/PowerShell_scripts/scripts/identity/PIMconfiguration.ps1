﻿$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
   $JsonPath = "$network_drive\Config.json"
 
   $config = Get-Content $JsonPath | ConvertFrom-Json
 
   $TenantId = $config.TenantId
   $ClientId = $config.AppId
   $Thumbprint = $config.Thumbprint

# === Output ===
$OutFolder = "$network_drive\Identity\AD_PIMconfiguration"
$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")


# Ensure TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "Connecting to Microsoft Graph (app-only)..."
#$secureSecret = ConvertTo-SecureString $ClientSecret -AsPlainText -Force

Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome | Out-Null
#Select-MgProfile -Name "beta" -ErrorAction SilentlyContinue

# tiny safe getter
function G($o,$p){ if($null -eq $o){return $null}; if($o.PSObject.Properties.Match($p)){ return $o.$p } else { return $null } }

# endpoints (single-call, no paging)
$elig = Invoke-MgGraphRequest -Method GET -Uri 'https://graph.microsoft.com/beta/roleManagement/directory/roleEligibilitySchedules?$expand=principal,roleDefinition' -ErrorAction SilentlyContinue
$act = Invoke-MgGraphRequest -Method GET -Uri 'https://graph.microsoft.com/beta/roleManagement/directory/roleAssignmentSchedules?$expand=principal,roleDefinition' -ErrorAction SilentlyContinue

# build arrays defensively
$eligOut = @()
foreach ($i in @($elig.value)) {
  $eligOut += [pscustomobject]@{
    RoleName = (G (G $i 'roleDefinition') 'displayName') -as [string]
    PrincipalName = (G (G $i 'principal') 'displayName') -as [string]
    Start = (G $i 'createdDateTime')
    End = (G $i 'modifiedDateTime')
    Status = (G $i 'status') -as [string]
  }
}

$actOut = @()
foreach ($i in @($act.value)) {
  $actOut += [pscustomobject]@{
    RoleName = (G (G $i 'roleDefinition') 'displayName') -as [string]
    PrincipalName = (G (G $i 'principal') 'displayName') -as [string]
    Start = (G $i 'createdDateTime')
    End = (G $i 'modifiedDateTime')
    Status = (G $i 'status') -as [string]
  }
}

$eligOut | Export-Csv (Join-Path $OutFolder "PIM_Eligible_Simple\PIM_Eligible_Simple_$timeStamp.csv") -NoTypeInformation -Force
$actOut | Export-Csv (Join-Path $OutFolder "PIM_Active_Simple\PIM_Active_Simple_$timeStamp.csv") -NoTypeInformation -Force

Write-Host "Done. Files:" (Join-Path $OutFolder "PIM_Eligible_Simple\PIM_Eligible_Simple_$timeStamp.csv"), (Join-Path $OutFolder "PIM_Active_Simple\PIM_Active_Simple_$timeStamp.csv")

try { Disconnect-MgGraph -ErrorAction SilentlyContinue } catch {}