$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\Metadata_TermstoreReport\Metadata_Termstore_Report_$timestamp.csv"


# Initialize an array to hold term data
$termData = @()

# Get all term groups
$termGroups = Get-PnPTermGroup

foreach ($group in $termGroups) {
    $termSets = Get-PnPTermSet -TermGroup $group.Name

    foreach ($termSet in $termSets) {
        $terms = Get-PnPTerm -TermSet $termSet.Id -TermGroup $group.Name -Recursive
        foreach ($term in $terms) {
    # Reload term with properties hydrated
    $termFull = Get-PnPTerm -Identity $term.Id -TermSet $termSet.Id -TermGroup $group.Name -Includes Labels,CustomProperties,LocalCustomProperties

    $termData += [PSCustomObject]@{
        TermGroupName = $group.Name
        TermSetName = $termSet.Name
        TermSetId = $termSet.Id
        TermId = $termFull.Id
        TermName = $termFull.Name
        TermDescription = $termFull.Description
        TermLabels = if ($termFull.Labels) { ($termFull.Labels | ForEach-Object { $_.Name }) -join ";" } else { "" }
        TermCustomProperties = if ($termFull.CustomProperties) { ($termFull.CustomProperties.GetEnumerator() | ForEach-Object { "$($_.Key): $($_.Value)" }) -join ";" } else { "" }
        TermLocalCustomProps = if ($termFull.LocalCustomProperties) { ($termFull.LocalCustomProperties.GetEnumerator() | ForEach-Object { "$($_.Key): $($_.Value)" }) -join ";" } else { "" }
        TermPath = ($termFull.Path -join " > ")
        IsDeprecated = $termFull.IsDeprecated
        IsAvailableForTagging= $termFull.IsAvailableForTagging
        CreatedDate = $termFull.CreatedDate
        LastModifiedDate = $termFull.LastModifiedDate
    }
}

       
            
            }
    }
# Export to CSV
$termData | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8





