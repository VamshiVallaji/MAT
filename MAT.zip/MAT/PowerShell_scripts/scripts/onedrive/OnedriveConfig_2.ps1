#$ReportPath = "Z:\Onedrive\OnedriveConfigReport\PnP_OneDrive_Report_$(Get-Date -Format 'yyyyMMdd_HHmm').csv" 

$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" |
                 Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json

$TenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint
 
Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name
 
$TenantName = $Organization.Split(".")[0]
 
# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $TenantId `
    -Thumbprint $Thumbprint `

Write-Host "Connected successfully. Retrieving OneDrive site information..." -ForegroundColor Green

# ====== Get OneDrive Sites ======
$sites = Get-PnPTenantSite -IncludeOneDriveSites | Where-Object { $_.Template -like "SPSPERS*" }
 
# Create report
$report = foreach ($site in $sites) {
    [PSCustomObject]@{
        SiteUrl                  = $site.Url
        Owner                    = $site.Owner
        StorageUsageMB           = $site.StorageUsage
        SharingCapability        = $site.SharingCapability
        LastContentModified      = $site.LastContentModifiedDate
        LockState                = $site.LockState
        Status                   = $site.Status
        Template                 = $site.Template
        SensitivityLabel         = $site.SensitivityLabel
        IsHubSite                = $site.IsHubSite
        ExternalUserCount        = $site.ExternalUserCount
        ConditionalAccessPolicy  = $site.ConditionalAccessPolicy
        DefaultLinkPermission    = $site.DefaultLinkPermission
        DefaultSharingLinkType   = $site.DefaultSharingLinkType
    }
}
 
# Export to CSV
 
# ====== Export Report ======
$report | Export-Csv -Path $ReportPath -NoTypeInformation -Encoding UTF8

Write-Host "OneDrive configuration report generated successfully:" -ForegroundColor Green
Write-Host $ReportPath