﻿$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]


$CSVPath = "$network_drive\Onedrive\UnlicensedOnedriveAccounts\UnlicensedOneDriveAccounts_$timestamp.csv"


# Connect to SharePoint Admin
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint


  $unlicensedUsers = Get-MgUser `
  -Filter "assignedLicenses/`$count eq 0 and userType eq 'Member'" `
  -ConsistencyLevel eventual `
  -CountVariable __ignore `
  -All

# Get all OneDrive sites
$oneDriveSites = Get-PnPTenantSite -IncludeOneDriveSites

# Match OneDrive sites to unlicensed users
$results = @()
foreach ($site in $oneDriveSites) {
    $owner = $site.Owner
    $user = $unlicensedUsers | Where-Object { $_.UserPrincipalName -eq $owner }
    if ($user) {
        $results += [PSCustomObject]@{
            URL                      = $site.Url
            "Owner email"           = $owner
            "Storage used (GB)"     = [math]::Round($site.StorageUsageCurrent / 1024, 2)
            "Unlicensed due to"     = "License removed"
            "Deletion blocked by"   = $site.BlockedDeletionStatus
            "Unlicensed on"         = $site.LastContentModifiedDate
            "Deletion scheduled on" = ($site.LastContentModifiedDate).AddDays(93)
            "Account provisioned for (UPN)" = $owner
        }
    }
}

# Export to CSV
$results | Export-Csv -Path $CSVPath -NoTypeInformation
Write-Host "Report saved to $CSVPath"
