$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\Lookup_Column_Information\Lookup_Column_Information_$timestamp.csv"

# Get all site collections
$sites = Get-PnPTenantSite

# Prepare report
$lookupReport = @()

foreach ($site in $sites) {
    Write-Host "Scanning site: $($site.Url)" -ForegroundColor Cyan
    #Connect-PnPOnline -Url $site.Url -Interactive
    Connect-PnPOnline -Url $site.Url `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint

    $lists = Get-PnPList

    foreach ($list in $lists) {
        $fields = Get-PnPField -List $list.Title

        foreach ($field in $fields) {
            if ($field.TypeAsString -eq "Lookup") {
                # Resolve LookupList ID to actual list name
                $lookupListId = $field.LookupList
                $lookupListTitle = ""
                try {
                    $lookupTargetList = Get-PnPList | Where-Object { $_.Id.Guid -eq $lookupListId }
                    if ($lookupTargetList) {
                        $lookupListTitle = $lookupTargetList.Title
                    }
                } catch {
                    $lookupListTitle = "Unable to resolve"
                }

                # Parse projected fields from SchemaXml
                $schemaXml = [xml]$field.SchemaXml
                $projectedFields = @()
                foreach ($node in $schemaXml.Field.LookupField) {
                    $projectedFields += $node.InnerText
                }

                # Determine if it's a site column
                $isSiteColumn = $field.Scope -eq "/"

                # Add to report
                $lookupReport += [PSCustomObject]@{
                    SiteUrl             = $site.Url
                    SiteTitle           = $site.Title
                    ListTitle           = $list.Title
                    FieldDisplayName    = $field.Title
                    FieldInternalName   = $field.InternalName
                    LookupListId        = $lookupListId
                    LookupListTitle     = $lookupListTitle
                    LookupField         = $field.LookupField
                    ProjectedFields     = ($projectedFields -join ", ")
                    IsMultiValue        = $field.AllowMultipleValues
                    IsRequired          = $field.Required
                    Hidden              = $field.Hidden
                    ReadOnly            = $field.ReadOnlyField
                    IsSiteColumn        = $isSiteColumn
                    Group               = $field.Group
                    StaticName          = $field.StaticName
                }
            }
        }
    }
}

# Output to console
#$lookupReport | Format-Table -AutoSize

# Optional: Export to CSV
$lookupReport | Export-Csv -Path $reportPath -NoTypeInformation






