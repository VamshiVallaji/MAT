$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\SiteCollectionsEnabledAppCatalog\SiteCollectionsEnabledAppCatalog_$timestamp.csv"


# Get all site collections
$sites = Get-PnPTenantSite

# Prepare output array
$report = @()

foreach ($site in $sites) {
    Write-Host "?? Checking site: $($site.Url)" -ForegroundColor Cyan

    $appCatalogEnabled = $false
    $appCatalogUrl = ""

    try {
        # Connect to each site
        Connect-PnPOnline -Url $site.Url -ClientId $ClientId -Tenant $tenantId -Thumbprint $Thumbprint
        #Connect-PnPOnline -Url $site.Url -Interactive

        # Check for Site Collection App Catalog
        $appCatalog = Get-PnPSiteCollectionAppCatalog
        if ($appCatalog) {
            $appCatalogEnabled = $true
            $appCatalogUrl = $appCatalog.Url
        }
    } catch {
        Write-Warning "?? Could not check App Catalog for site: $($site.Url)"
    }

    # Add site info to report
    $report += [PSCustomObject]@{
        SiteUrl             = $site.Url
        Title               = $site.Title
        Template            = $site.Template
        Owner               = $site.Owner
        StorageUsageMB      = $site.StorageUsage
        TimeZoneId          = $site.TimeZoneId
        LastContentModified = $site.LastContentModifiedDate
        LockState           = $site.LockState
        AppCatalogEnabled   = $appCatalogEnabled
        AppCatalogUrl       = $appCatalogUrl
    }
}

# Export to CSV
$report | Export-Csv -Path $reportPath -NoTypeInformation

Write-Host "? Report generated: SiteCollections_AppCatalogReport_$timestamp.csv"




