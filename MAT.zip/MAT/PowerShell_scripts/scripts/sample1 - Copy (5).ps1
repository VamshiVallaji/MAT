$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\SiteCollections_CustomSPFxApps\SiteCollections_CustomSPFxApps_$timestamp.csv"


# Get all site collections
$sites = Get-PnPTenantSite

# Prepare output array
$report = @()

foreach ($site in $sites) {
    Write-Host "?? Checking site: $($site.Url)" -ForegroundColor Cyan

    try {
        # Connect to site
        #Connect-PnPOnline -Url $site.Url -Interactive
        Connect-PnPOnline -Url $site.Url -ClientId $ClientId -Tenant $tenantId -Thumbprint $Thumbprint


        # Check if Site Collection App Catalog is enabled
        $appCatalog = Get-PnPSiteCollectionAppCatalog
        if ($appCatalog) {
            # Get apps in the site collection app catalog
            $apps = Get-PnPApp -Scope Site

            if ($apps.Count -eq 0) {
                # Add empty entry for site with no apps
                $report += [PSCustomObject]@{
                    SiteUrl         = $site.Url
                    SiteTitle       = $site.Title
                    AppTitle        = ""
                    AppId           = ""
                    AppVersion      = ""
                    AppPublisher    = ""
                    AppDeployed     = ""
                    AppEnabled      = ""
                    AppIsClientSide = ""
                    AppCatalogUrl   = $appCatalog.Url
                    StorageUsageMB  = $site.StorageUsage
                    Owner           = $site.Owner
                    Template        = $site.Template
                    LastModified    = $site.LastContentModifiedDate
                }
            } else {
                foreach ($app in $apps) {
                    # Filter for custom apps (non-Microsoft)
                    if ($app.Publisher -ne "Microsoft Corporation") {
                        $report += [PSCustomObject]@{
                            SiteUrl         = $site.Url
                            SiteTitle       = $site.Title
                            AppTitle        = $app.Title
                            AppId           = $app.Id
                            AppVersion      = $app.Version
                            AppPublisher    = $app.Publisher
                            AppDeployed     = $app.Deployed
                            AppEnabled      = $app.Enabled
                            AppIsClientSide = $app.IsClientSideSolution
                            AppCatalogUrl   = $appCatalog.Url
                            StorageUsageMB  = $site.StorageUsage
                            Owner           = $site.Owner
                            Template        = $site.Template
                            LastModified    = $site.LastContentModifiedDate
                        }
                    }
                }
            }
        } else {
            # Add entry for site with no app catalog
            $report += [PSCustomObject]@{
                SiteUrl         = $site.Url
                SiteTitle       = $site.Title
                AppTitle        = ""
                AppId           = ""
                AppVersion      = ""
                AppPublisher    = ""
                AppDeployed     = ""
                AppEnabled      = ""
                AppIsClientSide = ""
                AppCatalogUrl   = ""
                StorageUsageMB  = $site.StorageUsage
                Owner           = $site.Owner
                Template        = $site.Template
                LastModified    = $site.LastContentModifiedDate
            }
        }
    } catch {
        Write-Warning "?? Failed to check site or app catalog: $($site.Url)"
    }
}

# Export to CSV
$report | Export-Csv -Path $reportPath -NoTypeInformation

Write-Host "? Report generated: SiteCollections_CustomSPFxApps_$timestamp.csv"




