$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\OrphanedUsers_DisabledInAD\OrphanedUsers_DisabledinAD_Report_$timestamp.csv"




# Initialize report
$report = @()
$sites = Get-PnPTenantSite -IncludeOneDriveSites:$false -Detailed

foreach ($site in $sites) {
    Write-Host "?? Scanning site: $($site.Url)" -ForegroundColor Cyan
    try {
        Connect-PnPOnline -Url $site.Url `
        -ClientId $ClientId `
        -Tenant $tenantId `
        -Thumbprint $Thumbprint

        $users = Get-PnPUser

        foreach ($user in $users) {
            $login = $user.LoginName
            $isOrphaned = $false
            $graphUser = $null

            try {
                # Normalize login name
                $upn = $login -replace "i:0#.f|membership|", ""
                $graphUser = Get-MgUser -UserId $upn -ErrorAction Stop

                if ($graphUser.AccountEnabled -eq $false) {
                    $isOrphaned = $true
                }
            } catch {
                # User not found in Graph (deleted or external)
                $isOrphaned = $true
            }

            if ($isOrphaned) {
                $report += [PSCustomObject]@{
                    SiteUrl        = $site.Url
                    UserLogin      = $login
                    DisplayName    = $user.Title
                    Email          = $user.Email
                    IsSiteAdmin    = $user.IsSiteAdmin
                    PrincipalType  = $user.PrincipalType
                    IsOrphaned     = "Yes"
                    UserType       = if ($graphUser) { $graphUser.UserType } else { "Unknown" }
                    LastDirSync    = if ($graphUser) { $graphUser.OnPremisesLastSyncDateTime } else { "N/A" }
                }
            }
        }
    } catch {
        Write-Warning "?? Failed to process site: $($site.Url)"
    }
}

# Export to CSV
$report | Export-Csv -Path $reportPath -NoTypeInformation
Write-Host "? Report saved: OrphanedUsers_Report.csv -ForegroundColor Green"
