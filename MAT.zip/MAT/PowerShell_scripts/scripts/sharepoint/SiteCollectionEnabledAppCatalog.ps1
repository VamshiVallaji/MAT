$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\SiteCollectionsEnabledAppCatalog\SiteCollectionsEnabledAppCatalog_$timestamp.csv"

# Get all sites with Site Collection App Catalogs
$appCatalogSites = Get-PnPSiteCollectionAppCatalog

# Prepare output array
$report = @()

foreach ($appCatalog in $appCatalogSites) {
    $siteUrl = $appCatalog.AbsoluteUrl

    Write-Host "?? Found App Catalog at: $siteUrl" -ForegroundColor Cyan

    try {
        # Connect to the site to fetch additional details
        Connect-PnPOnline -Url $siteUrl -ClientId $ClientId -Tenant $tenantId -Thumbprint $Thumbprint
        #Connect-PnPOnline -Url $siteUrl -Interactive

        $site = Get-PnPTenantSite -Url $siteUrl

        # Add site info to report
        $report += [PSCustomObject]@{
            SiteUrl             = $site.Url
            Title               = $site.Title
            Template            = $site.Template
            Owner               = $site.Owner
            StorageUsageMB      = $site.StorageUsage
            TimeZoneId          = $site.TimeZoneId
            LastContentModified = $site.LastContentModifiedDate
            LockState           = $site.LockState
            AppCatalogEnabled   = $true
            AppCatalogUrl       = $siteUrl
        }
    } catch {
        Write-Warning "?? Could not retrieve details for site: $siteUrl"
    }
}

# Export to CSV
$report | Export-Csv -Path $reportPath -NoTypeInformation

Write-Host "? Report generated: SiteCollections_AppCatalogReport_$timestamp.csv"
