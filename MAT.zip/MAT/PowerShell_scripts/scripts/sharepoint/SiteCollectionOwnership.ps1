$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\SiteCollectionOwnership\SiteCollectionOwnership_Report_$timestamp.csv"


$sites = Get-PnPTenantSite -IncludeOneDriveSites:$false

$report = @()
foreach ($site in $sites) {
    Write-Host "Processing: $($site.Url)" -ForegroundColor Cyan

    try {
        # Connect to the site
        Connect-PnPOnline -Url $site.Url `
            -ClientId $ClientId `
            -Tenant $tenantId `
            -Thumbprint $Thumbprint
        # Get site admins (true SharePoint Owners)
        $admins = Get-PnPSiteCollectionAdmin

        $ownersGroup = Get-PnPGroup -AssociatedOwnerGroup
        $groupMembers = Get-PnPGroupMember -Identity $ownersGroup

      #  $hubSites = Get-PnPHubSite

        $hubInfo = Get-PnPHubSite -Identity $site.Url -ErrorAction SilentlyContinue
        $isHubSite = ($hubInfo.SiteId -ne $null -and $hubInfo.SiteId -ne "")



        # Normalize hub site URLs
        #$hubSiteUrls = $hubSites | ForEach-Object { $_.SiteUrl.TrimEnd("/").ToLower() }

        # Then in your loop:
        #$currentSiteUrl = $site.Url.TrimEnd("/").ToLower()
        #$isHubSite = $hubSiteUrls -contains $currentSiteUrl
        #Write-Host "Checking site: $($site.Url)"
        #Write-Host "Normalized: $currentSiteUrl"
        #Write-Host "IsHubSite: $isHubSite"


        # Add one row per site, with multiple owners joined
        $report += [PSCustomObject]@{
            SiteUrl = $site.Url
            Title = $site.Title
            Template = $site.Template
            TemplateName = $site.TemplateName
            StorageQuotaMB = $site.StorageQuota
            StorageUsedMB = $site.StorageUsageCurrent
            LastContentModified = $site.LastContentModifiedDate
            IsHubSite = $isHubSite
            HubSiteId = $site.HubSiteId
            SharingCapability = $site.SharingCapability
            ExternalSharing = $site.SharingAllowedDomainList
            LockState = $site.LockState
            SiteStatus = $site.Status
            TimeZoneId = $site.TimeZoneId
            LocaleId = $site.LocaleId

            # admin-specific details
            AdminNames = ($admins.Title -join ";")
            AdminUPNs = ($admins.Email -join ";")
            AdminCount = $admins.Count

            #owner-specific details
            OwnerNames = ($groupMembers.Title -join ";")
            OwnerUPNs = ($groupMembers.Email -join ";")
            OwnerCount = $groupMembers.Count

        }
    }
    catch {
        Write-Host "Error processing $($site.Url): $_" -ForegroundColor Red
    }
}

    
# Export to CSV
$report | Export-Csv -Path $reportPath -NoTypeInformation




