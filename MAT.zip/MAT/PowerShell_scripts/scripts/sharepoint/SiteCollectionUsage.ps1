$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]


$reportPath = "$network_drive\Sharepoint\SiteCollectionUsage\SiteCollectionUsage_Report_$timestamp.csv"

Get-MgReportSharePointSiteUsageDetail -Period D30 -OutFile $reportPath


Write-Host "Sharepoint site usage report saved to $reportPath"





