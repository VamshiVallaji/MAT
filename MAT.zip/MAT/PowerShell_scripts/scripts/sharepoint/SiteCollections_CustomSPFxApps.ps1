$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\SiteCollections_CustomSPFxApps\SiteCollections_CustomSPFxApps_$timestamp.csv"


# Get all sites with Site Collection App Catalogs
$appCatalogSites = Get-PnPSiteCollectionAppCatalog

# Initialize report array
$report = @()

foreach ($appCatalog in $appCatalogSites) {
    $siteUrl = $appCatalog.AbsoluteUrl

    Write-Host "?? Checking App Catalog site: $siteUrl" -ForegroundColor Cyan

    try {
        # Connect to the site
        Connect-PnPOnline -Url $siteUrl -ClientId $ClientId -Tenant $tenantId -Thumbprint $Thumbprint

        # Get apps deployed to the site
        $apps = Get-PnPApp -Scope Site

        # Get site metadata
        $site = Get-PnPTenantSite -Url $siteUrl

            foreach ($app in $apps) {
                if ($app.Publisher -ne "Microsoft Corporation") {
                    $report += [PSCustomObject]@{
                        SiteUrl         = $site.Url
                        SiteTitle       = $site.Title
                        AppTitle        = $app.Title
                        AppId           = $app.Id
                        AppVersion      = $app.Version
                        AppPublisher    = $app.Publisher
                        AppDeployed     = $app.Deployed
                        AppEnabled      = $app.Enabled
                        AppIsClientSide = $app.IsClientSideSolution
                        AppCatalogUrl   = $siteUrl
                        StorageUsageMB  = $site.StorageUsage
                        Owner           = $site.Owner
                        Template        = $site.Template
                        LastModified    = $site.LastContentModifiedDate
                    }
                }
            }
    } catch {
        Write-Warning "?? Failed to process site: $siteUrl"
    }
}




# Export to CSV
$report | Export-Csv -Path $reportPath -NoTypeInformation

Write-Host "? Report generated: SiteCollections_CustomSPFxApps_$timestamp.csv"




