$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\Site_User-Group_highlevelPermissions\SiteUser-Group_Permissions_Report_$timestamp.csv"





$results = @()

# Get all site collections (excluding OneDrive)
$sites = Get-PnPTenantSite -IncludeOneDriveSites:$false

foreach ($site in $sites) {
    Write-Host "Processing site: $($site.Url)" -ForegroundColor Cyan
    try {
        # Connect to each site
        #Connect-PnPOnline -Url $site.Url -UseWebLogin
        Connect-PnPOnline -Url $site.Url `
        -ClientId $ClientId `
        -Tenant $tenantId `
        -Thumbprint $Thumbprint

        # Get web + subsites
        $webs = Get-PnPSubWeb -Recurse
        $webs += Get-PnPWeb

        foreach ($web in $webs) {
            Write-Host " Checking web: $($web.Url)" -ForegroundColor Yellow
            
            # Get role assignments on web
            $webObj = Get-PnPWeb -Identity $web
            $webObj = Get-PnPProperty -ClientObject $webObj -Property RoleAssignments
            foreach ($ra in $webObj.RoleAssignments) {
                $ra = Get-PnPProperty -ClientObject $ra -Property Member, RoleDefinitionBindings
                $principal = $ra.Member
                $roles = ($ra.RoleDefinitionBindings | ForEach-Object { $_.Name }) -join ";"

                $results += [PSCustomObject]@{
                    SiteUrl = $site.Url
                    WebUrl = $web.Url
                    ObjectType = "Site/Web"
                    ObjectName = $web.Title
                    Principal = $principal.LoginName
                    PrincipalType = $principal.PrincipalType
                    Roles = $roles
                }
            }

            # Lists/libraries with unique permissions (?? no -Web here)
            $lists = Get-PnPList | Where-Object { $_.HasUniqueRoleAssignments -eq $true }
            foreach ($list in $lists) {
                $listObj = Get-PnPList -Identity $list
                $listObj = Get-PnPProperty -ClientObject $listObj -Property RoleAssignments
                foreach ($ra in $listObj.RoleAssignments) {
                    $ra = Get-PnPProperty -ClientObject $ra -Property Member, RoleDefinitionBindings
                    $principal = $ra.Member
                    $roles = ($ra.RoleDefinitionBindings | ForEach-Object { $_.Name }) -join ";"

                    $results += [PSCustomObject]@{
                        SiteUrl = $site.Url
                        WebUrl = $web.Url
                        ObjectType = "List/Library"
                        ObjectName = $list.Title
                        Principal = $principal.LoginName
                        PrincipalType = $principal.PrincipalType
                        Roles = $roles
                    }
                }
            }

            # ?? Optional: Item-level permissions (can be very heavy)
            <#
            foreach ($list in $lists) {
                $items = Get-PnPListItem -List $list -PageSize 1000
                foreach ($item in $items) {
                    if ($item.HasUniqueRoleAssignments) {
                        $itemObj = Get-PnPProperty -ClientObject $item -Property RoleAssignments
                        foreach ($ra in $itemObj.RoleAssignments) {
                            $ra = Get-PnPProperty -ClientObject $ra -Property Member, RoleDefinitionBindings
                            $principal = $ra.Member
                            $roles = ($ra.RoleDefinitionBindings | ForEach-Object { $_.Name }) -join ";"

                            $results += [PSCustomObject]@{
                                SiteUrl = $site.Url
                                WebUrl = $web.Url
                                ObjectType = "ListItem"
                                ObjectName = $item["FileLeafRef"]
                                Principal = $principal.LoginName
                                PrincipalType = $principal.PrincipalType
                                Roles = $roles
                            }
                        }
                    }
                }
            }
            #>
        }
    }
    catch {
        Write-Host "Failed on $($site.Url): $_" -ForegroundColor Red
    }
}


# Export report
if ($results.Count -gt 0) {
    $results | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8
    Write-Host "Report generated: $reportPath" -ForegroundColor Green
} else {
    # Empty report structure
    [PSCustomObject]@{
        SiteUrl = ""
        WebUrl = ""
        ObjectType = ""
        ObjectName = ""
        Principal = ""
        PrincipalType = ""
        Roles = ""
    } | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8
    Write-Host "No permissions found, exported empty report." -ForegroundColor Yellow
}




