$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint
$secret = $config.AppSecret
#$username = "VamshiV@M365x95823790.onmicrosoft.com"

Add-PowerAppsAccount -TenantId $tenantId -ApplicationId $ClientId -ClientSecret $secret


#$cert = Get-Item "Cert:\CurrentUser\My\$Thumbprint"


#Connect-PowerPlatform -ApplicationId $ClientId -Tenant $tenantId -Certificate $cert -UserName $username


#Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
#$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

#$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
#Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
 #   -ClientId $ClientId `
  #  -Tenant $tenantId `
   # -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\TenantLevel_PowerApps\TenantLevel_PowerApps_Report_$timestamp.csv"


$apps = Get-AdminPowerApp

if (-not $apps -or $apps.Count -eq 0) {
    Write-Warning "No PowerApps found or insufficient permissions."
    exit
}

$report = foreach ($app in $apps) {
    # Get sharing permissions for each app
    try {
        $permissions = Get-AdminPowerAppRoleAssignment -AppName $app.AppName -EnvironmentName $app.EnvironmentName
        $sharedWith = ($permissions | Select-Object -ExpandProperty PrincipalObjectId) -join ";"
    } catch {
        $sharedWith = "Error/NoAccess"
    }

    # Build report row
    [PSCustomObject]@{
        DisplayName = $app.DisplayName
        AppName = $app.AppName
        EnvironmentName = $app.EnvironmentName
        AppFamily = $app.AppFamily
        AppVersion = $app.AppVersion
        Publisher = $app.Publisher
        Owner = $app.Owner
        CreatedTime = $app.CreatedTime
        LastModifiedTime = $app.LastModifiedTime
        IsFeaturedApp = $app.IsFeaturedApp
        IsHeroApp = $app.IsHeroApp
        ConsentStatus = $app.ConsentStatus
        IsOnAdminApprovedList = $app.IsOnAdminApprovedList
        SharedWith = $sharedWith
    }
}

# --- Export report ---
$report | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "Full PowerApps report generated: $reportPath" -ForegroundColor Green




