$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint



Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $Thumbprint -NoWelcome
$Organization = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.isInitial -eq $true } | Select-Object -ExpandProperty Name

$TenantName = $Organization.Split(".")[0]



# Connect using app-only authentication
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint 

# Connect to Exchange Online
#Connect-ExchangeOnline -CertificateThumbprint $Thumbprint -AppId $ClientId -Organization $Organization

$reportPath = "$network_drive\Sharepoint\WSP-APP_CatalogReport\WSP-APP_Catalog_Report_$timestamp.csv"


# Get all site collections
$Sites = Get-PnPTenantSite -IncludeOneDriveSites:$false

foreach ($Site in $Sites) {
    Write-Host "Adding $User as Site Collection Admin to $($Site.Url)" -ForegroundColor Cyan
    
    Set-PnPTenantSite -Url $Site.Url -Owners $User
}


$report = @()

# ======= TENANT APP CATALOG =======
$tenantAppCatalogUrl = Get-PnPTenantAppCatalogUrl
if ($tenantAppCatalogUrl) {
    Write-Host "Tenant App Catalog found: $tenantAppCatalogUrl" -ForegroundColor Green
    Connect-PnPOnline -Url $tenantAppCatalogUrl `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint
    $tenantApps = Get-PnPApp -Scope Tenant -ErrorAction SilentlyContinue

    foreach ($app in $tenantApps) {
        $report += [PSCustomObject]@{
            Scope = "Tenant"
            AppCatalogUrl = $tenantAppCatalogUrl
            ID = $app.Id
            Title = $app.Title
            InternalName = $app.Name
            Version = $app.AppVersion
            Deployed = $app.Deployed
            Enabled = $app.Enabled
            AppCatalogType = "Tenant App Catalog"
        }
    }
} else {
    Write-Host "No Tenant App Catalog found" -ForegroundColor Yellow
}

# ======= SITE COLLECTION APP CATALOGS =======
Connect-PnPOnline -Url "https://$TenantName-admin.sharepoint.com" `
    -ClientId $ClientId `
    -Tenant $tenantId `
    -Thumbprint $Thumbprint
$siteAppCatalogs = Get-PnPSiteCollectionAppCatalog -ErrorAction SilentlyContinue
##extract the site appcatalog to another report like site collections enabled with app catalog
if ($siteAppCatalogs) {
    foreach ($site in $siteAppCatalogs.SiteCollectionAppCatalogs.Url) {
        Write-Host "Checking Site Collection App Catalog: $site" -ForegroundColor Cyan
        Connect-PnPOnline -Url $Site `
        -ClientId $ClientId `
        -Tenant $tenantId `
        -Thumbprint $Thumbprint
        $siteApps = Get-PnPApp -Scope Site -ErrorAction SilentlyContinue

        foreach ($app in $siteApps) {
            $report += [PSCustomObject]@{
                Scope = "SiteCollection"
                AppCatalogUrl = $site
                ID = $app.Id
                Title = $app.Title
                InternalName = $app.Name
                Version = $app.AppVersion
                Deployed = $app.Deployed
                Enabled = $app.Enabled
                AppCatalogType = "Site Collection App Catalog"
            }
        }
    }
} else {
    Write-Host "No Site Collection App Catalogs found" -ForegroundColor Yellow
}

# ======= HANDLE EMPTY CASE =======
if (-not $report -or $report.Count -eq 0) {
    Write-Host "No apps found. Creating empty report with headers..." -ForegroundColor Yellow
    $report = [PSCustomObject]@{
        Scope = ""
        AppCatalogUrl = ""
        ID = ""
        Title = ""
        InternalName = ""
        Version = ""
        Deployed = ""
        Enabled = ""
        AppCatalogType = ""
    }
}

# ======= EXPORT =======
$report | Export-Csv -Path $reportPath -NoTypeInformation -Force
Write-Host "Report exported to $reportPath" -ForegroundColor Green




