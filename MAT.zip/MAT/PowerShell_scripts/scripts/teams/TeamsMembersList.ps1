$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome


$reportPath = "$network_drive\Teams\TeamsMembersList\TeamsMembersList_$timestamp.csv"


# Get all Teams
$teams = Get-MgGroup -All -Filter "resourceProvisioningOptions/Any(x:x eq 'Team')"

$report = @()

foreach ($team in $teams) {
    try {
        # Get members of this Team
        $members = Get-MgTeamMember -TeamId $team.Id -All -ErrorAction Stop

        foreach ($member in $members) {
       
       $report += [PSCustomObject]@{
        TeamName          = $team.DisplayName
        TeamId            = $team.Id
        TeamVisibility    = $team.Visibility
        MemberName        = $member.DisplayName
        MemberId          = $member.Id
        Role              = if ($member.Roles.Count -gt 0) { $member.Roles -join "," } else { "Member" }
       }
     }

    }
    catch {
        Write-Warning "?? Could not fetch members for Team: $($team.DisplayName) ($($team.Id))"
    }
}

# If no members found at all, still create CSV with headers
if ($report.Count -eq 0) {
    $report += [PSCustomObject]@{
        TeamName          = ""
        TeamId            = ""
        TeamVisibility    = ""
        MemberName        = ""
        MemberId          = ""
        Role              = ""
    }
}

# Save report to CSV
#$csvPath = "$env:USERPROFILE\Desktop\Teams_Members_List_$(Get-Date -Format 'dd-MM-yyyy').csv"
$report | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "?? Teams members report saved to: $reportPath" -ForegroundColor Cyan
