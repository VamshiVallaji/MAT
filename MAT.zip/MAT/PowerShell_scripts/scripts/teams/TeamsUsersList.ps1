$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome


$reportPath = "$network_drive\Teams\TeamsUsersList\TeamsUsersList_$timestamp.csv"


# Get all users (you can filter later for Teams-licensed users)
$users = Get-MgUser -All -Property `
    "id",
    "displayName",
    "userPrincipalName",
    "mail",
    "givenName",
    "surname",
    "jobTitle",
    "department",
    "companyName",
    "mobilePhone",
    "officeLocation",
    "businessPhones",
    "preferredLanguage",
    "accountEnabled",
    "createdDateTime",
    "assignedLicenses",
    "assignedPlans",
    "city",
    "country",
    "state",
    "postalCode",
    "streetAddress",
    "employeeId",
    "employeeType",
    "employeeHireDate",
    "employeeLeaveDateTime",
    "userType",
    "userState",
    "userStateChangedOn",
    "usageLocation",
    "onPremisesSamAccountName",
    "onPremisesSecurityIdentifier",
    "onPremisesSyncEnabled",
    "signInActivity",
    "manager"

# Optional: filter users with Teams service plan
$teamsUsers = $users | Where-Object {
    $_.AssignedPlans.Service -contains "MicrosoftCommunicationsOnline"
}
# Output total count
Write-Host "Total Teams Users: $($teamsUsers.Count)"

# Export full details to CSV
$teamsUsers | Select-Object `
    Id,
    DisplayName,
    UserPrincipalName,
    Mail,
    GivenName,
    Surname,
    JobTitle,
    Department,
    CompanyName,
    MobilePhone,
    @{Name="BusinessPhones";Expression={($_.BusinessPhones -join "; ")}},
    OfficeLocation,
    PreferredLanguage,
    AccountEnabled,
    CreatedDateTime,
    City,
    State,
    Country,
    PostalCode,
    StreetAddress,
    EmployeeId,
    EmployeeType,
    EmployeeHireDate,
    EmployeeLeaveDateTime,
    UserType,
    UserState,
    UserStateChangedOn,
    UsageLocation,
    OnPremisesSamAccountName,
    OnPremisesSecurityIdentifier,
    OnPremisesSyncEnabled | Export-Csv -Path $reportPath -NoTypeInformation




Write-Host "Teams users List report saved to $reportPath"




