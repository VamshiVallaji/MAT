$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint

Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome

$reportPath = "$network_drive\Teams\Teams_DataSize_and_Storage\Teams_DataSize_and_Storage_$timestamp.csv"




# Get all Teams (Groups with resourceProvisioningOptions eq 'Team')
$teams = Get-MgGroup -Filter "resourceProvisioningOptions/Any(x:x eq 'Team')" -All

$report = @()

foreach ($team in $teams) {
    Write-Host "Fetching info for $($team.DisplayName)..."

    
    # Get Owners (force extract DisplayName or UPN from AdditionalProperties)
    $owners = (Get-MgGroupOwner -GroupId $team.Id -All |
    ForEach-Object {
        if ($_.AdditionalProperties['@odata.type'] -eq "#microsoft.graph.user") {
            # Prefer DisplayName if available, else fall back to UserPrincipalName
            if ($_.AdditionalProperties['displayName']) {
                $_.AdditionalProperties['displayName']
            }
            elseif ($_.AdditionalProperties['userPrincipalName']) {
                $_.AdditionalProperties['userPrincipalName']
            }
        }
    }) -join ", "


    # Get linked SharePoint site (where storage is tracked)
    $site = Get-MgGroupSite -GroupId $team.Id | Select-Object -First 1

    $storageUsedMB = 0
    $storageAllocatedMB = 0
    $siteUrl = ""

    if ($site) {
        try {
            # Fetch site details including quota
            $siteDetails = Get-MgSite -SiteId $site.Id
            $siteUrl = $siteDetails.WebUrl

            # Storage info (quota info comes under drives)
            $drive = Get-MgSiteDrive -SiteId $site.Id
            if ($drive.Quota) {
                $storageUsedMB = [math]::Round(($drive.Quota.Used / 1MB),2)
                $storageAllocatedMB = [math]::Round(($drive.Quota.Total / 1MB),2)
            }
        }
        catch {
            Write-Warning "Could not fetch storage info for site $($site.Id)"
        }
    }

    # Add to report
    $report += [PSCustomObject]@{
        TeamName = $team.DisplayName
        TeamId = $team.Id
        Description = $team.Description
        Visibility = $team.Visibility
        CreatedDateTime = $team.CreatedDateTime
        Owners = $owners
        SiteUrl = $siteUrl
        StorageUsedMB = $storageUsedMB
        StorageAllocatedMB= $storageAllocatedMB
    }
}

# Export to CSV

$report | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "Report generated successfully at: $reportPath"
