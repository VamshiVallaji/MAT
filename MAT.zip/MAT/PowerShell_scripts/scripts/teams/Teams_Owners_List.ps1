$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint

Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome

$reportPath = "$network_drive\Teams\Teams_Owners_List\Teams_Owners_List_$timestamp.csv"

# Get all Teams (M365 Groups with Team provisioned)
$teams = Get-MgGroup -Filter "resourceProvisioningOptions/Any(x:x eq 'Team')" -All

$report = @()

foreach ($team in $teams) {
    Write-Host "Fetching owners for Team: $($team.DisplayName)"

    # Get Owners
    $owners = Get-MgGroupOwner -GroupId $team.Id -All |
        ForEach-Object {
            $ownerType = $_.AdditionalProperties['@odata.type']
            
            if ($ownerType -eq "#microsoft.graph.user") {
                [PSCustomObject]@{
                    TeamName = $team.DisplayName
                    TeamId = $team.Id
                    Visibility = $team.Visibility
                    CreatedDateTime = $team.CreatedDateTime
                    Description = $team.Description
                    OwnerDisplayName = $_.AdditionalProperties['displayName']
                    OwnerUPN = $_.AdditionalProperties['userPrincipalName']
                    OwnerType = "User"
                }
            }
            else {
                [PSCustomObject]@{
                    TeamName = $team.DisplayName
                    TeamId = $team.Id
                    Visibility = $team.Visibility
                    CreatedDateTime = $team.CreatedDateTime
                    Description = $team.Description
                    OwnerDisplayName = $_.AdditionalProperties['displayName']
                    OwnerUPN = ""
                    OwnerType = $ownerType.Replace("#microsoft.graph.", "")
                }
            }
        }

    # Handle Teams with no owners (shouldn't normally happen, but possible)
    if (-not $owners) {
        $owners = [PSCustomObject]@{
            TeamName = $team.DisplayName
            TeamId = $team.Id
            Visibility = $team.Visibility
            CreatedDateTime = $team.CreatedDateTime
            Description = $team.Description
            OwnerDisplayName = "None"
            OwnerUPN = "None"
            OwnerType = "None"
        }
    }

    $report += $owners
}

# Export report
#$csvPath = "$env:USERPROFILE\Desktop\TeamsOwnersReport_Extended.csv"
$report | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "? Teams Owners Report saved to: $reportPath"


