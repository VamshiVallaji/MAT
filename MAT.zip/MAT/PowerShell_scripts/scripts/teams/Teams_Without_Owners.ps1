$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID
$JsonPath = "$network_drive\Config.json"
$config = Get-Content $JsonPath | ConvertFrom-Json
$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint

Connect-MgGraph -TenantId $tenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome

$reportPath = "$network_drive\Teams\Teams_Without_Owners\Teams_Without_Owners_$timestamp.csv"

# Get all Teams
$teams = Get-MgGroup -All -Filter "resourceProvisioningOptions/Any(x:x eq 'Team')"

# Define headers explicitly (ensures CSV never comes out blank)
$report = @()

foreach ($team in $teams) {
    $owners = Get-MgGroupOwner -GroupId $team.Id

    if (-not $owners) {
        $report += [PSCustomObject]@{
            TeamName = $team.DisplayName
            TeamId = $team.Id
            Visibility = $team.Visibility
            CreatedDateTime = $team.CreatedDateTime
            Description = $team.Description
            Status = "No Owners"
        }
    }
}

# If no data, create a dummy row with empty values (so headers appear in Excel)
if ($report.Count -eq 0) {
    $report += [PSCustomObject]@{
        TeamName = ""
        TeamId = ""
        Visibility = ""
        CreatedDateTime = ""
        Description = ""
        Status = ""
    }
}

# File path
#$csvPath = "$env:USERPROFILE\Desktop\Teams_Without_Owners_$(Get-Date -Format 'dd-MM-yyyy').csv"

# Export to CSV
$report | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

Write-Host "?? Report saved to: $reportPath" -ForegroundColor Cyan
