$timestamp = Get-Date -Format "ddMMyyyy_HHmm"
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$JsonPath = "$network_drive\Config.json"

$config = Get-Content $JsonPath | ConvertFrom-Json


$tenantId = $config.TenantId
$ClientId = $config.AppId
$Thumbprint = $config.Thumbprint


$tenantId
$ClientId
$Thumbprint




