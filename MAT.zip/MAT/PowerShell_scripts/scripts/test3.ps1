# Example usage
#Get-ADUser -Filter * -Server $dc -Credential $cred

$dc = "MATADDC2.MAT.com"
$username = "azureuser"
$password = ConvertTo-SecureString "Matnew@2025" -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential ($username, $password)

$Global:PSDefaultParameterValues = @{
   "*-AD*:Server" = $dc
   "*-AD*:Credential" = $cred
 }

#$Servers = @("MATADDC1.MAT.com","MATADDC2.MAT.com")
$network_drive = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty DeviceID

$timeStamp = (Get-Date -Format "yyyyMMdd_HHmmss")
$Servers = Get-ADDomainController -Filter * | Select-Object -ExpandProperty HostName
$outputFile = "$network_drive\AD_WindowsServerRoles\ServerRoles_All_$timeStamp.csv"

$results = foreach ($server in $Servers) {
    try {
        Invoke-Command -ComputerName $server -ScriptBlock {
            Get-WindowsFeature | Where-Object {$_.Installed -eq $true} |
                Select-Object @{n='Server';e={$env:COMPUTERNAME}}, DisplayName, Name
        }
    }
    catch {
        [PSCustomObject]@{
            Server = $server
            DisplayName = "ERROR"
            Name = $_.Exception.Message
        }
    }
}

$results | Export-Csv $outputFile -NoTypeInformation
Write-Host "Report generated at $outputFile"
