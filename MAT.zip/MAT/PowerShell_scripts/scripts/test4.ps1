$dc = "MATADDC2.MAT.com"
$username = "azureuser@MAT.com"
$password = ConvertTo-SecureString "Matnew@2025" -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential ($username, $password)

$Global:PSDefaultParameterValues = @{
   "*-AD*:Server" = $dc
   "*-AD*:Credential" = $cred
 }