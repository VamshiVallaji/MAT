Migration Acceleration Toolkit (MAT) - Windows Deployment Guide
Overview

The Migration Acceleration Toolkit (MAT) is a web-based automation platform designed for the Assessment phase of Microsoft 365 migrations.
It provides a centralized interface to configure tenant details, trigger PowerShell-based assessment scripts, and manage generated reports — all integrated with Azure File Share for secure and centralized storage.

Currently, MAT is in the development phase, focused on assessment automation.
However, its modular architecture allows for easy extension to future migration phases such as remediation, pilot migration, and full migration execution.

Prerequisites

Before running the application, ensure the following software is installed on your Windows system:

Node.js ≥ 18.x (for frontend)

Python ≥ 3.11 (for backend)

Redis (used as message broker for Celery)

Azure File Share configured and mounted as Z:\ (used to store PowerShell scripts and generated reports)

Frontend Deployment (React)

Navigate to the frontend folder:

cd mat-frontend


Install dependencies:

npm install


Start the frontend:

npm start


The application will start on:
👉 http://localhost:3000

(Optional) Build for production:

npm run build

Backend Deployment (FastAPI)

Navigate to the backend folder:

cd mat-backend


Create a virtual environment:

python -m venv venv


Activate the virtual environment:

venv\Scripts\activate


Install dependencies:

pip install -r requirements.txt


Start the backend API:

uvicorn app.main:app --reload --host 127.0.0.1 --port 3001


The backend will be accessible at:
👉 http://localhost:3001

API Documentation:
👉 http://localhost:3001/docs

Running Celery Worker

Celery is responsible for running PowerShell-based assessment scripts asynchronously.

Start Redis Server:

redis-server


Start Celery Worker:

celery -A app.tasks worker --loglevel=info --concurrency=10 --pool=threads


Explanation of parameters:

-A app.tasks → Location of Celery task definitions

--loglevel=info → Enables detailed log output

--concurrency=10 → Runs 10 parallel worker threads

--pool=threads → Uses threaded pool for lightweight execution

How It Works

The React frontend communicates with the FastAPI backend via REST APIs.

All user and tenant configurations are stored in a SQLite database.

When a user triggers an assessment, Celery executes PowerShell scripts located in the Z:\ (Azure File Share).

The generated reports are stored back in Z:\.

The frontend dynamically fetches these reports and allows users to download or review them via the web interface.

Common Commands Summary
Purpose	Command
Install Frontend Dependencies	npm install
Start Frontend	npm start
Create Virtual Environment	python -m venv venv
Activate Virtual Environment	venv\Scripts\activate
Install Backend Dependencies	pip install -r requirements.txt
Start FastAPI Backend	uvicorn app.main:app --reload --port 3001
Start Redis Server	redis-server
Start Celery Worker	celery -A app.tasks worker --loglevel=info --concurrency=10 --pool=threads
Verification Steps

Frontend:
Visit → http://localhost:3000

Backend:
Visit → http://localhost:3001/docs

Redis:
Make sure Redis is running in a separate terminal window.

Celery:
Confirm worker is connected to Redis and processing tasks.

Azure File Share:
Ensure that generated assessment reports appear in the Z:\ drive.

Architecture Summary

Frontend (React): Handles all user interactions, configuration forms, and report displays.

Backend (FastAPI): Exposes REST APIs for authentication, tenant management, and report tracking.

Celery (with Redis): Executes PowerShell scripts in background threads and updates job statuses.

Database (SQLite): Stores user credentials, tenant configuration, and report metadata.

Azure File Share: Centralized storage for input scripts and output reports.

Conclusion

After successful setup:

Frontend runs on port 3000

Backend runs on port 3001

Redis and Celery handle asynchronous background tasks

Azure File Share serves as the script execution and report repository

This setup provides a fully automated and centralized assessment platform for Microsoft 365 migration planning, with extensibility for future migration phases such as remediation, pilot migrations, and execution.

Author: Migration Acceleration Toolkit Development Team (Arunachalam Sevugan, Vamshi Vallaji. Jagadeesh Murru, Gayathri SR, Ramya Ummadisetti,Gayathri V, Avinash K)
Platform: Windows